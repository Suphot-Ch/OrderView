#ifndef TYPEDEF

typedef double d32;	
typedef float f32;	
typedef unsigned long u32;	
typedef long s32;
typedef unsigned int u16;	
typedef int s16; 
typedef unsigned char u8;  
typedef char s8; 
typedef struct{
	u8 Main;
	u8 CalAn;
	u8 Display;
}Status_sType;
typedef struct{
	u8 page;
	s16 Protocol;
	s16 BaudRate;
	s16 Parity;
	s16 Stop_Bit;
	s16 ADDr;
	u8 Dis_mode;
}Mode_sType;
typedef union{
	s32 LWord;
	struct{
		s16 WordLo;
		s16 WordHi;		
	};
}LWord_sType;
typedef union{
	u32 LWord;
	struct{
		u16 WordLo;
		u16 WordHi;		
	};
}LU16_uType;
typedef struct{
	u16 Buffer[16];
	u16 DecodeLast;
	u16 Decode;
	u8 Status;
	u8 TimeOut;
	u8 ByteCount;
}IR_sType;
typedef union{
	u16 Word;
	struct{
		u8 L;
		u8 H;
	};
}U16_uType;
typedef struct{
	s16 Channel;

	u8 	TimeLenght;
	s32	Actual2;
	s32	Actual1;
	s32	Total;

	s16 Data16Last;
	s32 Data32Last;

	u32 Time32;
	
	s16  ResponseTimeOut;
	s16  DelayBetweenPolls;
	
	s16  Parity;
	s16  Baudrate;
	s16  SlaveAddress;
	s16  Protocol;
	
	s8 Bits;
	u8 CoilOutput;
	
	LU16_uType DatamLast;
	
	u8	CalAnTimeOut;
	u16  CycleTimeEdit;
	u16  Time1Sec;
	u8  Time10mSec;

}Value_sType;
typedef struct{
	u32 Data[8];
	u32 Filter;
	u16 Sample;
	u32 Buffer[16];
	u8 TimeOunt;
	u8 ch[2];
	u8 ch_num;
}ADC_sType;
typedef struct {
	u8 Status;
	u16 NotResponse; 
	u16 Poll; 
	u16 Response; 
	u16 ByteReq; 
	u16 ByteRsp; 
	u16 DelayBetweenPolls; 
	u16 ResponseTimeOut; 
	u8 RxTimeOut; 
	u8 TxTimeOut; 
	u8 CrcHi; 
	u8 CrcLo;
	u8 TXTimeOut;
	u8 RXTimeOut;
	u8 ReqBuf[64];
	u8 RspBuf[64];
	u8 Ascii2HexBuf[64];
}MB_sType;
typedef struct{
	u8 Status;
	u16 HoldTime;
	u32 Actual1Div;
}Trig_sType;
typedef struct{
	u8 Minutes;
	u8 Hours;
	u8 Event;
}Program_sType;
typedef struct{
	u8 Seconds;
	u8 Minutes;
	u8 Hours;
	u8 Date;
	u8 Month;
	u8 Year;
	u8 Day;
	u8 Status;
	u8 Interrupt;
}RTC_sType;
typedef union{
	volatile u32 Word;
	struct{
		volatile u8 IrStart : 1;
		volatile u8 IrDecode : 1;
		volatile u8 TimeSetting : 1;
		volatile u8 FTX:1;

		volatile u8 FRX : 1;
		volatile u8 DATA_NOT_SUPPORT:1;
		volatile u8 NoDevice : 1;
		volatile u8 Sign : 1;

		volatile u8 Blink : 1;
		volatile u8 Power : 1;
		volatile u8 CoilsOn;
		volatile u8 BlinkEn : 1;

		volatile u8 BreakTime : 1;
		volatile u8 Edit : 1;
		volatile u8 PVLoLimit : 1;
		volatile u8 PVHiLimit : 1;

		volatile u8 CalAnalog : 1;
		volatile u8 CalPoint : 1;
		volatile u8 MB_BUSY : 1;
		volatile u8 Timer_En : 1;
		
		volatile u8 Logo : 4;
		
	};
}Flag_uType;
#endif
/*
*/
