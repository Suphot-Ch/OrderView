#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"

void shift_edit_buffer(void){
	s8 i;
	
	for(i=0;i<3;i++){
		EditBuffer[i]=EditBuffer[i+1];
	}
}
void load_edit_buffer(s32 val){
	
	Flag.Sign = 0;
	if(val<0){
		val=-val;
		Flag.Sign = 1;}
		
	// EditBuffer[0]=val/1000%10;
	// EditBuffer[1]=val/100%10;
	// EditBuffer[2]=val/10%10;
	// EditBuffer[3]=val/1%10;
	EditBuffer[0]=val/100%10;
	EditBuffer[1]=val/10%10;
	EditBuffer[2]=val/1%10;
}
s32 reload_edit_buffer(void){
	s32 val[6];
	//Flag.Sign=(val<0) ? 1 : 0;

	val[0]=EditBuffer[0];
	val[1]=EditBuffer[1];
	val[2]=EditBuffer[2];

	val[0]=val[0]*100;
	val[1]=val[1]*10;
	val[2]=val[2]*1;

	val[0]=val[0]+val[1]+val[2];

	if(Flag.Sign) val[0]=-val[0];
	return (val[0]);
}
void load_buffer_Time(void){
	EditBuffer[0]=RTC.Hours/10;
	EditBuffer[1]=RTC.Hours%10;
	EditBuffer[2]=RTC.Minutes/10;
	EditBuffer[3]=RTC.Minutes%10;
}
void reload_buffer_Time(void){
	u8 val[2];

	val[0] =   (EditBuffer[0]*10)+EditBuffer[1];
	val[1] =   (EditBuffer[2]*10)+EditBuffer[3];

	write_current_time_Fix(val[0],HOURS_REG);
	write_current_time_Fix(val[1],MINUTES_REG);
	write_current_time_Fix(0,SECONDS_REG);
}
void load_buffer_Date(void){
	EditBuffer[0]=RTC.Date/10;
	EditBuffer[1]=RTC.Date%10;
	EditBuffer[2]=RTC.Month/10;
	EditBuffer[3]=RTC.Month%10;
}
void reload_buffer_Date(void){
	u8 val[2];

	val[0] =   (EditBuffer[0]*10)+EditBuffer[1];
	val[1] =   (EditBuffer[2]*10)+EditBuffer[3];
	
	write_current_time_Fix(val[0],DATE_REG);
	write_current_time_Fix(val[1],MONTH_REG);
}
void load_buffer_Year(void){
//	EditBuffer[0]=Value.Year/1000%10;
//	EditBuffer[1]=Value.Year/100%10;
	EditBuffer[2]=RTC.Year/10;
	EditBuffer[3]=RTC.Year%10;
}
void reload_buffer_Year(void){
	u8 val[2];

//	Value.Year	=   EditBuffer[0]*1000;
//	Value.Year	+= EditBuffer[1]*100;
	val[1] =   (EditBuffer[2]*10)+EditBuffer[3];
	
//	write_eeprom(EEP_TIME_YEAR, Value.Year);
	write_current_time_Fix(val[1],YEAR_REG);
}
void load_edit_buffer_tcd(s16 val){
	Flag.Sign = 0;
	if(val<0){
		val=-val;
		Flag.Sign = 1;}

	EditBuffer[0]=val/100000%10;
	EditBuffer[1]=val/10000%10;
	EditBuffer[2]=val/1000%10;
	EditBuffer[3]=val/100%10;
	EditBuffer[4]=val/10%10;
	EditBuffer[5]=val%10;
}
void hys_mode(void){
	Status.Main=HYS_MODE;
	Flag.Edit=0;
	Value.DatamLast.LWord=Value.ALC[Value.Channel].LWord;
	load_edit_buffer(Value.ALC[Value.Channel].LWord);
}
u8 modeBlank;
void Mode_Blank(void){
	modeBlank = Status.Main;
	Status.Main = MODE_INP;
}
void LoadMode_Blank(void){
	Status.Main = modeBlank;
	switch(modeBlank){
	case EDIT_SCALE_HI:
		Value.Channel=0;
		edit_scale_hi_mode();
		break;
	case EDIT_SCALE_LO:
		Value.Channel=0;
		edit_scale_lo_mode();
		break;
	case EDIT_PUS_MODE:
		Value.Channel=0;
		pus_mode();
		break;
	case EDIT_DP:
		Value.Channel=0;
		edit_decimalpoint_mode();
		break;
	case CAL_ANALOG:
		Value.Channel=0;
		cal_analog_mode();
		break;
	case EDIT_ADDRESS:
		edit_slave_address_mode();
		break;
	case EDIT_BAUDRATE:
		edit_baudrate_mode();
		break;
	case EDIT_PARITY:
		edit_parity_mode();
		break;
	}
}
void alarm_low_mode(void){
	Status.Main=ALL_MODE;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.ALL[Value.Channel].LWord;
	load_edit_buffer(Value.ALL[Value.Channel].LWord);
}
void alarm_high_mode(void){
	Status.Main=ALH_MODE;
	Flag.Edit=0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.ALH[Value.Channel].LWord;
	load_edit_buffer(Value.ALH[Value.Channel].LWord);
}
void alarm_control_mode(void){
	Status.Main=ALC_MODE;
	Flag.Edit=0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.ALC[Value.Channel].LWord;
	load_edit_buffer(Value.ALC[Value.Channel].LWord);
}
void set_point_2_c_mode(void){
	Status.Main=SETPOINT_2_MODE;
	Flag.Edit=0;
//	Value.DatamLast.LWord=Value.SP2_C;
//	load_edit_buffer(Value.SP2_C);
}
void choose_mode(void){
	Status.Main=CHOOSE_MODE;
	Flag.Edit=0;
	Flag.Blink=0;
	Value.DatamLast.LWord=Value.Mode[Value.Channel];
	load_edit_buffer(Value.Mode[Value.Channel]);
}
void mode_input(void){
	Status.Main=MODE_INP;
	Flag.Edit=0;
}
void operate_mode(void){
	Status.Main=OPERATE;
	Flag.Edit=0;
	EditNum=0;
	load_edit_buffer(0);
	Flag.CalAnalog=0;
	Value.Channel=0;
}
void edit_scale_hi_mode(void){														// USE
	Status.Main=EDIT_SCALE_HI;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.ScaleHiLimit[Value.Channel].LWord;
	load_edit_buffer(Value.ScaleHiLimit[Value.Channel].LWord);
}
void edit_scale_lo_mode(void){														// USE
	Status.Main=EDIT_SCALE_LO;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.ScaleLoLimit[Value.Channel].LWord;
	load_edit_buffer(Value.ScaleLoLimit[Value.Channel].LWord);
}
void pus_mode(void){
	Status.Main=EDIT_PUS_MODE;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.PVS[Value.Channel].LWord;
	load_edit_buffer(Value.PVS[Value.Channel].LWord);
}
void edit_decimalpoint_mode(void){												// USE
	Status.Main=EDIT_DP;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.DecimalPoint[Value.Channel];
	load_edit_buffer(Value.DecimalPoint[Value.Channel]);
}
void edit_slave_address_mode(void){												// USE
	Status.Main=EDIT_ADDRESS;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.SlaveAddress;
	load_edit_buffer(Value.SlaveAddress);
}
void edit_baudrate_mode(void){
	Status.Main=EDIT_BAUDRATE;		
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.Baudrate;
	EditBuffer[EDIT_LENGTH-1] = Value.Baudrate;
}
void edit_parity_mode(void){
	Status.Main=EDIT_PARITY;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Flag.Edit=0;
	EditNum=0;
	Value.DatamLast.LWord=Value.Parity;
	EditBuffer[EDIT_LENGTH-1] = Value.Parity;
}
void edit_delay_polls_mode(void){
	Status.Main=EDIT_DELAY_POLLS;
	Flag.Edit=0;
	Value.DatamLast.LWord=Value.DelayBetweenPolls;
	load_edit_buffer(Value.DelayBetweenPolls);
}
void edit_response_timeout_mode(void){
	Status.Main=EDIT_RESPONSE_TIMEOUT;
	Flag.Edit=0;
	Value.DatamLast.LWord=Value.ResponseTimeOut;
	load_edit_buffer(Value.ResponseTimeOut);
}
void change_display(void){
	Status.Main=CHANGE_DSP;
	Flag.Edit=0;
//	Value.DatamLast.LWord=Value.CycleTime;
//	load_edit_buffer(Value.CycleTime);
}

void tcd(void){
//	if(Value.CycleTimeEdit!=0){
//		if(++Value.Time1Sec>=Value.CycleTimeEdit){
//			Value.Time1Sec=0;	
//			Value.Channel++;
//			if(Value.Channel>3){Value.Channel=0;}
//			}
//		}
}
	
void edit_timer(void){
	Status.Main=EDIT_TIMER;
	Flag.Edit=1;
	Flag.BlinkEn = 1;
	Flag.Blink = 0;
	EditNum = 1;
	load_buffer_Time();
}
void edit_value_time(void){
	Status.Main=EDIT_VALUE_TIME;
	Flag.Edit=0;
	Flag.BlinkEn = 1;
	Flag.Blink = 0;
	EditNum = 1;
	load_buffer_Time();
}
void edit_value_date(void){
	Status.Main=EDIT_VALUE_DATE;
	Flag.Edit=0;
	Flag.BlinkEn = 1;
	Flag.Blink = 0;
	EditNum = 1;
	Flag.Checker = 0;
	load_buffer_Date();
}
void edit_value_year(void){
	Status.Main=EDIT_VALUE_YEAR;
	Flag.Edit=0;
	Flag.BlinkEn = 1;
	Flag.Blink = 0;
	EditNum = 1;
	Flag.Checker = 0;
	load_buffer_Year();
}
	
void cal_analog_mode(void){
	Status.Main=CAL_ANALOG;
	Flag.CalAnalog=1;
	Flag.Edit=0;
	Flag.CalPoint=0;
	Value.Channel=0;
	// Mode_Blank();
}
void idle_mode(void){
	Status.Main=IDLE;
	Flag.Edit=0;
}
void check_cal_analog(void){
	if(Status.Main!=OPERATE) return;
	if(!Flag.CalAnalog){
		if((EditNum>=1)&&(++Value.CalAnTimeOut>50)){
			if((EditBuffer[0]=1)&&(EditBuffer[1]==6)&&(EditBuffer[2]==3)&&(EditBuffer[3]==4)){
				cal_analog_mode();
			}
		}
	}
}
void Clear_Buffer(void){
	u8 i;
	Flag.Sign=0;
	EditNum=1;
	for(i=0;i<EDIT_LENGTH;i++)
		EditBuffer[i]=0;
}

void ch2(void){
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();

	/// CH0 ///
	LATBbits.LATB6=1; //A
	LATBbits.LATB7=0; //B
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	ADC_CS=0;
	delayxNop();
	delayxNop();
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
}

void ch3(void){
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();

	/// CH0 ///
	LATBbits.LATB6=0; //A
	LATBbits.LATB7=1; //B
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	ADC_CS=0;
	delayxNop();
	delayxNop();
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
}

void save(void){
	switch(Status.Main){
		case EDIT_SCALE_HI:
			if(Value.DatamLast.LWord!=Value.ScaleHiLimit[Value.Channel].LWord){
				if(Value.Channel==0){
					write_eeprom(EEP_SCALE_HI_HW0, Value.ScaleHiLimit[0].WordHi);
					write_eeprom(EEP_SCALE_HI_LW0, Value.ScaleHiLimit[0].WordLo);}
				if(Value.Channel==1){
					write_eeprom(EEP_SCALE_HI_HW1, Value.ScaleHiLimit[1].WordHi);
					write_eeprom(EEP_SCALE_HI_LW1, Value.ScaleHiLimit[1].WordLo);}
				if(Value.Channel==2){
					write_eeprom(EEP_SCALE_HI_HW2, Value.ScaleHiLimit[2].WordHi);
					write_eeprom(EEP_SCALE_HI_LW2, Value.ScaleHiLimit[2].WordLo);}
				// if(Value.Channel==3){
				// 	write_eeprom(EEP_SCALE_HI_HW3, Value.ScaleHiLimit[3].WordHi);
				// 	write_eeprom(EEP_SCALE_HI_LW3, Value.ScaleHiLimit[3].WordLo);}
				}
			break;
		case EDIT_SCALE_LO:
			if(Value.DatamLast.LWord!=Value.ScaleLoLimit[Value.Channel].LWord){
				if(Value.Channel==0){
					write_eeprom(EEP_SCALE_LO_HW0, Value.ScaleLoLimit[0].WordHi);
					write_eeprom(EEP_SCALE_LO_LW0, Value.ScaleLoLimit[0].WordLo);}
				if(Value.Channel==1){
					write_eeprom(EEP_SCALE_LO_HW1, Value.ScaleLoLimit[1].WordHi);
					write_eeprom(EEP_SCALE_LO_LW1, Value.ScaleLoLimit[1].WordLo);}
				if(Value.Channel==2){
					write_eeprom(EEP_SCALE_LO_HW2, Value.ScaleLoLimit[2].WordHi);
					write_eeprom(EEP_SCALE_LO_LW2, Value.ScaleLoLimit[2].WordLo);}
				// if(Value.Channel==3){
				// 	write_eeprom(EEP_SCALE_LO_HW3, Value.ScaleLoLimit[3].WordHi);
				// 	write_eeprom(EEP_SCALE_LO_LW3, Value.ScaleLoLimit[3].WordLo);}	
				}
			break;
		case EDIT_PUS_MODE:
			if(Value.DatamLast.LWord!=Value.PVS[Value.Channel].LWord){
				if(Value.Channel==0){	
					write_eeprom(EEP_PUS1, Value.PVS[0].WordHi);
					write_eeprom(EEP_PUS11, Value.PVS[0].WordLo);}
				if(Value.Channel==1){
					write_eeprom(EEP_PUS2, Value.PVS[1].WordHi);
					write_eeprom(EEP_PUS22, Value.PVS[1].WordLo);}
				if(Value.Channel==2){
					write_eeprom(EEP_PUS3, Value.PVS[2].WordHi);
					write_eeprom(EEP_PUS33, Value.PVS[2].WordLo);}
			}
			break;
		case ALC_MODE:
			// if(Value.DatamLast.LWord!=Value.ALC[Value.Channel].LWord){
			// 	if(Value.Channel==0){
			// 		write_eeprom(EEP_ALC1, Value.ALC[0].WordHi);
			// 		write_eeprom(EEP_ALC11, Value.ALC[0].WordLo);}
			// 	if(Value.Channel==1){
			// 		write_eeprom(EEP_ALC2, Value.ALC[1].WordHi);
			// 		write_eeprom(EEP_ALC22, Value.ALC[1].WordLo);}
			// 	if(Value.Channel==2){
			// 		write_eeprom(EEP_ALC3, Value.ALC[2].WordHi);
			// 		write_eeprom(EEP_ALC33, Value.ALC[2].WordLo);}
			// 	if(Value.Channel==3){
			// 		write_eeprom(EEP_ALC4, Value.ALC[3].WordHi);
			// 		write_eeprom(EEP_ALC44, Value.ALC[3].WordLo);}
			// 	}
			break;
		case ALH_MODE:
			// if(Value.DatamLast.LWord!=Value.ALH[Value.Channel].LWord){
			// 	if(Value.Channel==0){
			// 		write_eeprom(EEP_ALH1, Value.ALH[AL0_PV0].WordHi);
			// 		write_eeprom(EEP_ALH11, Value.ALH[AL0_PV0].WordLo);}
			// 	if(Value.Channel==1){
			// 		write_eeprom(EEP_ALH2, Value.ALH[AL1_PV0].WordHi);
			// 		write_eeprom(EEP_ALH22, Value.ALH[AL1_PV0].WordLo);}
			// 	if(Value.Channel==2){
			// 		write_eeprom(EEP_ALH3, Value.ALH[AL0_PV1].WordHi);
			// 		write_eeprom(EEP_ALH33, Value.ALH[AL0_PV1].WordLo);}
			// 	if(Value.Channel==3){
			// 		write_eeprom(EEP_ALH4, Value.ALH[AL1_PV1].WordHi);
			// 		write_eeprom(EEP_ALH44, Value.ALH[AL1_PV1].WordLo);}
			// 	}
			break;
		case ALL_MODE:
			// if(Value.DatamLast.LWord!=Value.ALL[Value.Channel].LWord){
			// 	if(Value.Channel==0){
			// 		write_eeprom(EEP_ALL1, Value.ALL[AL0_PV0].WordHi);
			// 		write_eeprom(EEP_ALL11, Value.ALL[AL0_PV0].WordLo);}
			// 	if(Value.Channel==1){
			// 		write_eeprom(EEP_ALL2, Value.ALL[AL1_PV0].WordHi);
			// 		write_eeprom(EEP_ALL22, Value.ALL[AL1_PV0].WordLo);}
			// 	if(Value.Channel==2){
			// 		write_eeprom(EEP_ALL3, Value.ALL[AL0_PV1].WordHi);
			// 		write_eeprom(EEP_ALL33, Value.ALL[AL0_PV1].WordLo);}
			// 	if(Value.Channel==3){
			// 		write_eeprom(EEP_ALL4, Value.ALL[AL1_PV1].WordHi);
			// 		write_eeprom(EEP_ALL44, Value.ALL[AL1_PV1].WordLo);}
			// 	}
			break;
		case CHOOSE_MODE:
			// if(Value.DatamLast.LWord!=Value.Mode[Value.Channel]){
			// 	if(Value.Channel==0){	write_eeprom(EEP_MODE1, Value.Mode[0]);}
			// 	if(Value.Channel==1){	write_eeprom(EEP_MODE2, Value.Mode[1]);}
			// 	if(Value.Channel==2){	write_eeprom(EEP_MODE3, Value.Mode[2]);}
			// 	if(Value.Channel==3){	write_eeprom(EEP_MODE4, Value.Mode[3]);}	
			// 	}
			break;
		case EDIT_DP:
			if(Value.DatamLast.LWord!=Value.DecimalPoint[Value.Channel]){
				if(Value.Channel==0){	write_eeprom(EEP_DP1, Value.DecimalPoint[0]);}
				if(Value.Channel==1){	write_eeprom(EEP_DP2, Value.DecimalPoint[1]);}
				if(Value.Channel==2){	write_eeprom(EEP_DP3, Value.DecimalPoint[2]);}
//				if(Value.Channel==3){write_eeprom(EEP_DP4, Value.DecimalPoint[3]);}	
				}
			break;
		case EDIT_ADDRESS:
			if(Value.DatamLast.LWord!=Value.SlaveAddress){
				write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
			}
			break;
		case EDIT_BAUDRATE:
			if(Value.DatamLast.LWord!=Value.Baudrate){
				write_eeprom(EEP_BAUDRATE, Value.Baudrate);
			}
			break;
		case EDIT_PARITY:
			if(Value.DatamLast.LWord!=Value.Parity){
				write_eeprom(EEP_PARITY, Value.Parity);
			}
			break;
/*
		case EDIT_DELAY_POLLS:
			if(Value.DatamLast.LWord!=Value.DelayBetweenPolls){
				write_eeprom(EEP_DELAY_POLLS, Value.DelayBetweenPolls);
			}
			break;
		case EDIT_RESPONSE_TIMEOUT:
			if(Value.DatamLast.LWord!=Value.ResponseTimeOut){
				write_eeprom(EEP_RESP_TIME_OUT, Value.ResponseTimeOut);
			}
			break;
*/
		case CHANGE_DSP:
//			if(Value.DatamLast.LWord!=Value.CycleTimeEdit){
//				if(Value.CycleTimeEdit>60000||Value.CycleTimeEdit<1){Value.CycleTimeEdit=0; write_eeprom(EEP_CYCLE, Value.CycleTimeEdit);}
//				else write_eeprom(EEP_CYCLE, Value.CycleTimeEdit);
//				}
			break;
		case CAL_ANALOG:
			if(!Flag.CalPoint){
				if(Value.Channel==0){
				Value.SystemZeroScale[0].LWord=ADC.Filter[0];
				write_eeprom(EEP_AN_ZERO_HW0, Value.SystemZeroScale[0].WordHi);
				write_eeprom(EEP_AN_ZERO_LW0, Value.SystemZeroScale[0].WordLo);
					}
				if(Value.Channel==1){
				Value.SystemZeroScale[1].LWord=ADC.Filter[1];
				write_eeprom(EEP_AN_ZERO_HW1, Value.SystemZeroScale[1].WordHi);
				write_eeprom(EEP_AN_ZERO_LW1, Value.SystemZeroScale[1].WordLo);
					}
				
				if(Value.Channel==2){
				Value.SystemZeroScale[2].LWord=ADC.Filter[2];
				write_eeprom(EEP_AN_ZERO_HW2, Value.SystemZeroScale[2].WordHi);
				write_eeprom(EEP_AN_ZERO_LW2, Value.SystemZeroScale[2].WordLo);
					}

				if(Value.Channel==3){
				Value.SystemZeroScale[3].LWord=ADC.Filter[3];
				write_eeprom(EEP_AN_ZERO_HW3, Value.SystemZeroScale[3].WordHi);
				write_eeprom(EEP_AN_ZERO_LW3, Value.SystemZeroScale[3].WordLo);
					}
				
			}
			else{
				if(Value.Channel==0){
				Value.SystemFullScale[0].LWord=ADC.Filter[0];
				write_eeprom(EEP_AN_FULL_HW0, Value.SystemFullScale[0].WordHi);
				write_eeprom(EEP_AN_FULL_LW0, Value.SystemFullScale[0].WordLo);
					}
				if(Value.Channel==1){
				Value.SystemFullScale[1].LWord=ADC.Filter[1];
				write_eeprom(EEP_AN_FULL_HW1, Value.SystemFullScale[1].WordHi);
				write_eeprom(EEP_AN_FULL_LW1, Value.SystemFullScale[1].WordLo);
					}
				
				if(Value.Channel==2){
				Value.SystemFullScale[2].LWord=ADC.Filter[2];
				write_eeprom(EEP_AN_FULL_HW2, Value.SystemFullScale[2].WordHi);
				write_eeprom(EEP_AN_FULL_LW2, Value.SystemFullScale[2].WordLo);
					}

				if(Value.Channel==3){
				Value.SystemFullScale[3].LWord=ADC.Filter[3];
				write_eeprom(EEP_AN_FULL_HW3, Value.SystemFullScale[3].WordHi);
				write_eeprom(EEP_AN_FULL_LW3, Value.SystemFullScale[3].WordLo);
					}
					
			}
			break;
	}
}
void OUTPUT_RELAY(u8 status){
u8 i;
	OUT1 = status==1? 1 : 0;
	for(i=0;i<100;i++) {}
	OUT2 = status==2? 1 : 0;
	for(i=0;i<100;i++) {}
	OUT3 = status==3? 1 : 0;
	for(i=0;i<100;i++) {}
}
void backGround(void){

	if(Value.TimeOut_cal>0)Value.TimeOut_cal--;
	else{
		Value.Analog_cal = 0;
		}

	switch(Value.Mode[0]){
	case 0:
		OUTPUT_RELAY(0);
		Alarm_PV_Ch_1 = 0;
		Alarm_PV_Ch_2 = 0;
		break;
	case 1:
		if(	((Value.PV[0]>Value.ALH[AL1_PV0].LWord)||(Value.PV[1]>Value.ALH[AL1_PV1].LWord))||
			((Value.PV[0]<Value.ALL[AL1_PV0].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord))	)
			{ 	OUTPUT_RELAY(3);	}
		else{
			if(	((Value.PV[0]>Value.ALH[AL0_PV0].LWord)||(Value.PV[1]>Value.ALH[AL0_PV1].LWord))||
				((Value.PV[0]<Value.ALL[AL0_PV0].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord))	)
				{ 	OUTPUT_RELAY(2);	}
			else{ 	OUTPUT_RELAY(1);	}
			}
		
			 if((Value.PV[0]>Value.ALH[AL1_PV0].LWord)||(Value.PV[0]<Value.ALL[AL1_PV0].LWord)){	Alarm_PV_Ch_1 = 2;	}
		else if((Value.PV[0]>Value.ALH[AL0_PV0].LWord)||(Value.PV[0]<Value.ALL[AL0_PV0].LWord)){	Alarm_PV_Ch_1 = 1;	}
		else{	Alarm_PV_Ch_1 = 0;		}
		
			 if((Value.PV[1]>Value.ALH[AL1_PV1].LWord)||(Value.PV[1]<Value.ALL[AL1_PV1].LWord)){	Alarm_PV_Ch_2 = 2;	}
		else if((Value.PV[1]>Value.ALH[AL0_PV1].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord)){	Alarm_PV_Ch_2 = 1;	}
		else{	Alarm_PV_Ch_2 = 0;		}
		break;
	case 2:
		if(	((Value.PV[0]>Value.ALH[AL1_PV0].LWord)||(Value.PV[1]>Value.ALH[AL1_PV1].LWord))	)
			{ 	OUTPUT_RELAY(3);	}
		else{
			if(	((Value.PV[0]>Value.ALH[AL0_PV0].LWord)||(Value.PV[1]>Value.ALH[AL0_PV1].LWord))	)
				{ 	OUTPUT_RELAY(2);	}
			else{ 	OUTPUT_RELAY(1);	}
			}
		
		if((Value.PV[0]>Value.ALH[AL1_PV0].LWord)){		Alarm_PV_Ch_1 = 2;	}
		else if((Value.PV[0]>Value.ALH[AL0_PV0].LWord)){	Alarm_PV_Ch_1 = 1;	}
		else{	Alarm_PV_Ch_1 = 0;		}
		
		if((Value.PV[1]>Value.ALH[AL1_PV1].LWord)){		Alarm_PV_Ch_2 = 2;	}
		else if((Value.PV[1]>Value.ALH[AL0_PV1].LWord)){	Alarm_PV_Ch_2 = 1;	}
		else{	Alarm_PV_Ch_2 = 0;		}
		break;
	case 3:
		if(	((Value.PV[0]<Value.ALL[AL1_PV0].LWord)||(Value.PV[1]<Value.ALL[AL1_PV1].LWord))	)
			{ 	OUTPUT_RELAY(3);	}
		else{
			if(((Value.PV[0]<Value.ALL[AL0_PV0].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord))	)
				{ 	OUTPUT_RELAY(2);	}
			else{ 	OUTPUT_RELAY(1);	}
			}
		
		if((Value.PV[0]<Value.ALL[AL1_PV0].LWord)){		Alarm_PV_Ch_1 = 2;	}
		else if((Value.PV[0]<Value.ALL[AL0_PV0].LWord)){	Alarm_PV_Ch_1 = 1;	}
		else{	Alarm_PV_Ch_1 = 0;		}
		
		if((Value.PV[1]<Value.ALL[AL1_PV1].LWord)){		Alarm_PV_Ch_2 = 2;	}
		else if((Value.PV[1]<Value.ALL[AL0_PV1].LWord)){	Alarm_PV_Ch_2 = 1;	}
		else{	Alarm_PV_Ch_2 = 0;		}
		break;
	case 4:
		if(	((Value.PV[0]>Value.ALH[AL1_PV0].LWord)||(Value.PV[1]>Value.ALH[AL1_PV1].LWord))||
			((Value.PV[0]<Value.ALL[AL1_PV0].LWord)||(Value.PV[1]<Value.ALL[AL1_PV1].LWord))	)
			{ 	OUTPUT_RELAY(1);	}
		else{
			if(	((Value.PV[0]>Value.ALH[AL0_PV0].LWord)||(Value.PV[1]>Value.ALH[AL0_PV1].LWord))||
				((Value.PV[0]<Value.ALL[AL0_PV0].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord))	)
				{ 	OUTPUT_RELAY(2);	}
			else{ 	OUTPUT_RELAY(3);	}
			}
		
		if((Value.PV[0]>Value.ALH[AL1_PV0].LWord)||(Value.PV[0]<Value.ALL[AL1_PV0].LWord)){		Alarm_PV_Ch_1 = 0;	}
		else if((Value.PV[0]>Value.ALH[AL0_PV0].LWord)||(Value.PV[0]<Value.ALL[AL0_PV0].LWord)){	Alarm_PV_Ch_1 = 1;	}
		else{	Alarm_PV_Ch_1 = 2;		}
		
		if((Value.PV[1]>Value.ALH[AL1_PV1].LWord)||(Value.PV[1]<Value.ALL[AL1_PV1].LWord)){		Alarm_PV_Ch_2 = 0;	}
		else if((Value.PV[1]>Value.ALH[AL0_PV1].LWord)||(Value.PV[1]<Value.ALL[AL0_PV1].LWord)){	Alarm_PV_Ch_2 = 1;	}
		else{	Alarm_PV_Ch_2 = 2;		}
		break;
	}
	
}
void trig_0(void){
	switch(Trig0.Status){
		case TRIG:
			if(!_RB0){
				Trig0.HoldTime=CLR;
				Trig0.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB0){
				if(++Trig0.HoldTime>=2){
					/*trig*/
					Trig0.HoldTime=CLR;
					Trig0.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig0.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB0){
				Trig0.Status=TRIG;
			}
			break;
	}
}
void trig_1(void){
	switch(Trig1.Status){
		case TRIG:
			if(!_RB1){
				Trig1.HoldTime=CLR;
				Trig1.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB1){
				if(++Trig1.HoldTime>=2){
					/*trig*/
					Trig1.HoldTime=CLR;
					Trig1.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig1.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB1){
				Trig1.Status=TRIG;
			}
			break;
	}
}
void trig_2(void){
	switch(Trig2.Status){
		case TRIG:
			if(!_RB2){
				Trig2.HoldTime=CLR;
				Trig2.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB2){
				if(++Trig2.HoldTime>=2){
					/*trig*/
					Trig2.HoldTime=CLR;
					Trig2.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig2.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB2){
				Trig2.Status=TRIG;
			}
			break;
	}
}
void trig_3(void){
	switch(Trig3.Status){
		case TRIG:
			if(!_RB3){
				Trig3.HoldTime=CLR;
				Trig3.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB3){
				if(++Trig3.HoldTime>=2){
					/*trig*/
					Trig3.HoldTime=CLR;
					Trig3.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig3.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB3){
				Trig3.Status=TRIG;
			}
			break;
	}
}
void trig_4(void){
	switch(Trig4.Status){
		case TRIG:
			if(!_RB4){
				Trig4.HoldTime=CLR;
				Trig4.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB4){
				if(++Trig4.HoldTime>=2){
					/*trig*/
					Trig4.HoldTime=CLR;
					Trig4.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig4.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB4){
				Trig4.Status=TRIG;
			}
			break;
	}
}
void trig_5(void){
	switch(Trig5.Status){
		case TRIG:
			if(!_RB5){
				Trig5.HoldTime=CLR;
				Trig5.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB5){
				if(++Trig5.HoldTime>=2){
					/*trig*/
					Trig5.HoldTime=CLR;
					Trig5.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig5.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB5){
				Trig5.Status=TRIG;
			}
			break;
	}
}
void trig_6(void){
	switch(Trig6.Status){
		case TRIG:
			if(!_RC13){
				Trig6.HoldTime=CLR;
				Trig6.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC13){
				if(++Trig6.HoldTime>=2){
					/*trig*/
					Trig6.HoldTime=CLR;
					Trig6.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig6.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC13){
				Trig6.Status=TRIG;
			}
			break;
	}
}
void trig_7(void){
	switch(Trig7.Status){
		case TRIG:
			if(!_RC14){
				Trig7.HoldTime=CLR;
				Trig7.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC14){
				if(++Trig7.HoldTime>=2){
					/*trig*/
					Trig7.HoldTime=CLR;
					Trig7.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig7.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC14){
				Trig7.Status=TRIG;
			}
			break;
	}
}

