#include <p30f4011.h>
#include <stdio.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"

/*
void U2RX_handle(u8 rxbuffer){
	
	if(!Flag.Frx){
		if(rxbuffer==RX_START){
			Flag.Frx=SET;
			Modbus.ByteReq=CLR;
			Modbus.ReqBuf[Modbus.ByteReq++]=rxbuffer;
		}
	}
	else{
		if(rxbuffer==RX_STOP){
			Flag.Frx=CLR;
			if(Modbus.ReqBuf[1]=='W'&&Modbus.ReqBuf[2]=='R'){
				sum(_W, Modbus.ReqBuf);
				if((Modbus.CrcH==Modbus.ReqBuf[11])&&(Modbus.CrcLo==Modbus.ReqBuf[12])){
					switch(get_addr(Modbus.ReqBuf[3], Modbus.ReqBuf[4])){
						case SLAVE_ADDR:
							if(!incorrect_data(&Modbus.ReqBuf[5])){
								write_data(get_sign(), get_dp(), &Modbus.ReqBuf[6]);
							}
							break;
						default:
							break;
					}
				}
			}
			else if(Modbus.ReqBuf[1]=='R'&&Modbus.ReqBuf[2]=='D'){
				sum(_R, Modbus.ReqBuf);
				if((Modbus.CrcHi==Modbus.ReqBuf[5])&&(Modbus.CrcLo==Modbus.ReqBuf[6])){
					switch(get_addr(Modbus.ReqBuf[3], Modbus.ReqBuf[4])){
						case SLAVE_ADDR:
							read_data();
							break;
						default:
							break;
					}
				}
			}
		}	
		else{
			Modbus.ReqBuf[Modbus.ByteReq++]=rxbuffer;
		}
	}
}
*/
void INT0_handle(void){
	if(Status.Main){
		IrData.TimeOut=0;
		switch(IrData.Status){
			case 0:
				_T2ON=DIS;	
				Flag.IrDecode=SET;
				IrData.Status=SET;
				break;
			case 1:
				IrData.ByteCount=CLR;
				_T2ON=EN;	
				IrData.Status=2;	
				break;
			case 2:
				IrData.Buffer[IrData.ByteCount++]=TMR2;	
				break;
		}
		TMR2=CLR;	
	}
}
void U2RX_handle(u8 rxbuffer){
	if(!Flag.FRX){ 
		Flag.FRX=1;
		Modbus.ByteReq=0;
	}
	Modbus.RxTimeOut=CLR;
	Modbus.ReqBuf[Modbus.ByteReq++]=rxbuffer;
	if(Modbus.ByteReq>128) Modbus.ByteReq=CLR;
}
void U2TX_handle(void){
	//if(bic(U2STA, BIT9)){
		if(Modbus.ByteRsp){
			Modbus.ByteRsp--;
			U2TXREG=*MB_Dptr++;	
		}
		else{
			Modbus.RxTimeOut=0;
			Flag.FRX=0;
			//Modbus.ByteRsp=0;
// Use			rx_en();
		}
	//}
}
u32 x11,x33,x44;
void TMR3_handle(void){
	switch(Status.Main){
		case INIT_MODE:
		case IDLE_MODE:
			break;
		default:
				Encoder();
			if(Value.InputType == 0){
//				trig_1();
//				trig_2();
				}
//			trig_5();
			break;
	}
	x33++;
}
void TMR4_handle(void){
	f32 actual;
	switch(Status.Main){
		case INIT_MODE:
		case IDLE_MODE:
			break;
		default:
//			if(Flag.Timer_En){
//				++Value.Actual3;
//				write_ram_RTC(RAM_ACTUAL3_, &Value.Actual3, 4);
//				Value.Actual2 = (Value.Actual1*100) / Value.Actual3;
//				Value.Actual2 *= 60;
//				if(Value.Actual2>=0 && Value.Actual2<= 9){
//					Value.Actual2 /=1;
//					Value.xDecimalPoint = 2;
//					}
//				else if(Value.Actual2>=10 && Value.Actual2<= 99){
//					Value.Actual2 /=10;
//					Value.xDecimalPoint = 1;
//					}
//				else{
//					Value.Actual2 /=100;
//					Value.xDecimalPoint = 0;
//					}
//				}
//			trig_4();
//			trig_5();
			break;
	}
}

void TMR1_handle(void){
	
	switch(Status.Main){
		case INIT_MODE:
			//Open();
			Flag.BlinkEn=0;
			Flag.Blink=0;
			if(++Value.Time1Sec>=TIME1SEC){
				Value.Time1Sec=0;
				if(++Flag.Logo>=4){
					operate_mode();
				}
				}
			break;
		default:
			if(++x11>=100){
				x11=0;
				x44 = x33;
				x33 = 0;
				}
			trig_0();
			ir_decode();	
			AlarmOutput();
//			read_rtc_ISL();
//			modbus();
//			check_cal_analog();
//			get_analog(0);
//			edit_Relay_mode();
//			get_analog(ADC.ch_num);
//			summary_and_percent_grade_c();
//			grade_C_RJ_count();
//			grade_A_count();
			//update_segment_page[Status.Main]();
			//TPIC6B595_LATCH(SegmentData);
//			Time_Reset_Display();
//			Time_ON_OFF();
			break;
	}
//	ir_decode();
//	get_analog(ADC.ch_num);
	update_segment_page[Status.Main]();
	TPIC6B595_scan();
//	TPIC6B595_LATCH(SegmentData);
}
void CN2_handle(void){
	switch(Status.Main){
		case INIT_MODE:
			break;
		case OPERATE_MODE:
		default:
			if(Value.InputType == 1){
				}
			break;
		}
}
void _ISR _CNInterrupt(void){
	_CNIF^=_CNIF;
		CN2_handle();
}
void _ISR _INT0Interrupt(void){
		_INT0IF^=_INT0IF;
		INT0_handle();
}
void _ISR _U2RXInterrupt(void){
	/*Add your code here*/
		_U2RXIF^=_U2RXIF;
		U2RX_handle(U2RXREG);
}
void _ISR _T4Interrupt(void){
	/*Add your code here*/
		_T4IF^=_T4IF;
		TMR4_handle();
		//TPIC6B595_LATCH(SegmentData);
}
void _ISR _T1Interrupt(void){
	/*Add your code here*/
		_T1IF^=_T1IF;
		TMR1_handle();
		//	TimeUpdate=CLR;
		//	if(++TestCount>=10000) TestCount=CLR;
		//}
}
void _ISR _T2Interrupt(void){
	/*Add your code here*/
		_T2IF^=_T2IF;
		//TMR2_handle();
		//if(++TimeUpdate>=10) TimeUpdate=0;
		//display_1();
}
void _ISR _U2TXInterrupt(void){
	/*Add your code here*/
	_U2TXIF^=_U2TXIF;	
	U2TX_handle();
}
void _ISR _T3Interrupt(void){
	/*Add your code here*/
		_T3IF^=_T3IF;
		TMR3_handle();
		//if(++TimeUpdate>=10) TimeUpdate=0;
		//display_1();
}

