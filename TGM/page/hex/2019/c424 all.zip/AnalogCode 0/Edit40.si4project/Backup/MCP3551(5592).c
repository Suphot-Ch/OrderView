#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

enum{Lo, Hi};

void clk(void){
	delayxNop();
	SCL=Hi;
	delayxNop();
	SCL=Lo;
}

void mux(void){
	CD4051_A=(ADC.channel&0x01) ? 1 : 0;
	CD4051_B=(ADC.channel&0x02) ? 1 : 0;
}

#if 0
void t_sample(void){
	SDAIO=OUTPUT;
	SDA=Hi;
	SCL=Hi;
	delayxNop();
	SCL=Lo;
	clk();
	clk();
}
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;
	
	ADC_CS=Lo;
	delayxNop();
	t_sample();
	SDAIO=INPUT;
	clk();
	delayxNop();
	value=CLR;
	for(i=0;i<22;i++){
		value<<=1;
		SCL=Lo;
		delayxNop();
		if(SDA) value|=1;
		SCL=Hi;	
		delayxNop();
	}
	delayxNop();
	ADC_CS=Hi;
	return value;
}
#endif
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;

	value=0;
	for(i=0;i<24;i++){
		value<<=1;
		SCL=Hi;
		delayxNop();
		if(SDA) value|=1;
		delayxNop();
		SCL=Lo;	
		delayxNop();
		delayxNop();
	}
	delayxNop();
	
	ADC_CS=Hi;
	return value;
}
void get_analog(channel){
	float scale, span[3], zero[3], output[3];
	u8 i, j;
	s32 temp;
	s32 buffer, High_Scale[4],Low_Scale[4]; 
	mux();
	
	if(++ADC.TimeOunt>=5){
		ADC.TimeOunt=CLR;

		SDAIO=INPUT;
		ADC_CS=Lo;
		delayxNop();
		SCL=Lo;
		delayxNop();
		delayxNop();
		
		if(SDA==0){ 
			ADC.Data[ADC.Sample++]=MCP3551_read(channel);
			
			if(ADC.Data[ADC.Sample]&0x400000){
			}
			else if(ADC.Data[ADC.Sample]&0x800000){
			}
			
			else{
				if(ADC.Sample>=4){
					ADC.Sample=0;  
#if 1				
					for(i=0;i<3;i++){
						for(j=i+1;j<4;j++){
							if(ADC.Data[i]>ADC.Data[j]){
								temp=ADC.Data[j];
								ADC.Data[j]=ADC.Data[i];
								ADC.Data[i]=temp;
							}
						}
					}
					buffer=0;
					buffer=ADC.Data[1]+ADC.Data[2];
					
					for(i=ADC.channel*4;i<3+ADC.channel*4;i++) 
					ADC.Buffer[i]=ADC.Buffer[i+1];
					ADC.Buffer[3+ADC.channel*4]=buffer/2;
					buffer=0;
					
					for(i=ADC.channel*4;i<4+ADC.channel*4;i++) buffer+=ADC.Buffer[i];
					ADC.Filter[ADC.channel]=buffer/4;
					ADC.Filter[ADC.channel]>>=4;
					
					output[ADC.channel]=ADC.Filter[ADC.channel];
						
					span[ADC.channel]=Value.SystemFullScale[ADC.channel].LWord;  
					zero[ADC.channel]=Value.SystemZeroScale[ADC.channel].LWord;

					output[ADC.channel]-=zero[ADC.channel];
					output[ADC.channel]=output[ADC.channel]/(span[ADC.channel]-zero[ADC.channel]);

					High_Scale[ADC.channel]=Value.ScaleHiLimit[ADC.channel].LWord;
					Low_Scale[ADC.channel]=Value.ScaleLoLimit[ADC.channel].LWord;
					
					output[ADC.channel]=output[ADC.channel]*(High_Scale[ADC.channel]-Low_Scale[ADC.channel])+Low_Scale[ADC.channel];
					
					Value.PV[ADC.channel]=output[ADC.channel];
					Value.PV[ADC.channel]=Value.PV[ADC.channel]+Value.PVS[ADC.channel].LWord;
					/*
					Value.PV[0]=352;
					Value.PV[1]=123;
					Value.PV[2]=153;
					*/
					if(Status.Main!=CAL_ANALOG)ADC.channel++;
					else ADC.channel = Value.Channel;
					if(ADC.channel>=ADC_CHANNEL)ADC.channel=0;
					/*--------------------------------------------------------------------------------------*/

					
					
					//Value.ScaleHiLimit[0].LWord+20
					//Value.ScaleLoLimit[0].LWord-20
					
					if(Value.PV[0]>(Value.ScaleHiLimit[0].LWord)+100  || Value.PV[0]>9999 )			{ Flag.PVHiLimit_ch1=1; Flag.PVLoLimit_ch1=0;}
					else if(Value.PV[0]<(Value.ScaleLoLimit[0].LWord-100) || Value.PV[0]<-1999 ) 	{ Flag.PVHiLimit_ch1=0; Flag.PVLoLimit_ch1=1;}
					else																		{ Flag.PVHiLimit_ch1=0; Flag.PVLoLimit_ch1=0;}
					
					if(Value.PV[1]>(Value.ScaleHiLimit[1].LWord)+100  || Value.PV[1]>9999 )			{ Flag.PVHiLimit_ch2=1; Flag.PVLoLimit_ch2=0;}
					else if(Value.PV[1]<(Value.ScaleLoLimit[1].LWord)-100 || Value.PV[1]<-1999 )	{ Flag.PVHiLimit_ch2=0; Flag.PVLoLimit_ch2=1;}
					else																		{ Flag.PVHiLimit_ch2=0; Flag.PVLoLimit_ch2=0;}
/*
					if(Value.PV[2]>(Value.ScaleHiLimit[2].LWord*10)+10)		{ Flag.PVHiLimit_ch3=1; Flag.PVLoLimit_ch3=0;}
					else if(Value.PV[2]<(Value.ScaleLoLimit[2].LWord*10))		{ Flag.PVHiLimit_ch3=0; Flag.PVLoLimit_ch3=1;}
					else													{ Flag.PVHiLimit_ch3=0; Flag.PVLoLimit_ch3=0;}
*/					
/*					
					if(Value.PV[3]>Value.ScaleHiLimit[3].LWord)		{ Flag.PVHiLimit_ch4=1;}
					else if(Value.PV[3]<Value.ScaleLoLimit[3].LWord)	{ Flag.PVLoLimit_ch4=1;}
					else											{ Flag.PVHiLimit_ch4=0; Flag.PVLoLimit_ch4=0;}
*/					

					/*--------------------------------------------------------------------------------------*/
					
#if 1
				/*	None Limit  */

					if(Value.Mode[0]==0) {_RD1 = 0;}
					if(Value.Mode[1]==0) {_RD3 = 0;}
//					if(Value.Mode[2]==0) {_RD2 = 0;}
//					if(Value.Mode[3]==0) {TPIC6B595_LATCH2(0x00);}
				//	u8 HYS_F;
				/*	High and Low Limit  */
					
					if(Value.Mode[0]==1){
						if(!_RD1){	if(Value.PV[0]>=Value.ALH[0].LWord||(Value.PV[0]<=Value.ALL[0].LWord))										{_RD1 = 1;} }
						else {		if(Value.PV[0]<(Value.ALH[0].LWord-Value.ALC[0].LWord)&&Value.PV[0]>(Value.ALL[0].LWord+Value.ALC[0].LWord))	{_RD1 = 0;} }
						}
					if(Value.Mode[1]==1){
						if(!_RD3){	if(Value.PV[1]>=Value.ALH[1].LWord||(Value.PV[1]<=Value.ALL[1].LWord))										{_RD3 = 1;} }
						else {		if(Value.PV[1]<(Value.ALH[1].LWord-Value.ALC[1].LWord)&&Value.PV[1]>(Value.ALL[1].LWord+Value.ALC[1].LWord))	{_RD3 = 0;} }
						}
					
				/*	High Limit  */

					if(Value.Mode[0]==2){
						if(!_RD1){	if(Value.PV[0]>=Value.ALH[0].LWord)					{_RD1 = 1;} }
						else {		if(Value.PV[0]<(Value.ALH[0].LWord-Value.ALC[0].LWord))	{_RD1 = 0;} }
						}
					if(Value.Mode[1]==2){
						if(!_RD3){	if(Value.PV[1]>=Value.ALH[1].LWord)					{_RD3 = 1;} }
						else {		if(Value.PV[1]<(Value.ALH[1].LWord-Value.ALC[1].LWord))	{_RD3 = 0;} }
						}

				/*	Low Limit  */

					if(Value.Mode[0]==3){
						if(!_RD1){	if(Value.PV[0]<=Value.ALL[0].LWord)						{_RD1 = 1;} }
						else {		if(Value.PV[0]>(Value.ALL[0].LWord+Value.ALC[0].LWord))	{_RD1 = 0;} }
						}
					if(Value.Mode[1]==3){
						if(!_RD3){	if(Value.PV[1]<=Value.ALL[1].LWord)					{_RD3 = 1;} }
						else {		if(Value.PV[1]>(Value.ALL[1].LWord+Value.ALC[1].LWord))	{_RD3 = 0;} }
						}
				/*	High and Low Limit range */

					if(Value.Mode[0]==4){
						if(!_RD1){	if(Value.PV[0]<=Value.ALH[0].LWord&&(Value.PV[0]>=Value.ALL[0].LWord))										{_RD1 = 1;} }
						else {		if(Value.PV[0]>(Value.ALH[0].LWord+Value.ALC[0].LWord)||Value.PV[0]<(Value.ALL[0].LWord-Value.ALC[0].LWord))	{_RD1 = 0;} }
						}
					if(Value.Mode[1]==4){
						if(!_RD3){	if(Value.PV[1]<=Value.ALH[1].LWord&&(Value.PV[1]>=Value.ALL[1].LWord))										{_RD3 = 1;} }
						else {		if(Value.PV[1]>(Value.ALH[1].LWord+Value.ALC[1].LWord)||Value.PV[1]<(Value.ALL[1].LWord-Value.ALC[1].LWord))	{_RD3 = 0;} }
						}
#endif
			
				
						}
					}
				}
			}
		}

#endif


