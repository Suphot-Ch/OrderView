#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

void eeprom_erase_word(unsigned long addr){
	__asm__ ("MOV W1,NVMADRU");	// Keep  High byte address 
	__asm__ ("MOV W0,NVMADR");	// Write data to table
	__asm__ ("MOV #0x4044,W0");	// Load comamnd
	__asm__ ("MOV W0,NVMCON");
	__asm__ ("DISI #5");
	__asm__ ("MOV #0x55,W0");		// Lanch command step 1
	__asm__ ("MOV W0,NVMKEY");
	__asm__ ("MOV #0xAA,W1");	// Lanch command step 2	
	__asm__ ("MOV W1,NVMKEY");
	_WR=SET;
	while(_WR) continue;
	_WREN=CLR;
}
void eeprom_write_word(unsigned long addr, u16 val){
	//addr+=EEPROM_OFFSET;
	__asm__ ("MOV W1,TBLPAG");	// Keep  High byte address 
	__asm__ ("TBLWTL W2,[W0]");	// Write data to table
	__asm__ ("MOV #0x4004,W0");	// Load comamnd
	__asm__ ("MOV W0,NVMCON");
	__asm__ ("DISI #5");
	__asm__ ("MOV #0x55,W0");		// Lanch command step 1
	__asm__ ("MOV W0,NVMKEY");
	__asm__ ("MOV #0xAA,W1");	// Lanch command step 2	
	__asm__ ("MOV W1,NVMKEY");
	_WR=SET;
	while(_WR) continue;
	_WREN=CLR;
}
u16 eeprom_read_word(unsigned long addr){
	//addr+=EEPROM_OFFSET;
	__asm__("MOV W1,TBLPAG");	// Keep  High byte address 
	__asm__("TBLRDL [W0],W4");	// Load data into W4	
	return(WREG4);
}
void write_eeprom_word(unsigned long addr, u16* val, u8 word){
	u8 i;
	addr+=EEPROM_OFFSET;
	for(i=0;i<word;i++){
		eeprom_erase_word(addr+(i*2));
		eeprom_write_word(addr+(i*2), *val++);
		}
}
void write_eeprom(unsigned long addr, u16 val){
	addr+=EEPROM_OFFSET;
	eeprom_erase_word(addr);
	eeprom_write_word(addr, val);
}
u16 read_eeprom(unsigned long addr){
	u16 val;
	addr+=EEPROM_OFFSET;
	val=eeprom_read_word(addr);
	return val;
}
void write_eeprom_16(unsigned long addr, s16 *val){
	write_eeprom(addr + 0, *val);
}
void read_eeprom_16(unsigned long addr, s16 *val){
	*val = read_eeprom(addr);
}
void write_eeprom_32(unsigned long addr, s32 *val){
	LWord_sType Vl;
	Vl.LWord = *val;
	write_eeprom(addr + 0, Vl.WordHi);
	write_eeprom(addr + 2, Vl.WordLo);
}
void read_eeprom_32(unsigned long addr, s32 *val){
	LWord_sType Vl;
	Vl.WordHi = read_eeprom(addr + 0);
	Vl.WordLo = read_eeprom(addr + 2);
	*val = Vl.LWord;
}

