#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

//IR_sType IrData;
s8 IR_SW;
void BUTTON_SET_TIME_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_SetTime();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_DSP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_POWER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			idle_mode();
			break;
		case IDLE_MODE:
			operate_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OP_MODE_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_SetPGrandC();
			break;
		default:
			break;
	}
}
void BUTTON_ADD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_slave_address_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OSD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_SIGN_event(void){
	switch(Status.Main){
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_BALANCE:
		case EDIT_TACTTIME:
			Flag.Sign=Flag.Sign? 0 : 1;
			if(Flag.Sign&&EditBuffer[0]>1){
				EditBuffer[0]=1;
				EditBuffer[1]=9;
				EditBuffer[2]=9;
				EditBuffer[3]=9;
				EditBuffer[4]=9;
				EditBuffer[5]=9;
				}
			break;
		default:
			break;
	}
}
void BUTTON_F1_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_GradeA();
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_PLUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Mul_mode();
			break;
		case EDIT_TIMERESET:
			if(++Value.ResetMode>=8)Value.ResetMode = 0;
			write_eeprom(EEP_TIMERESET_M, Value.ResetMode);
			break;
		case EDIT_BREAK_EN:
			if(Flag.Edit)Value.Break_EN = 1;
			write_eeprom(EEP_TIME_EN, Value.Break_EN);
			break;
		case EDIT_BREAK_OFF:
			if(++Value.Break_Channel>=10)Value.Break_Channel = 0;
			edit_Break_OFF(Value.Break_Channel);
			break;
		case EDIT_BREAK_ON:
			if(++Value.Break_Channel>=10)Value.Break_Channel = 0;
			edit_Break_ON(Value.Break_Channel);
			break;
		default:
			break;
	}
}
void BUTTON_VOL_PLUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		case 2:
			break;
		case EDIT_BREAK_OFF:
			break;
		case EDIT_BREAK_ON:
			break;
		case EDIT_SETTIME:
			break;
		case EDIT_TIMERESET:
			break;
		default:
			break;
	}
}
void BUTTON_F2_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_GradeC();
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_MINUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Div_mode();
			break;
		case EDIT_TIMERESET:
			if(--Value.ResetMode>=8)Value.ResetMode = 7;
			write_eeprom(EEP_TIMERESET_M, Value.ResetMode);
			break;
		case EDIT_BREAK_EN:
			if(Flag.Edit)Value.Break_EN = 0;
			write_eeprom(EEP_TIME_EN, Value.Break_EN);
			break;
		case EDIT_BREAK_OFF:
			if(--Value.Break_Channel>=10)Value.Break_Channel = 9;
			edit_Break_OFF(Value.Break_Channel);
			break;
		case EDIT_BREAK_ON:
			if(--Value.Break_Channel>=10)Value.Break_Channel = 9;
			edit_Break_ON(Value.Break_Channel);
			break;
		default:
			break;
	}
}
void BUTTON_VOL_MINUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		case 2:
			break;
		case EDIT_BREAK_OFF:
			break;
		case EDIT_BREAK_ON:
			break;
		case EDIT_SETTIME:
			break;
		case EDIT_TIMERESET:
			break;
		default:
			break;
	}
}
void BUTTON_F3_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
		//	if(Value.StatusTact == 1){
		//		Value.StatusTact = 0;
		//		Flag.Blink = 0;
		//		}
		//	else {
		//		Value.StatusTact = 1;
		//		}
			
			break;
		default:
			break;
	}
}
void BUTTON_CANCEL_event(void){
	switch(Status.Main){
		case EDIT_DP_MODE:
		case EDIT_ADDRESS_MODE:
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
		case EDIT_DELAY_POLLS_MODE:
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_BALANCE:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTIME:
			operate_mode();
			break;
		case OPERATE_MODE:
//			edit_delay_polls_mode();
			break;
		case 2:
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_ENTER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		case CAL_ANALOG_MODE:
			if(!Flag.Edit) break;
			Flag.Edit=0;
			save();
			if(!Flag.CalPoint){
				Flag.CalPoint=1;
			}
			else{
				operate_mode();
			}
			edit_slave_address_mode();
			break;
		case EDIT_ADDRESS_MODE:
			if(reload_edit_buffer_4digit()<=240){
				Value.SlaveAddress=reload_edit_buffer_4digit();
				save();
				operate_mode();
				}
			break;
		case EDIT_BAUDRATE_MODE:
			if(reload_edit_buffer_4digit()>=BR4800&&reload_edit_buffer_4digit()<=BR57600){
				Value.Baudrate=reload_edit_buffer_4digit();
				uart2_init();
				save();
				operate_mode();
				}
			break;
		case EDIT_PARITY_MODE:
			if(reload_edit_buffer_4digit()>=b8n1&&reload_edit_buffer_4digit()<=b8e1){
				Value.Parity=reload_edit_buffer_4digit();
				uart2_init();
				save();
				operate_mode();
				}
			break;
		case EDIT_TARGET:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()<=9999&&reload_edit_buffer()>=-1999){
					Value.GradeA=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_ACTUAL:
			if(!Flag.Edit){
				Flag.Edit=1;
				}
			else {
				if(reload_edit_buffer()<=9999&&reload_edit_buffer()>=-1999){
					Value.GradeC=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_TACTTIME:
			if(!Flag.Edit){
				Flag.Edit=1;
				}
			else {
				if(reload_edit_buffer()<=9999&&reload_edit_buffer()>=0){
					Value.PGrandC=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_MUL_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=1000&&reload_edit_buffer()>=1){
					Value.Multiplier=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_DIV_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=2500&&reload_edit_buffer()>=1){
					Value.Divisor=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_SETTACTTIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=0){
					Value.SetPGrandC= reload_edit_buffer();
					save();
					EditNum = 0;
					Flag.Edit = 0;
					}
				}
			break;
		case EDIT_INPUT_DELAY:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=0){
					Value.InputDelay= reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_CYCLETIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=0){
					Value.CycleTime=reload_edit_buffer();
					save();
					EditNum = 0;
					Flag.Edit = 0;
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_SETTIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				edit_GetTime();
				operate_mode();
				}
			break;
		case EDIT_BREAK_EN:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				write_eeprom(EEP_TIME_EN, Value.Break_EN);
				EditNum = 0;
				Flag.Edit = 0;
				}
			break;
		case EDIT_BREAK_OFF:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeOFF(Value.Break_Channel);
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;			
		case EDIT_BREAK_ON:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeON(Value.Break_Channel);
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;
		case EDIT_TIMERESET:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeRESET();
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_F4_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			//edit_PGrandC();
			break;
		default:
			break;
	}
}
void BUTTON_MENU_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
		//	edit_Break_EN();
			break;
		case EDIT_BREAK_EN:
			Value.Break_Channel = 0;
			edit_Break_ON(Value.Break_Channel);
			break;
		case EDIT_BREAK_ON:
			Value.Break_Channel = 0;
			edit_Break_OFF(Value.Break_Channel);
			break;
		case EDIT_BREAK_OFF:
			edit_TimeRESET();
			break;
		case EDIT_TIMERESET:
			edit_CycleTime();
			break;
		case EDIT_CYCLETIME:
			edit_SetPGrandC();
			break;
		case EDIT_SETTACTTIME:
			edit_Break_EN();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_DP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			if(++Value.DecimalPoint>=4)Value.DecimalPoint=0;
			write_eeprom(EEP_DP, (u16)Value.DecimalPoint);
			break;
		default:
			break;
	}
}

void Button_Time(u8 ID){
	
	switch(EditNum){
		case 1:
			if(ID>=0&&ID<=2){
				EditBuffer[0] = ID;
				EditNum++;
				}
			break;
		case 2:
			if(EditBuffer[0]<2&&ID>=0&&ID<=9){
				EditBuffer[1] = ID;
				EditNum++;
				}
			else if(EditBuffer[0]==2&&ID>=0&&ID<=4){
				EditBuffer[1] = ID;
				EditNum++;
				}
			break;
		case 3:
			if(ID>=0&&ID<=5){
				EditBuffer[2] = ID;
				EditNum++;
				}
			break;
		case 4:
			if(ID>=0&&ID<=9){
				EditBuffer[3] = ID;
				EditNum=1;
				}
			break;
		default:
			break;
		}
}
void Button_Date(u8 ID){
	switch(EditNum){
		case 0:
			if(ID>=0&&ID<=3){
				EditBuffer[0] = ID;
				EditNum++;
				}
			break;
		case 1:
			if(EditBuffer[0]<3&&ID>=0&&ID<=9){
				EditBuffer[1] = ID;
				EditNum++;
				}
			else if(EditBuffer[0]==3&&ID>=0&&ID<=1){
				EditBuffer[1] = ID;
				EditNum++;
				}
			break;
		case 2:
			if(ID>=0&&ID<=1){
				EditBuffer[2] = ID;
				EditNum++;
				}
			break;
		case 3:
			if(EditBuffer[2]<1&&ID>=1&&ID<=9){
				EditBuffer[3] = ID;
				EditNum++;
				}
			else if(EditBuffer[2]==1&&ID>=1&&ID<=2){
				EditBuffer[3] = ID;
				EditNum++;
				}
			break;
		case 4:
			if(ID>=0&&ID<=9){
				EditBuffer[4] = ID;
				EditNum++;
				}
			break;
		case 5:
			if(ID>=0&&ID<=9){
				EditBuffer[5] = ID;
				EditNum++;
				}
			break;
		default:
			break;
		}
}
void Button_edit3(u8 ID){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
			}
			EditBuffer[3]=ID;
			EditNum++;
			break;
		default:
			break;
		}
}
void Button_edit4(u8 ID){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
		case 4:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
			}
			EditBuffer[3]=ID;
			EditNum++;
			break;
		default:
			break;
		}
}
void Button_edit5(u8 ID){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
				EditBuffer[3]=0;
				EditBuffer[4]=0;
			}
			EditBuffer[5]=ID;
			EditNum++;
			break;
		default:
			break;
		}
}
void Button_edit6(u8 ID){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
				EditBuffer[3]=0;
				EditBuffer[4]=0;
			}
			EditBuffer[5]=ID;
			EditNum++;
			break;
		default:
			break;
		}
}
void BUTTON_0_event(void){
	IR_SW=0;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_1_event(void){
	IR_SW=1;
	switch(Status.Main){
		case OPERATE_MODE:
			edit_baudrate_mode();
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_2_event(void){	
	IR_SW=2;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_3_event(void){	
	IR_SW=3;
	switch(Status.Main){
		case OPERATE_MODE:
			edit_parity_mode();
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_4_event(void){	
	IR_SW=4;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			edit_Input_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_5_event(void){	
	IR_SW=5;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_6_event(void){	
	IR_SW=6;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_7_event(void){	
	IR_SW=7;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_8_event(void){	
	IR_SW=8;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_9_event(void){	
	IR_SW=9;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			Button_edit3(IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_TARGET:
		case EDIT_ACTUAL:
		case EDIT_TACTTIME:
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_edit4(IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void ir_decode(void){
	u8 i;
	/*insert code here for active*/
	if(Flag.IrDecode){
		if(++IrData.TimeOut>=TIME20mSEC){
			IrData.TimeOut=CLR;
			if(IrData.ByteCount==11){
				//Flag.IrDecode=CLR;	
				IrData.Decode=CLR;
				for(i=0;i<IrData.ByteCount;i++){
					if(IrData.Buffer[i]>=IrDataLogic_0) IrData.Decode+=1;
					IrData.Decode=IrData.Decode<<1;
				}
				if(IrData.Decode!=IrData.DecodeLast){
					IrData.DecodeLast=IrData.Decode;
					TimeBlink = 0;
					Flag.Blink = 0;
					switch(IrData.Decode){
						case BUTTON_A1:
							BUTTON_SET_TIME_event();
							break;
						case BUTTON_A2:
							BUTTON_DSP_event();
							break;
						case BUTTON_A3:
							BUTTON_POWER_event();
							break;
						case BUTTON_A4:
							BUTTON_OP_MODE_event();
							break;
						case BUTTON_A5:
							BUTTON_ADD_event();
							break;
						case BUTTON_A6:
							BUTTON_OSD_event();
							break;
						case BUTTON_A7:
							BUTTON_SIGN_event();
							break;
						case BUTTON_A8:
							BUTTON_F1_event();
							break;
						case BUTTON_A9:
							BUTTON_SCALE_PLUS_event();
							break;
						case BUTTON_A10:
							BUTTON_VOL_PLUS_event();
							break;
						case BUTTON_A11:
							BUTTON_F2_event();
							break;
						case BUTTON_A12:
							BUTTON_SCALE_MINUS_event();
							break;
						case BUTTON_A13:
							BUTTON_VOL_MINUS_event();
							break;
						case BUTTON_A14:
							BUTTON_F3_event();
							break;
						case BUTTON_A15:
							BUTTON_CANCEL_event();
							break;
						case BUTTON_A16:
							BUTTON_ENTER_event();
							break;
						case BUTTON_A17:
							BUTTON_F4_event();
							break;
						case BUTTON_A18:
							BUTTON_MENU_event();
							break;
						case BUTTON_A19:
							BUTTON_DP_event();
							break;
						case BUTTON_0:
							Flag.Sign=0;
							BUTTON_0_event();
							break;
						case BUTTON_1:
							Flag.Sign=0;
							BUTTON_1_event();
							break;
						case BUTTON_2:
							Flag.Sign=0;
							BUTTON_2_event();
							break;
						case BUTTON_3:
							Flag.Sign=0;
							BUTTON_3_event();
							break;
						case BUTTON_4:
							Flag.Sign=0;
							BUTTON_4_event();
							break;
						case BUTTON_5:
							Flag.Sign=0;
							BUTTON_5_event();
							break;
						case BUTTON_6:
							Flag.Sign=0;
							BUTTON_6_event();
							break;
						case BUTTON_7:
							Flag.Sign=0;
							BUTTON_7_event();
							break;
						case BUTTON_8:
							Flag.Sign=0;
							BUTTON_8_event();
							break;
						case BUTTON_9:
							Flag.Sign=0;
							BUTTON_9_event();
							break;
						default:
							break;
					}
				}
			}
			IrData.Status=CLR;
			Flag.IrDecode=CLR;	
			IrData.ByteCount=CLR;
		}
	}
	else{
		if(++IrData.TimeOut>=5){
			IrData.TimeOut=CLR;
			IrData.Decode=CLR;
			IrData.DecodeLast=CLR;
		}
	}
}
