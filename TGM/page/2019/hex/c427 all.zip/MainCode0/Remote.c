#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

//IR_sType IrData;
s8 IR_SW;
void BUTTON_SET_TIME_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_SetTime();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_DSP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_POWER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			idle_mode();
			break;
		case IDLE_MODE:
			operate_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OP_MODE_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_SetTactTime();
			
			edit_SetPoint1();
			break;
		case EDIT_ALS_MODE:
//			if(Value.Channel == 0)
//				edit_SetPoint2();
//			else
//				edit_SetPoint1();
			break;
		default:
			break;
	}
}
void BUTTON_ADD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_slave_address_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OSD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_parity_mode();
			break;
		default:
			break;
	}
}
void BUTTON_SIGN_event(void){
	switch(Status.Main){
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
		case EDIT_INPUT_TYPE:
		case EDIT_CIRCUMFERENCE:
			Flag.Sign=Flag.Sign? 0 : 1;
			if(Flag.Sign&&EditBuffer[0]>1){
				EditBuffer[0]=1;
				EditBuffer[1]=9;
				EditBuffer[2]=9;
				EditBuffer[3]=9;
				EditBuffer[4]=9;
				EditBuffer[5]=9;
				}
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_PLUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			Value.Channel = 0;
			edit_Mul_mode();
			break;
//		case EDIT_MUL_MODE:
//			if(++Value.Channel>=4)Value.Channel = 0;
//			edit_Mul_mode();
//			break;
		default:
			break;
	}
}
void BUTTON_SCALE_MINUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			Value.Channel = 0;
			edit_Div_mode();
			break;
//		case EDIT_DIV_MODE:
//			if(++Value.Channel>=4)Value.Channel = 0;
//			edit_Div_mode();
//			break;
		default:
			break;
	}
}
void BUTTON_VOL_PLUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			if(Value.Actual1<SEG_LIMITMAX){
				Value.Actual1 += 1;
				write_ram(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//				write_eeprom(EEP_ACTUAL1, Value.Actual1);
			}
			break;
		case EDIT_ALS_MODE:
//			if(Flag.Edit) return;
//			if(Value.Channel == 0){
//				if(Value.SetPointMode1<2)Value.SetPointMode1++;
//				}
//			else{
//				if(Value.SetPointMode2<2)Value.SetPointMode2++;
//				}
			break;
		case EDIT_CIRCUMFERENCE:
			break;
		case EDIT_BREAK_OFF:
			break;
		case EDIT_BREAK_ON:
			break;
		case EDIT_SETTIME:
			break;
		case EDIT_TIMERESET:
			break;
		default:
			break;
	}
}
void BUTTON_VOL_MINUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			if(Value.Actual1>SEG_LIMITMIN){
				Value.Actual1 -= 1;
				write_ram(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//				write_eeprom(EEP_ACTUAL1, Value.Actual1);
			}
			break;
		case EDIT_ALS_MODE:
//			if(Flag.Edit) return;
//			if(Value.Channel == 0){
//				if(Value.SetPointMode1>0)Value.SetPointMode1--;
//				}
//			else{
//				if(Value.SetPointMode2>0)Value.SetPointMode2--;
//				}
			break;
		case EDIT_CIRCUMFERENCE:
			break;
		case EDIT_BREAK_OFF:
			break;
		case EDIT_BREAK_ON:
			break;
		case EDIT_SETTIME:
			break;
		case EDIT_TIMERESET:
			break;
		default:
			break;
	}
}
void BUTTON_F1_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Target();
			break;
		default:
			break;
	}
}
void BUTTON_F2_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Actual1();
			break;
		default:
			break;
	}
}
void BUTTON_F3_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			edit_Actual2();
			EDIT_CIRCUMFERENCE_mode();
			break;
		default:
			break;
	}
}
void BUTTON_F4_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			EDIT_INPUT_TYPE();
			edit_CycleTimeTarget();
			break;
		default:
			break;
	}
}
void BUTTON_CANCEL_event(void){
	switch(Status.Main){
		case EDIT_DP_MODE:
		case EDIT_ADDRESS_MODE:
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
		case EDIT_DELAY_POLLS_MODE:
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
		case EDIT_INPUT_TYPE:
		case EDIT_CIRCUMFERENCE:
		case EDIT_CYCLETIME:
		case EDIT_SETTIME:
			operate_mode();
			break;
		case OPERATE_MODE:
//			edit_delay_polls_mode();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_ENTER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		case CAL_ANALOG_MODE:
			if(!Flag.Edit) break;
			Flag.Edit=0;
			save();
			if(!Flag.CalPoint){
				Flag.CalPoint=1;
			}
			else{
			}
			edit_slave_address_mode();
			break;
		case EDIT_ADDRESS_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer_4digit()<=240){
					Value.SlaveAddress=reload_edit_buffer_4digit();
					save();
					operate_mode();
					}
				}
			break;
		case EDIT_BAUDRATE_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer_4digit()>=BR4800&&reload_edit_buffer_4digit()<=BR57600){
					Value.Baudrate=reload_edit_buffer_4digit();
					uart2_init();
					save();
					operate_mode();
					}
				}
			break;
		case EDIT_PARITY_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer_4digit()>=b8n1&&reload_edit_buffer_4digit()<=b8e1){
					Value.Parity=reload_edit_buffer_4digit();
					uart2_init();
					save();
					operate_mode();
					}
				}
			break;
		case EDIT_TARGET:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()<=SEG_LIMITMAX&&reload_edit_buffer()>=SEG_LIMITMIN){
					Value.Target= reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_ACTUAL1:
			if(!Flag.Edit){
				Flag.Edit=1;
				}
			else {
				if(reload_edit_buffer()<=SEG_LIMITMAX&&reload_edit_buffer()>=SEG_LIMITMIN){
					Value.Actual1=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_INPUT_TYPE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()<=1&&reload_edit_buffer()>=0){
					Value.InputType = reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_CIRCUMFERENCE:
			if(!Flag.Edit){
				Flag.Edit=1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=1){
					Value.CircumFerence=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_MUL_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if((reload_edit_buffer()<=10000&&reload_edit_buffer()>=1)&&reload_edit_buffer()<=SEG_LIMITMAX){
					Value.Multiplier1=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_DIV_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if((reload_edit_buffer()<=25000&&reload_edit_buffer()>=1)&&reload_edit_buffer()<=SEG_LIMITMAX){
					Value.Divisor1=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=SEG_LIMITMAX&&reload_edit_buffer()>=SEG_LIMITMIN){
					if(Value.Channel == 0)	 Value.SetPoint1 = reload_edit_buffer();
					else	if(Value.Channel == 1)	 Value.SetPoint2 = reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_SETTACTTIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=0){
					Value.SetTactTime= reload_edit_buffer();
					save();
					EditNum = 0;
					Flag.Edit = 0;
					}
				}
			break;
		case EDIT_INPUT_DELAY:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=1){
					Value.InputDelay= reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_CYCLETIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=6000&&reload_edit_buffer()>=0){
					if(Value.Channel == 0)	{
						Value.CycleTimeTarget = reload_edit_buffer();
						save();
						operate_mode();
						}
					else if(Value.Channel == 1){
						Value.CycleTimeTarget = reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_SETTIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				edit_GetTime();
				operate_mode();
				}
			break;
		case EDIT_BREAK_EN:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				write_eeprom(EEP_TIME_EN, Value.Break_EN);
				EditNum = 0;
				Flag.Edit = 0;
				}
			break;
		case EDIT_BREAK_OFF:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeOFF(Value.Break_Channel);
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;			
		case EDIT_BREAK_ON:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeON(Value.Break_Channel);
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;
		case EDIT_TIMERESET:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Reload_TimeRESET();
					EditNum = 0;
					Flag.Edit = 0;
				}
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_MENU_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			//edit_Break_EN();
			//Status.Main = EDIT_CIRCUMFERENCE;
			//Flag.Edit = 0;
			break;
		case EDIT_BREAK_EN:
			Value.Break_Channel = 0;
			edit_Break_ON(Value.Break_Channel);
			break;
		case EDIT_BREAK_ON:
			Value.Break_Channel = 0;
			edit_Break_OFF(Value.Break_Channel);
			break;
		case EDIT_BREAK_OFF:
			edit_TimeRESET();
			break;
		case EDIT_TIMERESET:
			edit_CycleTimeTotal();
			break;
		case EDIT_CYCLETIME:
			edit_SetTactTime();
			break;
		case EDIT_SETTACTTIME:
			edit_Break_EN();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}

void BUTTON_DP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			if(++Value.DecimalPoint>=EDIT_LENGTH)Value.DecimalPoint=0;
			write_eeprom(EEP_DP, (u16)Value.DecimalPoint);
			break;
		default:
			break;
	}
}

void Button_Time(u8 ID){
	
	switch(EditNum){
		case 1:
			if(ID>=0&&ID<=2){
				EditBuffer[0] = ID;
				EditNum++;
				}
			break;
		case 2:
			if(EditBuffer[0]==2){
				if(Status.Main!=EDIT_SETTIME){
					if(ID>=0&&ID<=3){
						EditBuffer[1] = ID;
						EditNum++;
						}
					}
				else{
					if(ID>=0&&ID<=4){
						EditBuffer[1] = ID;
						EditNum++;
						}
					}
				}
			else{
				EditBuffer[1] = ID;
				EditNum++;
				}
			break;
		case 3:
			if(EditBuffer[0]==2 && EditBuffer[1]==4){
				EditBuffer[2] = 0;
				EditNum++;
				}
			else{
				if(ID>=0&&ID<=5){
					EditBuffer[2] = ID;
					EditNum++;
					}
				}
			break;
		case 4:
			if(EditBuffer[0]==2 && EditBuffer[1]==4){
				EditBuffer[2] = 0;
				EditNum++;
				}
			else{
				if(ID>=0&&ID<=9){
					EditBuffer[3] = ID;
					EditNum=1;
					}
				}
			break;
		default:
			break;
		}
}
void Button_Date(u8 ID){
	switch(EditNum){
		case 0:
			if(ID>=0&&ID<=3){
				EditBuffer[0] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		case 1:
			if(EditBuffer[0]<3&&ID>=0&&ID<=9){
				EditBuffer[1] = ID;
				EditNum++;
				}
			else if(EditBuffer[0]==3&&ID>=0&&ID<=1){
				EditBuffer[1] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		case 2:
			if(ID>=0&&ID<=1){
				EditBuffer[2] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		case 3:
			if(EditBuffer[2]<1&&ID>=1&&ID<=9){
				EditBuffer[3] = ID;
				EditNum++;
				}
			else if(EditBuffer[2]==1&&ID>=1&&ID<=2){
				EditBuffer[3] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		case 4:
			if(ID>=0&&ID<=9){
				EditBuffer[4] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		case 5:
			if(ID>=0&&ID<=9){
				EditBuffer[5] = ID;
				EditNum++;
				}
			Flag.Blink = 1;
			TimeBlink = 0;
			break;
		default:
			break;
		}
}
void BUTTON_event_edit(u8 length, u8 IR){
	u8 i;
	if(EditNum>=1&&EditNum<=length){
		if(EditNum!=1){
			shift_edit_buffer();
		}
		else{
			for(i=0;i<EDIT_LENGTH-1;i++)
				EditBuffer[i]=0;
			Flag.Sign = 0;
		}
		EditBuffer[EDIT_LENGTH-1]=IR_SW;
		if(!EditBuffer[EDIT_LENGTH-1]&&EditNum==1) return;
		EditNum++;
	}
}
void BUTTON_0_event(void){
	IR_SW=0;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
		case EDIT_INPUT_TYPE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_1_event(void){
	IR_SW=1;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
		case EDIT_INPUT_TYPE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_2_event(void){	
	IR_SW=2;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			edit_InputType_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_3_event(void){	
	IR_SW=3;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_4_event(void){	
	IR_SW=4;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			edit_InputDelay_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_5_event(void){	
	IR_SW=5;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_6_event(void){	
	IR_SW=6;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_7_event(void){	
	IR_SW=7;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_8_event(void){	
	IR_SW=8;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_9_event(void){	
	IR_SW=9;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_BAUDRATE_MODE:
			EditBuffer[EDIT_LENGTH-1]=IR_SW;
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1: 
			if(Flag.Edit){
				BUTTON_event_edit(EDIT_LENGTH,IR_SW);
				}
			break;
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_SETTACTTIME:
		case EDIT_DP_MODE:
		case EDIT_INPUT_DELAY:
		case EDIT_CIRCUMFERENCE:
			if(Flag.Edit){
				BUTTON_event_edit(4,IR_SW);
				}
			break;
		case EDIT_SETTIME:
		case EDIT_BREAK_OFF:
		case EDIT_BREAK_ON:
		case EDIT_TIMERESET:
			if(Flag.Edit){
				Button_Time(IR_SW);
				}
			break; 
		default:
			break;
	}
}
void ir_decode(void){
	u8 i;
	/*insert code here for active*/
	if(Flag.IrDecode){
		if(++IrData.TimeOut>=TIME20mSEC){
			IrData.TimeOut=CLR;
			if(IrData.ByteCount==11){
				//Flag.IrDecode=CLR;	
				IrData.Decode=CLR;
				for(i=0;i<IrData.ByteCount;i++){
					if(IrData.Buffer[i]>=IrDataLogic_0) IrData.Decode+=1;
					IrData.Decode=IrData.Decode<<1;
				}
				if(IrData.Decode!=IrData.DecodeLast){
					IrData.DecodeLast=IrData.Decode;
					TimeBlink = 0;
					Flag.Blink = 0;
					switch(IrData.Decode){
						case BUTTON_SET_TIME:
							BUTTON_SET_TIME_event();
							break;
						case BUTTON_DSP:
							BUTTON_DSP_event();
							break;
						case BUTTON_POWER:
							BUTTON_POWER_event();
							break;
						case BUTTON_OP_MODE:
							BUTTON_OP_MODE_event();
							break;
						case BUTTON_ADD:
							BUTTON_ADD_event();
							break;
						case BUTTON_OSD:
							BUTTON_OSD_event();
							break;
						case BUTTON_SIGN:
							BUTTON_SIGN_event();
							break;
						case BUTTON_F1:
							BUTTON_F1_event();
							break;
						case BUTTON_F2:
							BUTTON_F2_event();
							break;
						case BUTTON_F3:
							BUTTON_F3_event();
							break;
						case BUTTON_F4:
							BUTTON_F4_event();
							break;
						case BUTTON_SCALE_PLUS:
							BUTTON_SCALE_PLUS_event();
							break;
						case BUTTON_SCALE_MINUS:
							BUTTON_SCALE_MINUS_event();
							break;
						case BUTTON_VOL_PLUS:
							BUTTON_VOL_PLUS_event();
							break;
						case BUTTON_VOL_MINUS:
							BUTTON_VOL_MINUS_event();
							break;
						case BUTTON_ENTER:
							BUTTON_ENTER_event();
							break;
						case BUTTON_MENU:
							BUTTON_MENU_event();
							break;
						case BUTTON_CANCEL:
							BUTTON_CANCEL_event();
							break;
						case BUTTON_DP:
							BUTTON_DP_event();
							break;
						case BUTTON_0:
							BUTTON_0_event();
							break;
						case BUTTON_1:
							BUTTON_1_event();
							break;
						case BUTTON_2:
							BUTTON_2_event();
							break;
						case BUTTON_3:
							BUTTON_3_event();
							break;
						case BUTTON_4:
							BUTTON_4_event();
							break;
						case BUTTON_5:
							BUTTON_5_event();
							break;
						case BUTTON_6:
							BUTTON_6_event();
							break;
						case BUTTON_7:
							BUTTON_7_event();
							break;
						case BUTTON_8:
							BUTTON_8_event();
							break;
						case BUTTON_9:
							BUTTON_9_event();
							break;
						default:
							break;
					}
				}
			}
			IrData.Status=CLR;
			Flag.IrDecode=CLR;	
			IrData.ByteCount=CLR;
		}
	}
	else{
		if(++IrData.TimeOut>=5){
			IrData.TimeOut=CLR;
			IrData.Decode=CLR;
			IrData.DecodeLast=CLR;
		}
	}
}
