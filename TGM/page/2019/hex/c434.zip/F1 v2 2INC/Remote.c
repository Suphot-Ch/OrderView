#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

//IR_sType IrData;
s8 IR_SW;
void BUTTON_SET_TIME_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_SetTime();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_DSP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_POWER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Ide_mode();
			break;
		case IDLE_MODE:
			operate_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OP_MODE_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			// edit_InpurType_mode();
			edit_SetPoint1();
			break;
		case EDIT_ALS_MODE:
//			if(Value.Channel == 0)
//				edit_SetPoint2();
//			else
//				edit_SetPoint1();
			break;
		default:
			break;
	}
}
void BUTTON_ADD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_slave_address_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OSD_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			// edit_parity_mode();
			break;
		default:
			break;
	}
}
void BUTTON_SIGN_event(void){
	switch(Status.Main){
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
		case EDIT_CHARTMENU_MODE:
		case EDIT_CHARTVALUE_MODE:
			Flag.Sign=Flag.Sign? 0 : 1;
			if(Flag.Sign&&EditBuffer[0]>1){
				EditBuffer[0]=1;
				EditBuffer[1]=9;
				EditBuffer[2]=9;
				EditBuffer[3]=9;
				EditBuffer[4]=9;
				EditBuffer[5]=9;
				}
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_PLUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			Value.Channel = 0;
			edit_Mul_mode();
			break;
		case EDIT_CHARTVALUE_MODE:
			if(++EditNum > 8) EditNum = 1;
			if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x20 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x3F)
				EditSet = 0x20;
			else if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x40 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x5F)
				EditSet = 0x40;
			else if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x60 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x7E)
				EditSet = 0x60;
			break;
//		case EDIT_MUL_MODE:
//			if(++Value.Channel>=4)Value.Channel = 0;
//			edit_Mul_mode();
//			break;
		default:
			break;
	}
}
void BUTTON_SCALE_MINUS_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			Value.Channel = 0;
			edit_Div_mode();
			break;
		case EDIT_CHARTVALUE_MODE:
			if(--EditNum < 1) EditNum = 8;
			if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x20 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x3F)
				EditSet = 0x20;
			else if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x40 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x5F)
				EditSet = 0x40;
			else if(EditcharBuffer[MATRIX_LENGTH - EditNum] >= 0x60 && EditcharBuffer[MATRIX_LENGTH - EditNum] <= 0x7E)
				EditSet = 0x60;
			break;
//		case EDIT_DIV_MODE:
//			if(++Value.Channel>=4)Value.Channel = 0;
//			edit_Div_mode();
//			break;
		default:
			break;
	}
}
void BUTTON_VOL_PLUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			if(Value.Actual1<SEG_LIMITMAX){
				Value.Actual1 += 1;
				write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//				write_eeprom(EEP_ACTUAL1, Value.Actual1);
			}
			break;
		case EDIT_ALS_MODE:
			edit_SetPoint1();
			break;
		case EDIT_INPUT_TYPE:
			EditBuffer[EDIT_LENGTH-1] = 0;
			break;
		case EDIT_TIMEMENU_MODE:
			if(++EditBuffer[EDIT_LENGTH -1]>=6)EditBuffer[EDIT_LENGTH -1]=0;
			break;
		case EDIT_TIMEEN_MODE:
			EditBuffer[EDIT_LENGTH -1] = !EditBuffer[EDIT_LENGTH -1]? 1 : 0;
			break;
		case EDIT_TIMEON_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel+1)>9? 0 : Value.Channel+1;
				edit_Time_ON_mode(Value.Channel);
			}
			else
				EditNum = (EditNum+1)>4? 1 : EditNum+1;
			break;
		case EDIT_TIMEOFF_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel+1)>9? 0 : Value.Channel+1;
				edit_Time_OFF_mode(Value.Channel);
			}
			else
				EditNum = (EditNum+1)>4? 1 : EditNum+1;
			break;
		case EDIT_TIMERESET_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel+1)>9? 0 : Value.Channel+1;
				edit_Time_RESET_mode(Value.Channel);
			}
			else
				EditNum = (EditNum+1)>4? 1 : EditNum+1;
			break;
		case EDIT_SUMTIME_MODE:
			if(!Flag.Edit){
				EditBuffer[EDIT_LENGTH-1] = 0;
			}
			break;
		case EDIT_DOWNTIME_MODE:
			if(!Flag.Edit){
				EditBuffer[EDIT_LENGTH-1] = 0;
			}
			break;
		case EDIT_SETTIME:
			edit_SetDate();
			break;
		case EDIT_SETDATE:
			edit_SetTime();
			break;
		case EDIT_DP_MODE:
			if(++EditBuffer[EDIT_LENGTH-1]>=EDIT_LENGTH)EditBuffer[EDIT_LENGTH-1] = 0;
			break;
		case EDIT_BAUDRATE_MODE:
			if(++EditBuffer[EDIT_LENGTH-1]>=5)EditBuffer[EDIT_LENGTH-1] = 0;
			break;
		case EDIT_PARITY_MODE:
			if(++EditBuffer[EDIT_LENGTH-1]>=3)EditBuffer[EDIT_LENGTH-1] = 0;
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit)return;
			if(++EditcharBuffer[MATRIX_LENGTH-EditNum] > EditSet+0x1F)
				EditcharBuffer[MATRIX_LENGTH-EditNum] = EditSet;
			break;
		default:
			break;
	}
}
void BUTTON_VOL_MINUS_event(void){
//	if(Flag.Edit) return;
	switch(Status.Main){
		case OPERATE_MODE:
			if(Value.Actual1>SEG_LIMITMIN){
				Value.Actual1 -= 1;
				write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//				write_eeprom(EEP_ACTUAL1, Value.Actual1);
			}
			break;
		case EDIT_ALS_MODE:
			edit_SetPoint2();
			break;
		case EDIT_INPUT_TYPE:
			EditBuffer[EDIT_LENGTH-1] = 1;
			break;
		case EDIT_TIMEMENU_MODE:
			if(--EditBuffer[EDIT_LENGTH -1]>=6)EditBuffer[EDIT_LENGTH -1]=5;
			break;
		case EDIT_TIMEEN_MODE:
			EditBuffer[EDIT_LENGTH -1] = !EditBuffer[EDIT_LENGTH -1]? 1 : 0;
			break;
		case EDIT_TIMEON_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel - 1)<0? 9 : Value.Channel - 1;
				edit_Time_ON_mode(Value.Channel);
			}
			else			
				EditNum = (EditNum - 1)<1? 4 : EditNum - 1;
			break;
		case EDIT_TIMEOFF_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel - 1)<0? 9 : Value.Channel - 1;
				edit_Time_OFF_mode(Value.Channel);
			}
			else			
				EditNum = (EditNum - 1)<1? 4 : EditNum - 1;
			break;
		case EDIT_TIMERESET_MODE:
			if(!Flag.Edit){
				Value.Channel = (Value.Channel - 1)<0? 9 : Value.Channel - 1;
				edit_Time_RESET_mode(Value.Channel);
			}
			else			
				EditNum = (EditNum - 1)<1? 4 : EditNum - 1;
			break;
		case EDIT_SUMTIME_MODE:
			if(!Flag.Edit){
				EditBuffer[EDIT_LENGTH-1] = 1;
			}
			break;
		case EDIT_DOWNTIME_MODE:
			if(!Flag.Edit){
				EditBuffer[EDIT_LENGTH-1] = 1;
			}
			break;
		case EDIT_SETTIME:
			edit_SetDate();
			break;
		case EDIT_SETDATE:
			edit_SetTime();
			break;
		case EDIT_DP_MODE:
			if(--EditBuffer[EDIT_LENGTH-1]>=EDIT_LENGTH)EditBuffer[EDIT_LENGTH-1] = EDIT_LENGTH-1;
			break;
		case EDIT_BAUDRATE_MODE:
			if(--EditBuffer[EDIT_LENGTH-1]>=5)EditBuffer[EDIT_LENGTH-1] = 4;
			break;
		case EDIT_PARITY_MODE:
			if(--EditBuffer[EDIT_LENGTH-1]>=3)EditBuffer[EDIT_LENGTH-1] = 2;
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit)return;
			if(--EditcharBuffer[MATRIX_LENGTH-EditNum] < EditSet)
				EditcharBuffer[MATRIX_LENGTH-EditNum] = EditSet+0x1F;
			break;
		default:
			break;
	}
}
void BUTTON_F1_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Target();
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit){
			}
			else{
				EditSet = 0x20;
				EditcharBuffer[MATRIX_LENGTH-EditNum] = EditSet;
			}
			break;
		default:
			break;
	}
}
void BUTTON_F2_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Actual1();
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit){
			}
			else{
				EditSet = 0x40;
				EditcharBuffer[MATRIX_LENGTH-EditNum] = EditSet;
			}
			break;
		default:
			break;
	}
}
void BUTTON_F3_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			EDIT_CHARTMENU_MODE();
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit){
			}
			else{
				EditSet = 0x60;
				EditcharBuffer[MATRIX_LENGTH-EditNum] = EditSet;
			}
			break;
		default:
			break;
	}
}
void BUTTON_F4_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
//			EDIT_CHARTMENU_MODE();
			edit_CycleTimeTarget();
			break;
		default:
			break;
	}
}
void BUTTON_CANCEL_event(void){
	switch(Status.Main){
		case EDIT_DP_MODE:
		case EDIT_ADDRESS_MODE:
		case EDIT_BAUDRATE_MODE:
		case EDIT_PARITY_MODE:
		case EDIT_DELAY_POLLS_MODE:
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
		case EDIT_CHARTMENU_MODE:
		case EDIT_CHARTVALUE_MODE:
		case EDIT_CYCLETIME:
		case EDIT_SETTIME:
			operate_mode();
			break;
		case OPERATE_MODE:
//			edit_delay_polls_mode();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_ENTER_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			break;
		case CAL_ANALOG_MODE:
			if(!Flag.Edit) break;
			Flag.Edit=0;
			save();
			if(!Flag.CalPoint){
				Flag.CalPoint=1;
			}
			else{
			}
			// edit_slave_address_mode();
			break;
		case EDIT_ADDRESS_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()<=255){
					Value.SlaveAddress=reload_edit_buffer();
					save();
					operate_mode();
					}
				EditNum=1;
				}
			break;
		case EDIT_BAUDRATE_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()>=BR4800&&reload_edit_buffer()<=BR57600){
					Value.Baudrate=reload_edit_buffer();
					uart2_init();
					save();
					operate_mode();
					}
				EditNum=1;
				}
			break;
		case EDIT_PARITY_MODE:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()>=b8n1&&reload_edit_buffer()<=b8e1){
					Value.Parity=reload_edit_buffer();
					uart2_init();
					save();
					operate_mode();
					}
				EditNum=1;
				}
			break;
		case EDIT_TARGET:
			if(!Flag.Edit){
				Flag.Edit=1;
				EditNum=1;
				}
			else {
				if(reload_edit_buffer()<=SEG_LIMITMAX&&reload_edit_buffer()>=SEG_LIMITMIN){
					Value.Target= reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_ACTUAL1:
			if(!Flag.Edit){
				Flag.Edit=1;
				}
			else {
				if(reload_edit_buffer()<=SEG_LIMITMAX&&reload_edit_buffer()>=SEG_LIMITMIN){
					Value.Actual1=reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_CYCLETIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=999 && reload_edit_buffer()>=0){
					if(Value.Channel == 0){
						Value.CycleTimeMasterPlan = reload_edit_buffer();
						}
					else if(Value.Channel == 1){
						Value.CycleTimeTarget = reload_edit_buffer();
						}
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_MUL_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=999 && reload_edit_buffer()>=1){
					switch(Value.Channel){
						case 0: Value.Multiplier1=reload_edit_buffer(); break;
						}
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_DIV_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=999 && reload_edit_buffer()>=1){
					switch(Value.Channel){
						case 0: Value.Divisor1=reload_edit_buffer(); break;
						}
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=99999 && reload_edit_buffer()>=0){
					if(Value.Channel == 0)	 	Value.SetPoint1 = reload_edit_buffer();
					else if(Value.Channel == 1)	Value.SetPoint2 = reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_INPUT_TYPE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=1 && reload_edit_buffer()>=0){
					Value.InputType = reload_edit_buffer();
					save();
					operate_mode();
					}
				}
			break;
		case EDIT_INPUT_DELAY:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=999 && reload_edit_buffer()>=1){
					Value.InputDelay= reload_edit_buffer();
					save();
					operate_mode();
					}
				else {
					EditNum=1;
					}
				}
			break;
		case EDIT_SETTIME:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(((EditTimeBuffer[0]*10)+EditTimeBuffer[1]) <= 23 ){
					if(((EditTimeBuffer[2]*10)+EditTimeBuffer[3]) <= 59 ){
						if(((EditTimeBuffer[4]*10)+EditTimeBuffer[5]) <= 59 ){
							edit_GetTime();
							operate_mode();
							}
						}
					}
				}
			break;
		case EDIT_SETDATE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(((EditTimeBuffer[0]*10)+EditTimeBuffer[1]) <= 31 ){
					if(((EditTimeBuffer[2]*10)+EditTimeBuffer[3]) <= 12 ){
						if(((EditTimeBuffer[4]*10)+EditTimeBuffer[5]) <= 99 ){
							edit_GetDate();
							operate_mode();
							}
						}
					}
				}
			break;
		case EDIT_TIMEMENU_MODE:
			switch(reload_edit_buffer()){
			case MENU_TIME_ON:		edit_Time_ON_mode(0);	break;
			case MENU_TIME_OFF:		edit_Time_OFF_mode(0);	break;
			case MENU_TIME_RESET:	edit_Time_RESET_mode(0);break;
			case MENU_TIME_EN:		edit_Time_En_mode();	break;
			case MENU_TIME_SUM:		edit_SummaryTime_mode();	break;
			case MENU_TIME_DOWN:	edit_DownTime_mode();	break;
			}
			break;
		case EDIT_TIMEEN_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				Value.Time_EN = reload_edit_buffer();
				save();
				operate_mode();
				}
			break;
		case EDIT_TIMEON_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				reload_Time_mode(&Value.Time_ON[TIMER_CHANNEL_MAX-Value.Channel].Word);
				save();
				EditNum = 0;
				Flag.Edit = 0;
				}
			break;			
		case EDIT_TIMEOFF_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				reload_Time_mode(&Value.Time_OFF[TIMER_CHANNEL_MAX-Value.Channel].Word);
				save();
				EditNum = 0;
				Flag.Edit = 0;
				}
			break;
		case EDIT_TIMERESET_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				EditNum = 1;
				}
			else {
				reload_Time_mode(&Value.Time_Reset[TIMER_CHANNEL_MAX-Value.Channel].Word);
				save();
				EditNum = 0;
				Flag.Edit = 0;
				}
			break;
		case EDIT_SUMTIME_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer() == 1){
					Value.SummaryTimeDay = 0;
					Value.SummaryTimeHour = 0;
					Value.SummaryTimeMinute = 0;
					Value.SummaryTimeSecond = 0;
					save();
					operate_mode();
					}
				else{
					edit_Time_MENU_mode(MENU_TIME_SUM);
					}
				}
			break;
		case EDIT_DOWNTIME_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer() == 1){
					Value.DownTimeDay = 0;
					Value.DownTimeHour = 0;
					Value.DownTimeMinute = 0;
					Value.DownTimeSecond = 0;
					save();	
					operate_mode();
					}
				else{
					edit_Time_MENU_mode(MENU_TIME_DOWN);
					}
				}
			break;
		case EDIT_CHARTVALUE_MODE:
			if(!Flag.Edit){
				Flag.Edit = 1;
			}
			else{
				save();
				// Flag.Edit = 0;
				operate_mode();
				//edit_Chart_Value_mode(EditNum);
			}
			break;
		case EDIT_DP_MODE:
			if(!Flag.Edit){
				EditNum = 1;
				Flag.Edit = 1;
				}
			else {
				if(reload_edit_buffer()<=4 && reload_edit_buffer()>=0){
					Value.DecimalPoint = reload_edit_buffer();
					save();
					operate_mode();
					}
				}
			break;
		case IDLE_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_MENU_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			edit_Time_MENU_mode(MENU_TIME_ON);
			break;
		case EDIT_TIMEEN_MODE:
//			Value.Break_Channel = 0;
//			edit_Time_OFF_mode(Value.Break_Channel);
			break;
		case EDIT_TIMEOFF_MODE:
//			Value.Break_Channel = 0;
//			edit_Time_ON_mode(Value.Break_Channel);
			break;
		case EDIT_TIMEON_MODE:
			// edit_Time_RESET_mode(0);
			break;
		case EDIT_TIMERESET_MODE:
			// edit_CycleTimeMasterPlan();
			break;
		case EDIT_CYCLETIME:
			// edit_InpurType_mode();
			break;
		case EDIT_INPUT_TYPE:
			// edit_Time_En_mode();
			break;
		case IDLE_MODE:
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_DP_event(void){
	switch(Status.Main){
		case OPERATE_MODE:
			// if(++Value.DecimalPoint>=EDIT_LENGTH)Value.DecimalPoint=0;
			// write_eeprom(EEP_DP, (u16)Value.DecimalPoint);
			edit_Decimal_mode();
			break;
		default:
			break;
	}
}

void Button_Time(u8 length, u8 ID){
	switch(EditNum){
		case 1:
			if(ID>=0 && ID<=2){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 2:
			if(EditTimeBuffer[0] == 2){
				if(Status.Main == EDIT_SETTIME){
					if(ID>=0&&ID<=3){
						EditTimeBuffer[EditNum - 1] = ID;
						EditNum++;
						}
					}
				else{
					if(ID>=0&&ID<=4){
						EditTimeBuffer[EditNum - 1] = ID;
						EditNum++;
						}
					}
				}
			else{
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 3:
		case 5:
			if(EditTimeBuffer[0]==2 && EditTimeBuffer[1]==4){
				EditTimeBuffer[EditNum - 1] = 0;
				EditNum++;
				}
			else{
				if(ID>=0&&ID<=5){
					EditTimeBuffer[EditNum - 1] = ID;
					EditNum++;
					}
				}
			break;
		case 4:
		case 6:
			if(EditTimeBuffer[0]==2 && EditTimeBuffer[1]==4){
				EditTimeBuffer[EditNum - 1] = 0;
				EditNum++;
				}
			else{
				if(ID>=0&&ID<=9){
					EditTimeBuffer[EditNum - 1] = ID;
					EditNum++;
					}
				}
			break;
		default:
			break;
		}
		if(EditNum > length)EditNum = 1;
}
void Button_Date(u8 length, u8 ID){
	switch(EditNum){
		case 1:
			if(ID>=0 && ID<=3){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 2:
			if(EditTimeBuffer[0]<3 && ID>=0 && ID<=9){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			else if(EditTimeBuffer[0]==3 && ID>=0 && ID<=1){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 3:
			if(ID>=0 && ID<=1){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 4:
			if(EditTimeBuffer[2]<1 && ID>=1 && ID<=9){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			else if(EditTimeBuffer[2]==1 && ID>=1 && ID<=2){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		case 5:
		case 6:
			if(ID>=0 && ID<=9){
				EditTimeBuffer[EditNum - 1] = ID;
				EditNum++;
				}
			break;
		default:
			break;
		}
		if(EditNum > length)EditNum = 1;
}
void BUTTON_event_edit(u8 length, u8 IR){
	u8 i;
	if(EditNum>=1&&EditNum<=length){
		if(EditNum!=1){
			shift_edit_buffer();
		}
		else{
			for(i=0;i<EDIT_LENGTH-1;i++)
				EditBuffer[i]=0;
			Flag.Sign = 0;
		}
		EditBuffer[EDIT_LENGTH-1]=IR_SW;
		if(!EditBuffer[EDIT_LENGTH-1]&&EditNum==1) return;
		EditNum++;
	}
}
void BUTTON_0_event(void){
	IR_SW=0;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_1_event(void){
	IR_SW=1;
	switch(Status.Main){
		case OPERATE_MODE:
			// cal_mode();
			edit_baudrate_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_2_event(void){	
	IR_SW=2;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_3_event(void){	
	IR_SW=3;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			edit_parity_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_4_event(void){	
	IR_SW=4;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			edit_InputType_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_5_event(void){	
	IR_SW=5;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_6_event(void){	
	IR_SW=6;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_7_event(void){	
	IR_SW=7;
	switch(Status.Main){
		case OPERATE_MODE:
			// For TGA-002
			// edit_Chart_Value_mode(1);
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_8_event(void){	
	IR_SW=8;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void BUTTON_9_event(void){	
	IR_SW=9;
	switch(Status.Main){
		case OPERATE_MODE:
			//cal_mode();
			break;
		case EDIT_ADDRESS_MODE:
			BUTTON_event_edit(3,IR_SW);
			break;
		case EDIT_ALS_MODE:
			if(!Flag.Edit) return;
		case EDIT_TARGET:
		case EDIT_ACTUAL1:
			if(Flag.Edit){
				BUTTON_event_edit(5,IR_SW);
				}
			break;
		case EDIT_CYCLETIME:
		case EDIT_MUL_MODE:
		case EDIT_DIV_MODE:
		case EDIT_INPUT_DELAY:
			if(Flag.Edit){
				BUTTON_event_edit(3,IR_SW);
				}
			break;
		case EDIT_SETTIME:
			if(Flag.Edit){
				Button_Time(6,IR_SW);
				}
			break; 
		case EDIT_SETDATE:
			if(Flag.Edit){
				Button_Date(6,IR_SW);
				}
			break; 
		case EDIT_TIMEON_MODE:
		case EDIT_TIMEOFF_MODE:
		case EDIT_TIMERESET_MODE:
			if(Flag.Edit){
				Button_Time(4,IR_SW);
				}
			break; 
		default:
			break;
	}
}
void ir_decode(void){
	u8 i;
	/*insert code here for active*/
	if(Flag.IrDecode){
		if(++IrData.TimeOut>=TIME20mSEC){
			IrData.TimeOut=CLR;
			if(IrData.ByteCount==11){
				//Flag.IrDecode=CLR;
				IrData.Decode=CLR;
				for(i=0;i<IrData.ByteCount;i++){
					if(IrData.Buffer[i]>=IrDataLogic_0) IrData.Decode+=1;
					IrData.Decode=IrData.Decode<<1;
				}
				if(IrData.Decode!=IrData.DecodeLast){
					IrData.DecodeLast=IrData.Decode;
					TimeBlink = 0;
					Flag.Blink = 0;
					switch(IrData.Decode){
						case BUTTON_SET_TIME:
							BUTTON_SET_TIME_event();
							break;
						case BUTTON_DSP:
							BUTTON_DSP_event();
							break;
						case BUTTON_POWER:
							BUTTON_POWER_event();
							break;
						case BUTTON_OP_MODE:
							BUTTON_OP_MODE_event();
							break;
						case BUTTON_ADD:
							BUTTON_ADD_event();
							break;
						case BUTTON_OSD:
							BUTTON_OSD_event();
							break;
						case BUTTON_SIGN:
							BUTTON_SIGN_event();
							break;
						case BUTTON_F1:
							BUTTON_F1_event();
							break;
						case BUTTON_F2:
							BUTTON_F2_event();
							break;
						case BUTTON_F3:
							BUTTON_F3_event();
							break;
						case BUTTON_F4:
							BUTTON_F4_event();
							break;
						case BUTTON_SCALE_PLUS:
							BUTTON_SCALE_PLUS_event();
							break;
						case BUTTON_SCALE_MINUS:
							BUTTON_SCALE_MINUS_event();
							break;
						case BUTTON_VOL_PLUS:
							BUTTON_VOL_PLUS_event();
							break;
						case BUTTON_VOL_MINUS:
							BUTTON_VOL_MINUS_event();
							break;
						case BUTTON_ENTER:
							BUTTON_ENTER_event();
							break;
						case BUTTON_MENU:
							BUTTON_MENU_event();
							break;
						case BUTTON_CANCEL:
							BUTTON_CANCEL_event();
							break;
						case BUTTON_DP:
							BUTTON_DP_event();
							break;
						case BUTTON_0:
							BUTTON_0_event();
							break;
						case BUTTON_1:
							BUTTON_1_event();
							break;
						case BUTTON_2:
							BUTTON_2_event();
							break;
						case BUTTON_3:
							BUTTON_3_event();
							break;
						case BUTTON_4:
							BUTTON_4_event();
							break;
						case BUTTON_5:
							BUTTON_5_event();
							break;
						case BUTTON_6:
							BUTTON_6_event();
							break;
						case BUTTON_7:
							BUTTON_7_event();
							break;
						case BUTTON_8:
							BUTTON_8_event();
							break;
						case BUTTON_9:
							BUTTON_9_event();
							break;
						default:
							break;
					}
				}
			}
			IrData.Status=CLR;
			Flag.IrDecode=CLR;	
			IrData.ByteCount=CLR;
		}
	}
	else{
		if(++IrData.TimeOut>=5){
			IrData.TimeOut=CLR;
			IrData.Decode=CLR;
			IrData.DecodeLast=CLR;
		}
	}
}
