#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

enum{Lo, Hi};

void clk(void){
	delayxNop();
	SCL=Hi;
	delayxNop();
	SCL=Lo;
}

void mux(void){
	/*
	if(Value.Channel==0){
		CD4051_A=0;
		CD4051_B=0;
		}
	if(Value.Channel==1){
		CD4051_A=0;
		CD4051_B=1;
		}
	if(Value.Channel==2){
		CD4051_A=1;
		CD4051_B=0;
		}
	if(Value.Channel==3){
		CD4051_A=1;
		CD4051_B=1;
		}
		*/
	CD4051_A=(ADC.channel&0x01) ? 1 : 0;
	CD4051_B=(ADC.channel&0x02) ? 1 : 0;
}

#if 0
void t_sample(void){
	SDAIO=OUTPUT;
	SDA=Hi;
	SCL=Hi;
	delayxNop();
	SCL=Lo;
	clk();
	clk();
}
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;
	
	ADC_CS=Lo;
	delayxNop();
	t_sample();
	SDAIO=INPUT;
	clk();
	delayxNop();
	value=CLR;
	for(i=0;i<22;i++){
		value<<=1;
		SCL=Lo;
		delayxNop();
		if(SDA) value|=1;
		SCL=Hi;	
		delayxNop();
	}
	delayxNop();
	ADC_CS=Hi;
	return value;
}
#endif
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;

	value=0;
	for(i=0;i<24;i++){
		value<<=1;
		SCL=Hi;
		delayxNop();
		if(SDA) value|=1;
		delayxNop();
		SCL=Lo;	
		delayxNop();
		delayxNop();
	}
	delayxNop();
	
	ADC_CS=Hi;
	return value;
}
void get_analog(channel){
	float scale, span, zero, output[4];
	u8 i, j;
	u32 temp;
	u32 buffer; 
	mux();

	if(++ADC.TimeOunt>=5){
		ADC.TimeOunt=CLR;

		SDAIO=INPUT;
		ADC_CS=Lo;
		delayxNop();
		SCL=Lo;
		delayxNop();
		delayxNop();
		
		if(SDA==0){ 
			ADC.Data[ADC.Sample++]=MCP3551_read(0);
			
			if(ADC.Data[ADC.Sample++]&0x400000){
			}
			else if(ADC.Data[ADC.Sample++]&0x800000){
			}
			
			else{
				if(ADC.Sample>=4){
					ADC.Sample=0;  
#if 1				
					for(i=0;i<3;i++){
						for(j=i+1;j<4;j++){
							if(ADC.Data[i]>ADC.Data[j]){
								temp=ADC.Data[j];
								ADC.Data[j]=ADC.Data[i];
								ADC.Data[i]=temp;
							}
						}
					}
					buffer=0;
					buffer=ADC.Data[1]+ADC.Data[2];
					
					for(i=0;i<3;i++) 
					ADC.Buffer[i]=ADC.Buffer[i+1];
					ADC.Buffer[3]=buffer/2;
					buffer=0;
					for(i=0;i<4;i++) buffer+=ADC.Buffer[i];
					ADC.Filter=buffer*4;
					ADC.Filter>>=4;
					
					//if(++ADC.channel>3) ADC.channel=0;
			
					output[Value.Channel]=ADC.Filter;
					span=Value.SystemFullScale[Value.Channel].LWord;
					zero=Value.SystemZeroScale[Value.Channel].LWord;

					output[Value.Channel]-=zero;
					output[Value.Channel]=output[Value.Channel]/(span-zero);
					
					Flag.PVLoLimit=0;
					Flag.PVHiLimit=0;
					if(output[Value.Channel]<-0.01) Flag.PVLoLimit=1;
					else if(output[Value.Channel]>1.01) Flag.PVHiLimit=1;
					else{
						output[ADC.channel]=output[Value.Channel]*(Value.ScaleHiLimit[Value.Channel].LWord-Value.ScaleLoLimit[Value.Channel].LWord)+Value.ScaleLoLimit[Value.Channel].LWord;
						}
					
					//delayxNop();
					//if (++ADC.channel>3) ADC.channel=0;
					//if (++Value.Channel>3) Value.Channel=0;
					//delayxNop();
					if(ADC.channel==1){
							
							Value.PV[0].LWord=(s32)output[ADC.channel];
						
							Value.CurrentTemp[0].LWord=(s32)output[ADC.channel];
							
							
#if 0
							if(Value.CurrentTemp[0]!=Value.PV[0].LWord)
								{Value.CurrentTemp[1]=Value.PV[0].LWord;}
							
							else{
							Value.CurrentTemp[0]=Value.PV[0].LWord;
							Value.CurrentTempInc=Value.CurrentTemp+1;
							Value.CurrentTempDec=Value.CurrentTemp-1;
								}
#endif
						}   	




					
					else if(ADC.channel==2){
							Value.PV[1].LWord=(s32)output[ADC.channel];  
						}

					else if(ADC.channel==3){
							Value.PV[2].LWord=(s32)output[ADC.channel];  
						}

						//if(Value.PV.LWord>99999){ Flag.PVHiLimit=1;}
						//else if(Value.PV.LWord<-19999){ Flag.PVLoLimit=1;}
						//else{ Flag.PVHiLimit=0; Flag.PVLoLimit=0;}
						
				}
			}
		}
#endif
		}
}

