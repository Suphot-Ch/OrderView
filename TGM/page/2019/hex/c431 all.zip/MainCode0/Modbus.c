#if 1
#include <p30f4011.h>
#include <stdio.h>
#include <uart.h>
#include "config.h"
#include "global.h"

const u8 CRCTableHigh[] = {
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,	0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
const u8 CRCTableLow[] = {
	0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
	0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
	0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
	0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
	0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
	0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
	0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
	0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
	0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
	0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
	0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
	0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
	0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;
const u8 HEX2ASCII[]={
	'0',
	'1',
	'2',
	'3',
	'4',
	'5',
	'6',
	'7',
	'8',
	'9',
	'A',
	'B',
	'C',
	'D',
	'E',
	'F'
};

void func_01_rtu_mode(void);
void func_01_ascii_mode(void);
void func_03_rtu_mode(void);
void func_03_ascii_mode(void);
void func_05_rtu_mode(void);
void func_05_ascii_mode(void);
void func_06_rtu_mode(void);
void func_06_ascii_mode(void);
void func_15_rtu_mode(void);
void func_15_ascii_mode(void);
void func_16_rtu_mode(void);
void func_16_ascii_mode(void);

void (*read_coils[]) (void)={
	func_01_rtu_mode,
	func_01_ascii_mode
};
void (*preset_a_single_coils[]) (void)={
	func_05_rtu_mode,
	func_05_ascii_mode
};

void (*read_multi_registers[]) (void)={
	func_03_rtu_mode,
	func_03_ascii_mode
};

void (*preset_a_single_register[]) (void)={
	func_06_rtu_mode,
	func_06_ascii_mode
};

void (*preset_multi_registers[]) (void)={
	func_16_rtu_mode,
	func_16_ascii_mode
};


void tx_en(void){
	RD_485=TX;
	//cbi(IE2, UCA0RXIE);
	//sbi(IE2, UCA0TXIE);
}
void rx_en(void){
	RD_485=RX;
	//sbi(IE2, UCA0RXIE);
	//cbi(IE2, UCA0TXIE);
}
void crc16(u8 *dptr,u8 n){
	u8 i, j;
	
	Modbus.CrcHi=Modbus.CrcLo=0xFF;
	for(i=0;i<n;i++,dptr++){
		j=Modbus.CrcHi^*dptr;
		Modbus.CrcHi=Modbus.CrcLo^CRCTableHigh[j];
		Modbus.CrcLo=CRCTableLow[j];
	}
}
void LRC(u8 *auchMsg, u8 usDataLen){
	unsigned char uchLRC = 0 ; /* LRC char initialized */
	
	while(usDataLen--){ /* pass through message buffer */
		uchLRC+=(*auchMsg); /* add buffer byte without carry */
		auchMsg++;
	}
	uchLRC=((unsigned char)(-((char)uchLRC))) ; /* return twos complement */
	
	Modbus.CrcHi=HEX2ASCII[uchLRC>>4];
	Modbus.CrcLo=HEX2ASCII[uchLRC&0x0F];	
}
u8 ascII2hex(u8 *ascii){	
	u8 buf[2];
	
	buf[0]=(ascii[0]>'9') ? ((ascii[0]-'A')+10) : (ascii[0]-'0');
	buf[1]=(ascii[1]>'9') ? ((ascii[1]-'A')+10) : (ascii[1]-'0');
	return((buf[0]*0x10)+(buf[1]));
}
void ASCII2HEX(u8 *ascii, u8 n){	
	u8 i;
	
	if(Value.Protocol==ASCII){
		n=(n-3)>>1;
		for(i=0;i<n;i++){
			Modbus.Ascii2HexBuf[i]=ascII2hex(&ascii[(i*2)+1]);
		}
	}
	else{
		for(i=0;i<n;i++){
			Modbus.Ascii2HexBuf[i]=ascii[i];
		}
	}
}
u8 register_value_in_range(u16 reg_addr, s16 reg_val){
#if 1
	U16_uType reg_fun;
	u8 PL;
	switch(reg_addr){
		case CHAR21:
		case CHAR43:
		case CHAR65:
			reg_fun.Word=reg_val;
			if((reg_fun.H<=0x7F)&&(reg_fun.H>=0x20)) PL= 1;
			else PL= 0;
			if((reg_fun.L<=0x7F)&&(reg_fun.L>=0x20)) PL= 1;
			else PL= 0;
			return PL;
			break;
		case CHARB7:
			reg_fun.Word=reg_val;
			if((reg_fun.L<=0x7F)&&(reg_fun.L>=0x20)) PL= 1;
			else PL= 0;
			if((reg_fun.H==0x20)) PL= 1;
			else PL= 0;
			return PL;
			break;
		case BATCH:
			if((reg_val<=9999)&&(reg_val>=-1999)) return 1;
			else return 0;
			break;
		case BATCH_DP:
			if((reg_val<=3)&&(reg_val>=0)) return 1;
			else return 0;
			break;
		case DUMP:
			if((reg_val<=9999)&&(reg_val>=-1999)) return 1;
			else return 0;
			break;
		case DUMP_DP:
			if((reg_val<=3)&&(reg_val>=0)) return 1;
			else return 0;
			break;
		case TIME_16:
			if((reg_val<=5970)&&(reg_val>=0)) return 1;
			else return 0;
			break;
		default:
			return 0;
			break;
		}
#endif	
}
void exeption_response(u8 ExeptionCode){
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		Value.Protocol=RTUs;
		if(Value.Protocol==RTUs){
			Modbus.ByteRsp=0;
			Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;	
			Modbus.RspBuf[Modbus.ByteRsp++]=0x80|Modbus.Ascii2HexBuf[1];	
			Modbus.RspBuf[Modbus.ByteRsp++]=ExeptionCode;	
			crc16(Modbus.RspBuf, 3);
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
		}
		else{
			Modbus.ByteRsp=0;
			Modbus.RspBuf[Modbus.ByteRsp++]=':';
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress>>4];
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress&0x0F];	
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[(0x80|Modbus.Ascii2HexBuf[1])>>4];	
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[(0x80|Modbus.Ascii2HexBuf[1])&0x0F];	
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[ExeptionCode>>4];	
			Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[ExeptionCode&0x0F];	
			ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
			LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
			Modbus.RspBuf[Modbus.ByteRsp++]='\r';
			Modbus.RspBuf[Modbus.ByteRsp++]='\n';
		}
		MB_Dptr=Modbus.RspBuf;	
		Flag.FTX=1;
		Modbus.TXTimeOut=0;
		tx_en();
		U2TXREG=*MB_Dptr++;
	}
}
void save_to_eeprom(u8 addr, s16 *dptr){
}
void get_data_last(u8 *dptr){
	DataLastMB=0;
	DataLastMB=*dptr--;
	DataLastMB<<=8;
	DataLastMB|=*dptr;
}
void get_address(u8 *dptr){
	DataLastMB=0;
	DataLastMB=*dptr--;
	DataLastMB<<=8;
	DataLastMB|=*dptr;
}
void func_01_rtu_mode(void){
	u16 i;
	U16_uType QUANTITY, REGISTER_ADDR;
	u8 *dptr, BYTE_COUNT;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
		QUANTITY.H=Modbus.Ascii2HexBuf[4];
		QUANTITY.L=Modbus.Ascii2HexBuf[5];
		BYTE_COUNT=(QUANTITY.Word/8)+1;
		if(QUANTITY.Word>=1&&QUANTITY.Word<=3){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			if((REGISTER_ADDR.Word>=0x0000)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=0x0003)){
				dptr=&Value.CoilOutput;
				Modbus.ByteRsp=0;
				Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];		
				Modbus.RspBuf[Modbus.ByteRsp++]=BYTE_COUNT;
				for(i=0;i<BYTE_COUNT;i++,dptr--){
					Modbus.RspBuf[Modbus.ByteRsp++]=*dptr;
				}
				crc16(Modbus.RspBuf, Modbus.ByteRsp);
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_01_ascii_mode(void){
	u16 i;
	U16_uType QUANTITY, REGISTER_ADDR;
	u8 *dptr, BYTE_COUNT;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=17) return;	
		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
		QUANTITY.H=Modbus.Ascii2HexBuf[4];
		QUANTITY.L=Modbus.Ascii2HexBuf[5];
		BYTE_COUNT=(QUANTITY.Word/8)+1;
		if(QUANTITY.Word>=1&&QUANTITY.Word<=3){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			if((REGISTER_ADDR.Word>=0x0000)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=0x0003)){
				dptr=&Value.CoilOutput;
				Modbus.RspBuf[Modbus.ByteRsp++]=':';
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[BYTE_COUNT>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[BYTE_COUNT&0x0F];	
				for(i=0;i<BYTE_COUNT;i++,dptr--){
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr>>4];
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr&0x0F];
				}
				ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
				LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_03_rtu_mode(void){
	u16 i;
	U16_uType NRegs, REGISTER_ADDR;
	u8 *dptr;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
		NRegs.H=Modbus.Ascii2HexBuf[4];
		NRegs.L=Modbus.Ascii2HexBuf[5];
		if(NRegs.Word>=1&&NRegs.Word<=TIME_16+1){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
				if((REGISTER_ADDR.Word>=CHAR21)&&((REGISTER_ADDR.Word+NRegs.Word)<=TIME_16+1)){
//					dptr=(u8 *)&Value.Char[3].H;
					dptr-=REGISTER_ADDR.Word<<1;
					Modbus.ByteRsp=0;
					Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];				
					NRegs.Word<<=1;
					Modbus.RspBuf[Modbus.ByteRsp++]=NRegs.Word;
					for(i=0;i<NRegs.Word;i++,dptr--){
						Modbus.RspBuf[Modbus.ByteRsp++]=*dptr;
					}
					crc16(Modbus.RspBuf, Modbus.ByteRsp);
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
					MB_Dptr=Modbus.RspBuf;
					Flag.FTX=1;
					Modbus.TXTimeOut=0;
					tx_en();
					U2TXREG=*MB_Dptr++;
				}
				else{
					exeption_response(ILLEGAL_DATA_ADDRESS);	
				}
			}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_03_ascii_mode(void){
	u16 i;
	U16_uType NRegs, REGISTER_ADDR;
	u8 *dptr;

	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=17) return;	
		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;			
		NRegs.H=Modbus.Ascii2HexBuf[4];
		NRegs.L=Modbus.Ascii2HexBuf[5];
		if(NRegs.Word>=1&&NRegs.Word<=TIME_16+1){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			if((REGISTER_ADDR.Word>=CHAR21)&&((REGISTER_ADDR.Word+NRegs.Word)<=TIME_16+1)){
//				dptr=(u8 *)&Value.Char[3].H;
				dptr-=REGISTER_ADDR.Word<<1;
					
				Modbus.ByteRsp=0;
				Modbus.RspBuf[Modbus.ByteRsp++]=':';
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress>>4];
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];					
				NRegs.Word<<=1;
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[NRegs.Word>>4];
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[NRegs.Word&0x0F];
				for(i=0;i<NRegs.Word;i++,dptr--){
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr>>4];
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr&0x0F];
				}
				ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
				LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
				}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
				}
		}
		else{
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_05_rtu_mode(void){
	u16 i;
	U16_uType OUTPUT_VALUE, REGISTER_ADDR;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
		OUTPUT_VALUE.H=Modbus.Ascii2HexBuf[4];
		OUTPUT_VALUE.L=Modbus.Ascii2HexBuf[5];
		if((OUTPUT_VALUE.Word==0x0000)||(OUTPUT_VALUE.Word==0xFF00)){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			if((REGISTER_ADDR.Word>=0)&&(REGISTER_ADDR.Word<=3)){
				if(OUTPUT_VALUE.Word==0xFF00){
					Flag.CoilsOn=1;
				}
				else{
					Flag.CoilsOn=0;
				}
				switch(REGISTER_ADDR.Word){
					case 0:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT0);
						}
						else{
							cbi(Value.CoilOutput, BIT0);
						}
						break;
					case 1:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT1);
						}
						else{
							cbi(Value.CoilOutput, BIT1);
						}
						break;
					case 2:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT2);
						}
						else{
							cbi(Value.CoilOutput, BIT2);
						}
						break;
				}
				for(i=0;i<Modbus.ByteReq;i++){
					Modbus.RspBuf[i]=Modbus.ReqBuf[i];
				}
				Modbus.ByteRsp=Modbus.ByteReq;
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_05_ascii_mode(void){
	U16_uType OUTPUT_VALUE, REGISTER_ADDR;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=17) return;	
		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
		OUTPUT_VALUE.H=Modbus.Ascii2HexBuf[4];
		OUTPUT_VALUE.L=Modbus.Ascii2HexBuf[5];
		if((OUTPUT_VALUE.Word==0x0000)||(OUTPUT_VALUE.Word==0xFF00)){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			if((REGISTER_ADDR.Word>=0)&&(REGISTER_ADDR.Word<=0)){
				if(OUTPUT_VALUE.Word==0xFF00){
					Flag.CoilsOn=1;
				}
				else{
					Flag.CoilsOn=0;
				}
				switch(REGISTER_ADDR.Word){
					case 0:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT0);
						}
						else{
							cbi(Value.CoilOutput, BIT0);
						}
						break;
					case 1:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT1);
						}
						else{
							cbi(Value.CoilOutput, BIT1);
						}
						break;
					case 2:
						if(Flag.CoilsOn){
							sbi(Value.CoilOutput, BIT2);
						}
						else{
							cbi(Value.CoilOutput, BIT2);
						}
						break;
				}
				Modbus.RspBuf[Modbus.ByteRsp++]=':';
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[6]>>4];	
				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[6]&0x0F];	
				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_06_rtu_mode(void){
	U16_uType REGISTER_VAL, REGISTER_ADDR;
	u8 *dptr;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
				if((REGISTER_ADDR.Word>=CHAR21)&&(REGISTER_ADDR.Word<=TIME_16)){
					REGISTER_VAL.H=Modbus.Ascii2HexBuf[4];
					REGISTER_VAL.L=Modbus.Ascii2HexBuf[5];
					Flag.DATA_NOT_SUPPORT=0;
					if(register_value_in_range(REGISTER_ADDR.Word, REGISTER_VAL.Word)){
//						dptr=(u8 *)&Value.Char[3].H;
						dptr-=REGISTER_ADDR.Word<<1;
						
						*dptr--=REGISTER_VAL.H;
						*dptr=REGISTER_VAL.L;
						
						if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
							Modbus.ByteRsp=0;
							Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[1];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[2];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[3];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[4];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[5];
							crc16(Modbus.Ascii2HexBuf, Modbus.ByteRsp);	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
							MB_Dptr=Modbus.RspBuf;
							Flag.FTX=1;
							Modbus.TXTimeOut=0;
							tx_en();
							U2TXREG=*MB_Dptr++;
							}
						}
					else{
						exeption_response(ILLEGAL_DATA_VALUE);	
						}
					}
		else{
			exeption_response(ILLEGAL_DATA_ADDRESS);	
		}
	}
}
void func_06_ascii_mode(void){
	U16_uType REGISTER_VAL, REGISTER_ADDR;
	u8 *dptr;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq!=17) return;	
		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
		if((REGISTER_ADDR.Word>=CHAR21)&&(REGISTER_ADDR.Word<=TIME_16)){
			REGISTER_VAL.H=Modbus.Ascii2HexBuf[4];
			REGISTER_VAL.L=Modbus.Ascii2HexBuf[5];
			Flag.DATA_NOT_SUPPORT=0;
			if(register_value_in_range(REGISTER_ADDR.Word, REGISTER_VAL.Word)){
//				dptr=(u8 *)&Value.Char[3].H;
				dptr-=REGISTER_ADDR.Word<<1;
				
				*dptr--=REGISTER_VAL.H;
				*dptr=REGISTER_VAL.L;
				
				if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
					Modbus.RspBuf[Modbus.ByteRsp++]=':';
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
					ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
					LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
					Modbus.RspBuf[Modbus.ByteRsp++]='\r';
					Modbus.RspBuf[Modbus.ByteRsp++]='\n';
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
				}
			}
			else{
				exeption_response(ILLEGAL_DATA_VALUE);	
			}
		}
		else{
			exeption_response(ILLEGAL_DATA_ADDRESS);	
		}
	}
}
void func_16_rtu_mode(void){	
	U16_uType QUANTITY, REGISTER_ADDR, REGISTER_VAL;
	u8 *dptr, i, BYTE_COUNT;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq<11) return;	
		crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
		QUANTITY.H=Modbus.Ascii2HexBuf[4];
		QUANTITY.L=Modbus.Ascii2HexBuf[5];
		BYTE_COUNT=Modbus.Ascii2HexBuf[6];
		if(((QUANTITY.Word>=1)&&(QUANTITY.Word<=TIME_16+1))&&((QUANTITY.Word<<1)==BYTE_COUNT)){
			if((REGISTER_ADDR.Word>=CHAR21)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=TIME_16+1)){
				Flag.DATA_NOT_SUPPORT=0;
				for(i=0;i<QUANTITY.Word;i++){
					REGISTER_VAL.H=Modbus.Ascii2HexBuf[(i*2)+7];
					REGISTER_VAL.L=Modbus.Ascii2HexBuf[(i*2)+8];
					if(!register_value_in_range(REGISTER_ADDR.Word+i,REGISTER_VAL.Word)){
						Flag.DATA_NOT_SUPPORT=1;
						break;
					}
				}
				if(Flag.DATA_NOT_SUPPORT==0){
//					dptr=(u8 *)&Value.Char[3].H;
					dptr-=REGISTER_ADDR.Word<<1;
					
					for(i=7;i<BYTE_COUNT+7;i++, dptr--){
						*dptr=Modbus.Ascii2HexBuf[i];
					}
					if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
						Modbus.ByteRsp=0;
						Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[1];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[2];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[3];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[5];
						crc16(Modbus.Ascii2HexBuf, Modbus.ByteRsp);	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
					}
				}
				else{
					exeption_response(ILLEGAL_DATA_VALUE);						
				}
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_16_ascii_mode(void){
	u16 BYTE_COUNT;
	U16_uType QUANTITY, REGISTER_ADDR, REGISTER_VAL;
	u8 *dptr, i;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq<27) return;	
		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
		QUANTITY.H=Modbus.Ascii2HexBuf[4];
		QUANTITY.L=Modbus.Ascii2HexBuf[5];
		BYTE_COUNT=Modbus.Ascii2HexBuf[6];
		if(((QUANTITY.Word>=1)&&(QUANTITY.Word<=TIME_16+1))&&((QUANTITY.Word<<1)==BYTE_COUNT)){
			if((REGISTER_ADDR.Word>=CHAR21)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=TIME_16+1)){
				Flag.DATA_NOT_SUPPORT=0;
				for(i=0;i<QUANTITY.Word;i++){
					REGISTER_VAL.H=Modbus.Ascii2HexBuf[(i*2)+7];
					REGISTER_VAL.L=Modbus.Ascii2HexBuf[(i*2)+8];
					if(!register_value_in_range(REGISTER_ADDR.Word+i, REGISTER_VAL.Word)){
						Flag.DATA_NOT_SUPPORT=1;
						break;
					}
				}
				if(Flag.DATA_NOT_SUPPORT==0){
//					dptr=(u8 *)&Value.Char[3].H;
					dptr-=REGISTER_ADDR.Word<<1;
					
					for(i=7;i<BYTE_COUNT+7;i++, dptr--){
						*dptr=Modbus.Ascii2HexBuf[i];
					}
					if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
						Modbus.RspBuf[Modbus.ByteRsp++]=':';
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
						ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
						LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
						Modbus.RspBuf[Modbus.ByteRsp++]='\r';
						Modbus.RspBuf[Modbus.ByteRsp++]='\n';
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
					}
				}
				else{
					exeption_response(ILLEGAL_DATA_VALUE);	
				}
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{
			exeption_response(ILLEGAL_DATA_VALUE);		
		}
	}
}
void modbus(void){
	if(Flag.FTX){
		if(++Modbus.TXTimeOut>=10){
			Modbus.TXTimeOut=0;
			Flag.FTX=0;
			rx_en();
		}
	}
	if(Flag.FRX){
		if(++Modbus.RXTimeOut>=10){
			Modbus.RXTimeOut=0;
			Flag.FRX=0;
			ASCII2HEX(&Modbus.ReqBuf[0], Modbus.ByteReq);
			switch(Modbus.Ascii2HexBuf[1]){
				case 0x01:
					read_coils[Value.Protocol]();
					break;
				case 0x03:
				case 0x04:
					read_multi_registers[Value.Protocol]();
					break;
				case 0x05:
					preset_a_single_coils[Value.Protocol]();
					break;
				case 0x06:
					preset_a_single_register[Value.Protocol]();
					break;
				case 0x0F:
					preset_multi_registers[Value.Protocol]();
					break;
				case 0x10:
					preset_multi_registers[Value.Protocol]();
					break;
				default:
					if(Value.Protocol==RTUs){
						crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
						if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1]) break;	
					}
					else{
						LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
						if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])break;	
					}
					exeption_response(ILLEGAL_FUNCTION);
					break;
			}
			Modbus.ByteReq=0;
		}
	}
}
#endif

