#include "Matrix.h"

char MAP_FONT[FONT_LENGHT][5]={   
    // **************************************** 20 - 3F **************************************** //

    {   S1FONT_BLANK,     S2FONT_BLANK,     S3FONT_BLANK,      S4FONT_BLANK,      S5FONT_BLANK},      //  BLANK																										
    {   S1FONT_EXC,       S2FONT_EXC,       S3FONT_EXC,        S4FONT_EXC,        S5FONT_EXC},        //  EXC   !																										
    {   S1FONT_QUOTE_2,   S2FONT_QUOTE_2,   S3FONT_QUOTE_2,    S4FONT_QUOTE_2,    S5FONT_QUOTE_2},    //  QUOTE_2   "																										
    {   S1FONT_HASH,      S2FONT_HASH,      S3FONT_HASH,       S4FONT_HASH,       S5FONT_HASH},       //  HASH   #																										
    {   S1FONT_DOLLAR,    S2FONT_DOLLAR,    S3FONT_DOLLAR,     S4FONT_DOLLAR,     S5FONT_DOLLAR},     //  DOLLAR   $																										
    {   S1FONT_PERCENT,   S2FONT_PERCENT,   S3FONT_PERCENT,    S4FONT_PERCENT,    S5FONT_PERCENT},    //  PERCENT   %																										
    {   S1FONT_AM,        S2FONT_AM,        S3FONT_AM,         S4FONT_AM,         S5FONT_AM},         //  AM   &																										
    {   S1FONT_QUOTE_1,   S2FONT_QUOTE_1,   S3FONT_QUOTE_1,    S4FONT_QUOTE_1,    S5FONT_QUOTE_1},    //  QUOTE_1   '																										
    {   S1FONT_PER_O,     S2FONT_PER_O,     S3FONT_PER_O,      S4FONT_PER_O,      S5FONT_PER_O},      //  PER_O   (																										
    {   S1FONT_PER_C,     S2FONT_PER_C,     S3FONT_PER_C,      S4FONT_PER_C,      S5FONT_PER_C},      //  PER_C   )																										
    {   S1FONT_AS,        S2FONT_AS,        S3FONT_AS,         S4FONT_AS,         S5FONT_AS},         //  AS   *																										
    {   S1FONT_PLUS,      S2FONT_PLUS,      S3FONT_PLUS,       S4FONT_PLUS,       S5FONT_PLUS},       //  PLUS   +																										
    {   S1FONT_COMA,      S2FONT_COMA,      S3FONT_COMA,       S4FONT_COMA,       S5FONT_COMA},       //  COMA   ,																										
    {   S1FONT_HYPHEN,    S2FONT_HYPHEN,    S3FONT_HYPHEN,     S4FONT_HYPHEN,     S5FONT_HYPHEN},     //  HYPHEN   -																										
    {   S1FONT_FULLSTOP,  S2FONT_FULLSTOP,  S3FONT_FULLSTOP,   S4FONT_FULLSTOP,   S5FONT_FULLSTOP},   //  FULLSTOP   .																										
    {   S1FONT_SLASH,     S2FONT_SLASH,     S3FONT_SLASH,      S4FONT_SLASH,      S5FONT_SLASH},      //  SLASH   /																										
    
    {   S1FONT_0,         S2FONT_0,         S3FONT_0,          S4FONT_0,          S5FONT_0},          //  0   0																										
    {   S1FONT_1,         S2FONT_1,         S3FONT_1,          S4FONT_1,          S5FONT_1},          //  1   1																										
    {   S1FONT_2,         S2FONT_2,         S3FONT_2,          S4FONT_2,          S5FONT_2},          //  2   2																										
    {   S1FONT_3,         S2FONT_3,         S3FONT_3,          S4FONT_3,          S5FONT_3},          //  3   3																										
    {   S1FONT_4,         S2FONT_4,         S3FONT_4,          S4FONT_4,          S5FONT_4},          //  4   4																										
    {   S1FONT_5,         S2FONT_5,         S3FONT_5,          S4FONT_5,          S5FONT_5},          //  5   5																										
    {   S1FONT_6,         S2FONT_6,         S3FONT_6,          S4FONT_6,          S5FONT_6},          //  6   6																										
    {   S1FONT_7,         S2FONT_7,         S3FONT_7,          S4FONT_7,          S5FONT_7},          //  7   7																										
    {   S1FONT_8,         S2FONT_8,         S3FONT_8,          S4FONT_8,          S5FONT_8},          //  8   8																										
    {   S1FONT_9,         S2FONT_9,         S3FONT_9,          S4FONT_9,          S5FONT_9},          //  9   9																										
    {   S1FONT_COLON,     S2FONT_COLON,     S3FONT_COLON,      S4FONT_COLON,      S5FONT_COLON},      // COLON   :																										
    {   S1FONT_SEMI,      S2FONT_SEMI,      S3FONT_SEMI,       S4FONT_SEMI,       S5FONT_SEMI},       // SEMI   ;																										
    {   S1FONT_CHEV_L,    S2FONT_CHEV_L,    S3FONT_CHEV_L,     S4FONT_CHEV_L,     S5FONT_CHEV_L},     // CHEV_L   <																										
    {   S1FONT_EQUALS,    S2FONT_EQUALS,    S3FONT_EQUALS,     S4FONT_EQUALS,     S5FONT_EQUALS},     // EQUALS   =																										
    {   S1FONT_CHEV_R,    S2FONT_CHEV_R,    S3FONT_CHEV_R,     S4FONT_CHEV_R,     S5FONT_CHEV_R},     // CHEV_R   >																										
    {   S1FONT_QUES,      S2FONT_QUES,      S3FONT_QUES,       S4FONT_QUES,       S5FONT_QUES},       // QUES   ?																										
    
    // **************************************** 40 - 5F **************************************** //

    {   S1FONT_AT,        S2FONT_AT,        S3FONT_AT,         S4FONT_AT,         S5FONT_AT},         // AT   @																										
    {   S1FONT_A,         S2FONT_A,         S3FONT_A,          S4FONT_A,          S5FONT_A},          // A   A																										
    {   S1FONT_B,         S2FONT_B,         S3FONT_B,          S4FONT_B,          S5FONT_B},          // B   B																										
    {   S1FONT_C,         S2FONT_C,         S3FONT_C,          S4FONT_C,          S5FONT_C},          // C   C																										
    {   S1FONT_D,         S2FONT_D,         S3FONT_D,          S4FONT_D,          S5FONT_D},          // D   D																										
    {   S1FONT_E,         S2FONT_E,         S3FONT_E,          S4FONT_E,          S5FONT_E},          // E   E																										
    {   S1FONT_F,         S2FONT_F,         S3FONT_F,          S4FONT_F,          S5FONT_F},          // F   F																										
    {   S1FONT_G,         S2FONT_G,         S3FONT_G,          S4FONT_G,          S5FONT_G},          // G   G																										
    {   S1FONT_H,         S2FONT_H,         S3FONT_H,          S4FONT_H,          S5FONT_H},          // H   H																										
    {   S1FONT_I,         S2FONT_I,         S3FONT_I,          S4FONT_I,          S5FONT_I},          // I   I																										
    {   S1FONT_J,         S2FONT_J,         S3FONT_J,          S4FONT_J,          S5FONT_J},          // J   J																										
    {   S1FONT_K,         S2FONT_K,         S3FONT_K,          S4FONT_K,          S5FONT_K},          // K   K																										
    {   S1FONT_L,         S2FONT_L,         S3FONT_L,          S4FONT_L,          S5FONT_L},          // L   L																										
    {   S1FONT_M,         S2FONT_M,         S3FONT_M,          S4FONT_M,          S5FONT_M},          // M   M																										
    {   S1FONT_N,         S2FONT_N,         S3FONT_N,          S4FONT_N,          S5FONT_N},          // N   N																										
    {   S1FONT_O,         S2FONT_O,         S3FONT_O,          S4FONT_O,          S5FONT_O},          // O   O																										
    
    {   S1FONT_P,         S2FONT_P,         S3FONT_P,          S4FONT_P,          S5FONT_P},          // P   P																										
    {   S1FONT_Q,         S2FONT_Q,         S3FONT_Q,          S4FONT_Q,          S5FONT_Q},          // Q   Q																										
    {   S1FONT_R,         S2FONT_R,         S3FONT_R,          S4FONT_R,          S5FONT_R},          // R   R																										
    {   S1FONT_S,         S2FONT_S,         S3FONT_S,          S4FONT_S,          S5FONT_S},          // S   S																										
    {   S1FONT_T,         S2FONT_T,         S3FONT_T,          S4FONT_T,          S5FONT_T},          // T   T																										
    {   S1FONT_U,         S2FONT_U,         S3FONT_U,          S4FONT_U,          S5FONT_U},          // U   U																										
    {   S1FONT_V,         S2FONT_V,         S3FONT_V,          S4FONT_V,          S5FONT_V},          // V   V																										
    {   S1FONT_W,         S2FONT_W,         S3FONT_W,          S4FONT_W,          S5FONT_W},          // W   W																										
    {   S1FONT_X,         S2FONT_X,         S3FONT_X,          S4FONT_X,          S5FONT_X},          // X   X																										
    {   S1FONT_Y,         S2FONT_Y,         S3FONT_Y,          S4FONT_Y,          S5FONT_Y},          // Y   Y																										
    {   S1FONT_Z,         S2FONT_Z,         S3FONT_Z,          S4FONT_Z,          S5FONT_Z},          // Z   Z																										
    {   S1FONT_BRACK_O,   S2FONT_BRACK_O,   S3FONT_BRACK_O,    S4FONT_BRACK_O,    S5FONT_BRACK_O},    // BRACK_O   [																										
    {   S1FONT_BACKSLASH, S2FONT_BACKSLASH, S3FONT_BACKSLASH,  S4FONT_BACKSLASH,  S5FONT_BACKSLASH},  // BACKSLASH   																										
    {   S1FONT_BRACK_C,   S2FONT_BRACK_C,   S3FONT_BRACK_C,    S4FONT_BRACK_C,    S5FONT_BRACK_C},    // BRACK_C   
    {   S1FONT_CARET,     S2FONT_CARET,     S3FONT_CARET,      S4FONT_CARET,      S5FONT_CARET},      // CARET   ^																										
    {   S1FONT_UNDER,     S2FONT_UNDER,     S3FONT_UNDER,      S4FONT_UNDER,      S5FONT_UNDER},      // UNDER   _																										
    
    // **************************************** 60 - 7F **************************************** //

    {   S1FONT_QUOTE_3,   S2FONT_QUOTE_3,   S3FONT_QUOTE_3,    S4FONT_QUOTE_3,    S5FONT_QUOTE_3},    // QUOTE_3   ′																										
    {   S1FONT_a,         S2FONT_a,         S3FONT_a,          S4FONT_a,          S5FONT_a},          // a   a																										
    {   S1FONT_b,         S2FONT_b,         S3FONT_b,          S4FONT_b,          S5FONT_b},          // b   b																										
    {   S1FONT_c,         S2FONT_c,         S3FONT_c,          S4FONT_c,          S5FONT_c},          // c   c																										
    {   S1FONT_d,         S2FONT_d,         S3FONT_d,          S4FONT_d,          S5FONT_d},          // d   d																										
    {   S1FONT_e,         S2FONT_e,         S3FONT_e,          S4FONT_e,          S5FONT_e},          // e   e																										
    {   S1FONT_f,         S2FONT_f,         S3FONT_f,          S4FONT_f,          S5FONT_f},          // f   f																										
    {   S1FONT_g,         S2FONT_g,         S3FONT_g,          S4FONT_g,          S5FONT_g},          // g   g																										
    {   S1FONT_h,         S2FONT_h,         S3FONT_h,          S4FONT_h,          S5FONT_h},          // h   h																										
    {   S1FONT_i,         S2FONT_i,         S3FONT_i,          S4FONT_i,          S5FONT_i},          // i   i																										
    {   S1FONT_j,         S2FONT_j,         S3FONT_j,          S4FONT_j,          S5FONT_j},          // j   j																										
    {   S1FONT_k,         S2FONT_k,         S3FONT_k,          S4FONT_k,          S5FONT_k},          // k   k																										
    {   S1FONT_l,         S2FONT_l,         S3FONT_l,          S4FONT_l,          S5FONT_l},          // l   l																										
    {   S1FONT_m,         S2FONT_m,         S3FONT_m,          S4FONT_m,          S5FONT_m},          // m   m																										
    {   S1FONT_n,         S2FONT_n,         S3FONT_n,          S4FONT_n,          S5FONT_n},          // n   n																										
    {   S1FONT_o,         S2FONT_o,         S3FONT_o,          S4FONT_o,          S5FONT_o},          // o   o																										
    
    {   S1FONT_p,         S2FONT_p,         S3FONT_p,          S4FONT_p,          S5FONT_p},          // p   p																										
    {   S1FONT_q,         S2FONT_q,         S3FONT_q,          S4FONT_q,          S5FONT_q},          // q   q																										
    {   S1FONT_r,         S2FONT_r,         S3FONT_r,          S4FONT_r,          S5FONT_r},          // r   r																										
    {   S1FONT_s,         S2FONT_s,         S3FONT_s,          S4FONT_s,          S5FONT_s},          // s   s																										
    {   S1FONT_t,         S2FONT_t,         S3FONT_t,          S4FONT_t,          S5FONT_t},          // t   t																										
    {   S1FONT_u,         S2FONT_u,         S3FONT_u,          S4FONT_u,          S5FONT_u},          // u   u																										
    {   S1FONT_v,         S2FONT_v,         S3FONT_v,          S4FONT_v,          S5FONT_v},          // v   v																										
    {   S1FONT_w,         S2FONT_w,         S3FONT_w,          S4FONT_w,          S5FONT_w},          // w   w																										
    {   S1FONT_x,         S2FONT_x,         S3FONT_x,          S4FONT_x,          S5FONT_x},          // x   x																										
    {   S1FONT_y,         S2FONT_y,         S3FONT_y,          S4FONT_y,          S5FONT_y},          // y   y																										
    {   S1FONT_z,         S2FONT_z,         S3FONT_z,          S4FONT_z,          S5FONT_z},          // z   z																										
    {   S1FONT_BRACE_O,   S2FONT_BRACE_O,   S3FONT_BRACE_O,    S4FONT_BRACE_O,    S5FONT_BRACE_O},    // BRACE_O   {																										
    {   S1FONT_PIPE,      S2FONT_PIPE,      S3FONT_PIPE,       S4FONT_PIPE,       S5FONT_PIPE},       // PIPE   |																										
    {   S1FONT_BRACE_C,   S2FONT_BRACE_C,   S3FONT_BRACE_C,    S4FONT_BRACE_C,    S5FONT_BRACE_C},    // BRACE_C   }																										
    {   S1FONT_TILDE,     S2FONT_TILDE,     S3FONT_TILDE,      S4FONT_TILDE,      S5FONT_TILDE},      // TILDE   ~																										
    {   S1FONT_HOLD,      S2FONT_HOLD,      S3FONT_HOLD,       S4FONT_HOLD,       S5FONT_HOLD},       // HOLD   																										
    { S1FONT_CENTER, S2FONT_CENTER, S3FONT_CENTER, S4FONT_CENTER, S5FONT_CENTER},  // CENTER   																										

};