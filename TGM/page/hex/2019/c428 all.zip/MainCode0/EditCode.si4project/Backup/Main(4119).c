#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"

_FOSC(CSW_FSCM_OFF & XT_PLL8);
_FWDT(WDT_OFF);
_FBORPOR(PBOR_ON & BORV_27 & PWRT_OFF & MCLR_DIS);

/*
Fcy=Fosc/4=(Xtal*PLL)/(POST*4)
Fcy=(7.3728MHz*8)/(4)
Fcy=14.7456MHz
Tcy=6.7816840277777777777777777777778e-8
*/

void io_init(void){
	ADPCFG=0xFFFF;
	TRISB=0xF03F;
	TRISC=0xFFFF;
	TRISD=0xFFF1;
	TRISE=0xFF00;
	TRISF=0xFFD3;
}
void int0_init(void){
	_INT0EP=FALLING;
	_INT0IE=EN;
	_INT0IP=PRIORITY_7;
}
void timer1_init(void){
	TMR1=CLR;
	PR1=TMR1_PERIOD;
	_T1IP=PRIORITY_3;
	T1CON=0x0030;
	_T1IE=EN;
	_T1ON=EN;
}
void timer2_init(void){
	TMR2=CLR;
	PR2=TMR2_PERIOD;
	T2CON=0x0030;
	_T2IP=PRIORITY_2;
	_T2IE=EN;
	//_T2ON=SET;
}
void timer3_init(void){
	TMR3=CLR;
	PR3=TMR3_PERIOD;
	T3CON=0x0030;
	_T3IP=PRIORITY_6;
	_T3IE=EN;
	_T3ON=SET;
}
void timer4_init(void){
	TMR4=CLR;
	PR4=TMR4_PERIOD;
	T4CON=0x0030;
	_T4IP=PRIORITY_5;
	_T4IE=EN;
	_T4ON=EN;
}
void config_uart2(void){
	switch(Value.Baudrate){
//		case BR2400:
//			U2BRG=384;
//			break;
		case BR4800:
			U2BRG=191;
			break;
		case BR19200:
			U2BRG=47;
			break;
		case BR38400:
			U2BRG=23;
			break;
		case BR57600:
			U2BRG=15;
			break;
		case BR115200:
			U2BRG=7;
			break;
		default:
			U2BRG=95;
			break;
	}
	switch(Value.Parity){
		case b8o1:
			cbi(U2MODE, BIT1);
			sbi(U2MODE, BIT2);
			break;
		case b8e1:
			sbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
		default:
			cbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
	}
}
void uart2_init(void){
	U2MODE=0x8000;
	U2STA=0x8400;
	config_uart2();
	_U2RXIP=PRIORITY_6;
	_U2TXIP=PRIORITY_4;
	_U2RXIE=EN;
	_U2TXIE=EN;
//USE	rx_en();
}
void ram_init(void){
	u8 ctrl;
	u16 i;
	s16 val[2];
	s16 segment[5];
	ADC_CS=1;
	for(i=0;i<10000;i++) delayxNop();
	read_ram_RTC(CONTROL_REG, &ctrl, 1);

//	Value.Target = read_eeprom(EEP_TARGET);
	read_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
	if(Value.Target>SEG_LIMITMAX||Value.Target<SEG_LIMITMIN){
		Value.Target=0;
		write_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
//		write_eeprom(EEP_TARGET, Value.Target);
	}
//	Value.Actual1 = read_eeprom(EEP_ACTUAL1);
	read_ram_RTC(RAM_ACTUAL1_, (u8 *)&Value.Actual1, 4);
	if(Value.Actual1>SEG_LIMITMAX||Value.Actual1<SEG_LIMITMIN){
		Value.Actual1=0;
		write_ram_RTC(RAM_ACTUAL1_, (u8 *)&Value.Actual1, 4);
//		write_eeprom(EEP_ACTUAL1, Value.Actual1);
	}
//	Value.Actual2 = read_eeprom(EEP_ACTUAL2);
	read_ram_RTC(RAM_ACTUAL2_, (u8 *)&Value.Actual2, 4);
	if(Value.Actual2 > SEG_LIMITMAX || Value.Actual2 < SEG_LIMITMIN){
		Value.Actual2 = 0;
		write_ram_RTC(RAM_ACTUAL2_, (u8 *)&Value.Actual2, 4);
//		write_eeprom(EEP_ACTUAL2, Value.Actual2);
	}
//	Value.Actual3 = read_eeprom(EEP_ACTUAL3);
	read_ram_RTC(RAM_ACTUAL3_, (u8 *)&Value.Actual3, 4);
	if(Value.Actual3>999999999||Value.Actual3<SEG_LIMITMIN){
		Value.Actual3=0;
		write_ram_RTC(RAM_ACTUAL3_, (u8 *)&Value.Actual3, 4);
//		write_eeprom(EEP_ACTUAL3, Value.Actual3);
	}
	Value.Multiplier1	=	read_eeprom(EEP_MUL1);
	if(Value.Multiplier1>6000||Value.Multiplier1<1)	write_eeprom(EEP_MUL1,Value.Multiplier1 = 1);	
	Value.Multiplier2	=	read_eeprom(EEP_MUL2);
	if(Value.Multiplier2>6000||Value.Multiplier2<1)	write_eeprom(EEP_MUL2,Value.Multiplier2 = 1);	
	Value.Multiplier3	=	read_eeprom(EEP_MUL3);
	if(Value.Multiplier3>6000||Value.Multiplier3<1)	write_eeprom(EEP_MUL3,Value.Multiplier3 = 1);	
	Value.Multiplier4	=	read_eeprom(EEP_MUL4);
	if(Value.Multiplier4>6000||Value.Multiplier4<1)	write_eeprom(EEP_MUL4,Value.Multiplier4 = 1);
	
	Value.Divisor1		=	read_eeprom(EEP_DIV1);
	if(Value.Divisor1>6000||Value.Divisor1<1)		write_eeprom(EEP_DIV1,Value.Divisor1 = 1);
	Value.Divisor2		=	read_eeprom(EEP_DIV2);
	if(Value.Divisor2>6000||Value.Divisor2<1)		write_eeprom(EEP_DIV2,Value.Divisor2 = 1);
	Value.Divisor3		=	read_eeprom(EEP_DIV3);
	if(Value.Divisor3>6000||Value.Divisor3<1)		write_eeprom(EEP_DIV3,Value.Divisor3 = 1);
	Value.Divisor4		=	read_eeprom(EEP_DIV4);
	if(Value.Divisor4>6000||Value.Divisor4<1)		write_eeprom(EEP_DIV4,Value.Divisor4 = 1);
	
	Value.DecimalPoint=	read_eeprom(EEP_DP);
	if(Value.DecimalPoint>EDIT_LENGTH||Value.DecimalPoint<0)	write_eeprom(EEP_DP,Value.DecimalPoint = 0);
	
	Value.InputDelay	=	read_eeprom(EEP_INPUTDELAY);
	if(Value.InputDelay>6000|Value.InputDelay<1)		write_eeprom(EEP_INPUTDELAY,Value.InputDelay = 2);

	read_ram_RTC(RAM_ACTUAL3_R,(u8 *)& Value.SetPoint1,4);
	if(Value.SetPoint1>SEG_LIMITMAX||Value.SetPoint1<SEG_LIMITMIN){
		Value.SetPoint1 = 1000;
		write_ram_RTC(RAM_ACTUAL3_R,(u8 *)& Value.SetPoint1,4);
		}
	
#if 0
	Value.SetTactTime=	read_eeprom(EEP_SETTACTTIME);
	if(Value.SetTactTime>6000|Value.SetTactTime<0)		write_eeprom(EEP_SETTACTTIME,Value.SetTactTime = 0);
	
	Value.CycleTimeTotal	=	read_eeprom(EEP_CYCLEPLAN);
	if(Value.CycleTimeTotal>6000||Value.CycleTimeTotal<0)		write_eeprom(EEP_CYCLEPLAN,Value.CycleTimeTotal = 0);

	Value.CycleTimeTarget =	read_eeprom(EEP_CYCLETARGET);
	if(Value.CycleTimeTarget>6000||Value.CycleTimeTarget<0)		write_eeprom(EEP_CYCLETARGET,Value.CycleTimeTarget = 0);

	Value.SetPoint1 =	read_eeprom(EEP_SETPOINT1_L);
	if(Value.SetPoint1>SEG_LIMITMAX||Value.SetPoint1<SEG_LIMITMIN)		write_eeprom(EEP_SETPOINT1_L,Value.SetPoint1 = 1000);

	Value.SetPoint2 =	read_eeprom(EEP_SETPOINT2_L);
	if(Value.SetPoint2>SEG_LIMITMAX||Value.SetPoint2<SEG_LIMITMIN)		write_eeprom(EEP_SETPOINT2_L,Value.SetPoint2 = 1000);

	Value.SetPointMode1 =	read_eeprom(EEP_SETPOINT1_M);
	if(Value.SetPointMode1>6000||Value.SetPointMode1<0)		write_eeprom(EEP_SETPOINT1_M,Value.SetPointMode1 = 0);
	
	Value.SetPointMode2 =	read_eeprom(EEP_SETPOINT2_M);
	if(Value.SetPointMode2>6000||Value.SetPointMode2<0)		write_eeprom(EEP_SETPOINT2_M,Value.SetPointMode2 = 0);
	
	
	Value.TimeReset	=read_eeprom(EEP_TIMERESET);
	if(Value.TimeReset>TIME2400||Value.TimeReset<0)write_eeprom(EEP_TIMERESET,Value.TimeReset=TIME2400);
	
	Value.ResetMode	=read_eeprom(EEP_TIMERESET_M);
	if(Value.ResetMode>7||Value.ResetMode<0)write_eeprom(EEP_TIMERESET_M,Value.ResetMode=0);
	
	Value.Break_EN	=read_eeprom(EEP_TIME_EN);
	if(Value.Break_EN>7||Value.Break_EN<0)write_eeprom(EEP_TIME_EN,Value.Break_EN=0);
	
	for(i=0;i<10;i++){
		Value.Break_OFF[i]=read_eeprom(Time_Off(i));
		if(Value.Break_OFF[i]>TIME2400||Value.Break_OFF[i]<0)	write_eeprom(Time_Off(i),Value.Break_OFF[i]=TIME2400);
		
		Value.Break_ON[i]=read_eeprom(Time_On(i));
		if(Value.Break_ON[i]>TIME2400||Value.Break_ON[i]<0)		write_eeprom(Time_On(i),Value.Break_ON[i]=TIME2400);
		}
	
#endif
	Mode.ADDr=read_eeprom(EEP_SLAVE_ADDRESS);
	Mode.BaudRate=read_eeprom(EEP_BAUDRATE);
	Mode.Parity=read_eeprom(EEP_PARITY);
	Mode.Stop_Bit=read_eeprom(EEP_BITS);
	Mode.Protocol=read_eeprom(EEP_RTU);
	Mode.Dis_mode=read_eeprom(EEP_INPUTDELAY);
	
	if(Mode.Protocol==0xffff)Value.Protocol=RTUs;
	else Value.Protocol=Mode.Protocol;
	
	if(Mode.BaudRate==0xffff)Value.Baudrate=BR9600;
	else Value.Baudrate=Mode.BaudRate;
	
	if(Mode.Parity==0xffff)Value.Parity=b8n1;
	else Value.Parity=Mode.Parity;
	
	if(Mode.Stop_Bit==0xffff)Value.Bits=1;
	else Value.Bits=Mode.Stop_Bit;
	
	if(Mode.ADDr==0xffff)Value.SlaveAddress=1;
	else Value.SlaveAddress=Mode.ADDr;
		
	
/*
	if(Value.RTU>1||Value.RTU<0){
		Value.RTU=1;
		write_eeprom(Value.RTU,EEP_RTU);
	}
	if(Value.SlaveAddress>255||Value.SlaveAddress<0){
		Value.SlaveAddress=1;
		write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
	}
	if(Value.Baudrate>BR57600||Value.Baudrate<BR4800){
		Value.Baudrate=BR9600;
		write_eeprom(EEP_BAUDRATE, Value.Baudrate);
	}
	if(Value.Parity>b8e1||Value.Parity<b8n1){
		Value.Parity=b8n1;
		write_eeprom(EEP_PARITY, Value.Parity);
	}
	if(Value.Bits>2||Value.Bits<1){
		Value.Bits=1;
		write_eeprom(EEP_BITS,Value.Bits);
	}
*/
	Flag.Word=CLR;
	Status.Main=INIT_MODE;
	Modbus.Status=RSP_PV;
	Value.Protocol=RTUs;
	Value.Bye.Word = 62019;
//	Value.Dis_mode=VOLUE;
	
}
s16 main(void){
	io_init();
	timer1_init();
	timer2_init();
	timer3_init();
	timer4_init();
//	rtc_init_ISL();
	ram_init();
	uart2_init();
	int0_init();
	TPIC6B595_init();
	while(1){
		
		}
	return 0;
}

