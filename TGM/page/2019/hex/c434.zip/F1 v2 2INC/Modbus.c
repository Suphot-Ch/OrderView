#if 1
#include <p30f4011.h>
#include <stdio.h>
#include <uart.h>
#include "config.h"
#include "global.h"

const u8 CRCTableHigh[] = {
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,	0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
const u8 CRCTableLow[] = {
	0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
	0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
	0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
	0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
	0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
	0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
	0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
	0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
	0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
	0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
	0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
	0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
	0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;
const u8 HEX2ASCII[]={
	'0',
	'1',
	'2',
	'3',
	'4',
	'5',
	'6',
	'7',
	'8',
	'9',
	'A',
	'B',
	'C',
	'D',
	'E',
	'F'
};

// void func_01_rtu_mode(void);
// void func_01_ascii_mode(void);
void func_03_rtu_mode(void);
// void func_03_ascii_mode(void);
// void func_05_rtu_mode(void);
// void func_05_ascii_mode(void);
void func_06_rtu_mode(void);
// void func_06_ascii_mode(void);
// void func_15_rtu_mode(void);
// void func_15_ascii_mode(void);
void func_16_rtu_mode(void);
// void func_16_ascii_mode(void);

// void (*read_coils[]) (void)={
// 	func_01_rtu_mode,
// 	func_01_ascii_mode
// };
// void (*preset_a_single_coils[]) (void)={
// 	func_05_rtu_mode,
// 	func_05_ascii_mode
// };

void (*read_multi_registers[]) (void)={
	func_03_rtu_mode,
	// func_03_ascii_mode
};

void (*preset_a_single_register[]) (void)={
	func_06_rtu_mode,
	// func_06_ascii_mode
};

void (*preset_multi_registers[]) (void)={
	func_16_rtu_mode,
	// func_16_ascii_mode
};


void tx_en(void){
	RD_485=TX;
	//cbi(IE2, UCA0RXIE);
	//sbi(IE2, UCA0TXIE);
}
void rx_en(void){
	RD_485=RX;
	//sbi(IE2, UCA0RXIE);
	//cbi(IE2, UCA0TXIE);
}
void crc16(u8 *dptr,u8 n){
	u8 i, j;
	
	Modbus.CrcHi=Modbus.CrcLo=0xFF;
	for(i=0;i<n;i++,dptr++){
		j=Modbus.CrcHi^*dptr;
		Modbus.CrcHi=Modbus.CrcLo^CRCTableHigh[j];
		Modbus.CrcLo=CRCTableLow[j];
	}
}
void LRC(u8 *auchMsg, u8 usDataLen){
	unsigned char uchLRC = 0 ; /* LRC char initialized */
	
	while(usDataLen--){ /* pass through message buffer */
		uchLRC+=(*auchMsg); /* add buffer byte without carry */
		auchMsg++;
	}
	uchLRC=((unsigned char)(-((char)uchLRC))) ; /* return twos complement */
	
	Modbus.CrcHi=HEX2ASCII[uchLRC>>4];
	Modbus.CrcLo=HEX2ASCII[uchLRC&0x0F];	
}
u8 ascII2hex(u8 *ascii){	
	u8 buf[2];
	
	buf[0]=(ascii[0]>'9') ? ((ascii[0]-'A')+10) : (ascii[0]-'0');
	buf[1]=(ascii[1]>'9') ? ((ascii[1]-'A')+10) : (ascii[1]-'0');
	return((buf[0]*0x10)+(buf[1]));
}
void ASCII2HEX(u8 *ascii, u8 n){	
	u8 i;
	
	if(Value.Protocol==ASCII){
		n=(n-3)>>1;
		for(i=0;i<n;i++){
			Modbus.Ascii2HexBuf[i]=ascII2hex(&ascii[(i*2)+1]);
		}
	}
	else{
		for(i=0;i<n;i++){
			Modbus.Ascii2HexBuf[i]=ascii[i];
		}
	}
}
u8 mb_modbus_function;
Word32_sType reg_check;
Word32_sType reg_Save;
u8 register_value_in_range(u16 reg_addr, s16 reg_val){
#if 1
	u8 PL;
	switch(reg_addr){
		case MB__TARGET_H:  				// = 08
		case MB__ACTUAL_H:  				// = 10
		case MB__MASTER_H:  				// = 14
		case MB__STEPOINT1_H:				// = 23
		case MB__STEPOINT2_H:				// = 25
			if(mb_modbus_function==6)return;
			reg_check.WordHi = reg_val;
			PL = 1;
			break;
		
		case MB__TARGET_L:  				// = 09
		case MB__ACTUAL_L:  				// = 11
		case MB__MASTER_L:  				// = 15
		case MB__STEPOINT1_L:				// = 24
		case MB__STEPOINT2_L:				// = 26
			if(mb_modbus_function==6)return;
			reg_check.WordLo = reg_val;
			if(reg_check.LWord<=99999 && reg_check.LWord>=0)	PL = 1;
			else PL = 0;
			break;
		
		case MB__INPUT_TYPE:				// = 18
		case MB__TIME_EN:  					// = 54
			if(reg_val<=1 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;

		case MB__MULTI:  					// = 21
		case MB__DIVISOR:  					// = 22
		case MB__CYCLETIME: 				// = 28
		case MB__INPUT_DELAY:				// = 29
		case MB__DOWNTIME_DAY:  			// = 46
		case MB__SUMTIME_DAY:  				// = 50
			if(reg_val<=999 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;

		case MB__DECIMALPOINT:				// = 27
			if(reg_val<=4 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		
		case MB__DAY2WEEK: 	 					// = 39
			if(reg_val<=6 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		case MB__DATE: 	 					// = 39
			if(reg_val<=31 && reg_val>=1)	PL = 1;
			else PL = 0;
			break;
		case MB__MONTH:  					// = 40
			if(reg_val<=12 && reg_val>=1)	PL = 1;
			else PL = 0;
			break;
		case MB__YEAR:	  					// = 41
			if(reg_val<=99 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		case MB__HOUR:	  					// = 42
		case MB__DOWNTIME_HOUR:  			// = 47
		case MB__SUMTIME_HOUR:  			// = 51
			if(reg_val<=23 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		case MB__MINUTE:  					// = 43
		case MB__SECOND:  					// = 44
		case MB__DOWNTIME_MINUTE:  			// = 48
		case MB__DOWNTIME_SECOND:  			// = 49
		case MB__SUMTIME_MINUTE:  			// = 52
		case MB__SUMTIME_SECOND:  			// = 53
			if(reg_val<=59 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;

		case MB__CHART_0:  					// = 30
		case MB__CHART_1:  					// = 31
		case MB__CHART_2:  					// = 32
		case MB__CHART_3:  					// = 33
		case MB__CHART_4:  					// = 34
		case MB__CHART_5:  					// = 35
		case MB__CHART_6:  					// = 36
		case MB__CHART_7:  					// = 37
			if(reg_val<=0x7F && reg_val>=0x20)	PL = 1;
			else PL = 0;
			break;
		
		case MB__TIME_ON_0: 					// = 55
		case MB__TIME_ON_1: 					// = 56
		case MB__TIME_ON_2: 					// = 57
		case MB__TIME_ON_3: 					// = 58
		case MB__TIME_ON_4: 					// = 59
		case MB__TIME_ON_5: 					// = 60
		case MB__TIME_ON_6: 					// = 61
		case MB__TIME_ON_7: 					// = 62
		case MB__TIME_ON_8: 					// = 63
		case MB__TIME_ON_9: 					// = 64
		case MB__TIME_OFF_0: 					// = 65
		case MB__TIME_OFF_1: 					// = 66
		case MB__TIME_OFF_2: 					// = 67
		case MB__TIME_OFF_3: 					// = 68
		case MB__TIME_OFF_4: 					// = 69
		case MB__TIME_OFF_5: 					// = 70
		case MB__TIME_OFF_6: 					// = 71
		case MB__TIME_OFF_7: 					// = 72
		case MB__TIME_OFF_8: 					// = 73
		case MB__TIME_OFF_9: 					// = 74
		case MB__TIME_RESET_0: 					// = 75
		case MB__TIME_RESET_1: 					// = 76
		case MB__TIME_RESET_2: 					// = 77
		case MB__TIME_RESET_3: 					// = 78
		case MB__TIME_RESET_4: 					// = 79
		case MB__TIME_RESET_5: 					// = 80
		case MB__TIME_RESET_6: 					// = 81
		case MB__TIME_RESET_7: 					// = 82
		case MB__TIME_RESET_8: 					// = 83
		case MB__TIME_RESET_9: 					// = 84
			if(reg_val<=0x1800 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;

		case MB__BAUDRATE:  					// = 85
			if(reg_val<=4 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		case MB__PARITY:  						// = 86
			if(reg_val<=0 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		case MB__ADD:  							// = 87
			if(reg_val<=1 && reg_val>=0)	PL = 1;
			else PL = 0;
			break;
		default:
			return 0;
			break;
		}
		return PL;
#endif	
}
u8 register_value_Save(u16 reg_addr, s16 reg_val){
#if 1
	Byte_sType reg_fun;
	u8 PL;
	u32 are;
	switch(reg_addr){
		case MB__TARGET_H:  				// = 08
		case MB__ACTUAL_H:  				// = 10
		case MB__MASTER_H:  				// = 14
		case MB__STEPOINT1_H:				// = 23
		case MB__STEPOINT2_H:				// = 25
			if(mb_modbus_function==6)return;
			reg_Save.WordHi = reg_val;
			PL = 1;
			break;
		
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__TARGET_L:  				// = 09
			if(mb_modbus_function==6)return;
			reg_Save.WordLo = reg_val;
			Value.Target = reg_Save.LWord;
			write_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
			break;
		case MB__ACTUAL_L:  				// = 11
			if(mb_modbus_function==6)return;
			reg_Save.WordLo = reg_val;
			Value.Actual1 = reg_Save.LWord;
			write_ram_RTC(RAM_ACTUAL1_, (u8 *)&Value.Actual1, 4);
			break;
		case MB__STEPOINT1_L:				// = 24
			if(mb_modbus_function==6)return;
			reg_Save.WordLo = reg_val;
			Value.SetPoint1 = reg_Save.LWord;
			write_eeprom_32(EEP_SETPOINT1_H,&Value.SetPoint1);
			break;
		case MB__STEPOINT2_L:				// = 26
			if(mb_modbus_function==6)return;
			reg_Save.WordLo = reg_val;
			Value.SetPoint2 = reg_Save.LWord;
			write_eeprom_32(EEP_SETPOINT2_H,&Value.SetPoint2);
			break;
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__MASTER_L:  				// = 15
			if(mb_modbus_function==6)return;
			reg_Save.WordLo = reg_val;
			Value.MasterPlan = reg_Save.LWord;
			write_ram_RTC(RAM_MASTER, (u8 *)&Value.MasterPlan, 4);
			break;
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__INPUT_TYPE:				// = 18
			Value.InputType = reg_val;
			write_eeprom(EEP_INPUT_TYPE, Value.InputType);
			break;
		case MB__MULTI:  					// = 21
			Value.Multiplier1 = reg_val;
			write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__DIVISOR:  					// = 22
			Value.Divisor1 = reg_val;
			write_eeprom(EEP_DIV1, reg_val);
			break;
		case MB__CYCLETIME: 				// = 28
			Value.CycleTimeTarget = reg_val;
			write_eeprom(EEP_CYCLETARGET, reg_val);
			break;
		case MB__INPUT_DELAY:				// = 29
			Value.InputDelay = reg_val;
			if(Value.InputDelay<1)Value.InputDelay=1;
			write_eeprom(EEP_INPUTDELAY, Value.InputDelay);
			break;
		case MB__DECIMALPOINT:				// = 27
			Value.DecimalPoint = reg_val;
			write_eeprom(EEP_DP, reg_val);
			break;
		
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__DAY2WEEK: 	 					// = 39
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(DW_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__DATE: 	 					// = 39
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(DT_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__MONTH:  					// = 40
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(MO_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__YEAR:	  					// = 41
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(YR_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__HOUR:	  					// = 42
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			reg_fun.Bytes = reg_fun.Bytes|0x80;
			write_time_rtc(HR_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__MINUTE:  					// = 43
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(MN_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;
		case MB__SECOND:  					// = 44
			reg_fun.H = reg_val/10;
			reg_fun.L = reg_val%10;
			write_time_rtc(SC_REG, reg_fun.Bytes);
			// write_eeprom(EEP_MUL1, reg_val);
			break;

//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__DOWNTIME_DAY:  			// = 46
			Value.DownTimeDay = reg_val;
			write_eeprom(EEP_DOWNTIME_DAY, reg_val);
			break;
		case MB__DOWNTIME_HOUR:  			// = 47
			Value.DownTimeHour = reg_val;
			write_eeprom(EEP_DOWNTIME_HOUR, reg_val);
			break;
		case MB__DOWNTIME_MINUTE:  			// = 48
			Value.DownTimeMinute = reg_val;
			write_eeprom(EEP_DOWNTIME_MINUTE, reg_val);
			break;
		case MB__DOWNTIME_SECOND:  			// = 49
			Value.DownTimeSecond = reg_val;
			write_eeprom(EEP_DOWNTIME_SECOND, reg_val);
			break;
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__SUMTIME_DAY:  				// = 50
			Value.SummaryTimeDay = reg_val;
			write_eeprom(EEP_SUMMARYTIME_DAY, reg_val);
			break;
		case MB__SUMTIME_HOUR:  			// = 51
			Value.SummaryTimeHour = reg_val;
			write_eeprom(EEP_SUMMARYTIME_HOUR, reg_val);
			break;
		case MB__SUMTIME_MINUTE:  			// = 52
			Value.SummaryTimeMinute = reg_val;
			write_eeprom(EEP_SUMMARYTIME_MINUTE, reg_val);
			break;
		case MB__SUMTIME_SECOND:  			// = 53
			Value.SummaryTimeSecond = reg_val;
			write_eeprom(EEP_SUMMARYTIME_SECOND, reg_val);
			break;
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__CHART_0:  					// = 30
		case MB__CHART_1:  					// = 31
		case MB__CHART_2:  					// = 32
		case MB__CHART_3:  					// = 33
		case MB__CHART_4:  					// = 34
		case MB__CHART_5:  					// = 35
		case MB__CHART_6:  					// = 36
		case MB__CHART_7:  					// = 37
			are = MB__CHART_7-reg_addr;
			Value.Chart[are] = reg_val;
			write_eeprom(EEP_CHART_ASCII + (are*2), reg_val);
			break;
		
//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__TIME_EN:  					// = 54
			Value.Time_EN = reg_val;
			write_eeprom(EEP_TIME_EN, reg_val);
			break;
		case MB__TIME_ON_0: 					// = 55
		case MB__TIME_ON_1: 					// = 56
		case MB__TIME_ON_2: 					// = 57
		case MB__TIME_ON_3: 					// = 58
		case MB__TIME_ON_4: 					// = 59
		case MB__TIME_ON_5: 					// = 60
		case MB__TIME_ON_6: 					// = 61
		case MB__TIME_ON_7: 					// = 62
		case MB__TIME_ON_8: 					// = 63
		case MB__TIME_ON_9: 					// = 64
			are = reg_addr-MB__TIME_ON_0;
			Value.Time_ON[TIMER_CHANNEL_MAX-are].Word = reg_val;
			write_eeprom(EEP_TIMEON_00+(are*2), reg_val);
			break;
		case MB__TIME_OFF_0: 					// = 65
		case MB__TIME_OFF_1: 					// = 66
		case MB__TIME_OFF_2: 					// = 67
		case MB__TIME_OFF_3: 					// = 68
		case MB__TIME_OFF_4: 					// = 69
		case MB__TIME_OFF_5: 					// = 70
		case MB__TIME_OFF_6: 					// = 71
		case MB__TIME_OFF_7: 					// = 72
		case MB__TIME_OFF_8: 					// = 73
		case MB__TIME_OFF_9: 					// = 74
			are = MB__TIME_OFF_9-reg_addr;
			Value.Time_OFF[TIMER_CHANNEL_MAX-are].Word = reg_val;
			write_eeprom(EEP_TIMEOFF_00+(are*2), reg_val);
			break;
		case MB__TIME_RESET_0: 					// = 75
		case MB__TIME_RESET_1: 					// = 76
		case MB__TIME_RESET_2: 					// = 77
		case MB__TIME_RESET_3: 					// = 78
		case MB__TIME_RESET_4: 					// = 79
		case MB__TIME_RESET_5: 					// = 80
		case MB__TIME_RESET_6: 					// = 81
		case MB__TIME_RESET_7: 					// = 82
		case MB__TIME_RESET_8: 					// = 83
		case MB__TIME_RESET_9: 					// = 84
			are = MB__TIME_RESET_9-reg_addr;
			Value.Time_Reset[TIMER_CHANNEL_MAX-are].Word = reg_val;
			write_eeprom(EEP_TIMERESET_00+(are*2), reg_val);
			break;

//***************************************************************//
//***************************************************************//
//***************************************************************//
		case MB__BAUDRATE:  					// = 85
			Value.Baudrate = reg_val;
			write_eeprom(EEP_BAUDRATE, reg_val);
			config_uart2();
			break;
		case MB__PARITY:  						// = 86
			Value.Parity = reg_val;
			write_eeprom(EEP_PARITY, reg_val);
			config_uart2();
			break;
		case MB__ADD:  							// = 87
			Value.SlaveAddress = reg_val;
			write_eeprom(EEP_SLAVE_ADDRESS, reg_val);
			break;
		default:
			return 0;
			break;
		}
#endif	
}
void exeption_response(u8 ExeptionCode){
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		Value.Protocol=RTUs;
		// if(Value.Protocol==RTUs){
			Modbus.ByteRsp=0;
			Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;	
			Modbus.RspBuf[Modbus.ByteRsp++]=0x80|Modbus.Ascii2HexBuf[1];	
			Modbus.RspBuf[Modbus.ByteRsp++]=ExeptionCode;	
			crc16(Modbus.RspBuf, 3);
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
			Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
		// }
		// else{
		// 	Modbus.ByteRsp=0;
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=':';
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress>>4];
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress&0x0F];	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[(0x80|Modbus.Ascii2HexBuf[1])>>4];	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[(0x80|Modbus.Ascii2HexBuf[1])&0x0F];	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[ExeptionCode>>4];	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[ExeptionCode&0x0F];	
		// 	ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
		// 	LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
		// 	Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
		// 	Modbus.RspBuf[Modbus.ByteRsp++]='\r';
		// 	Modbus.RspBuf[Modbus.ByteRsp++]='\n';
		// }
		MB_Dptr=Modbus.RspBuf;	
		Flag.FTX=1;
		Modbus.TXTimeOut=0;
		tx_en();
		U2TXREG=*MB_Dptr++;
	}
}
void save_to_eeprom(u8 addr, s16 *dptr){
}
void get_data_last(u8 *dptr){
	DataLastMB=0;
	DataLastMB=*dptr--;
	DataLastMB<<=8;
	DataLastMB|=*dptr;
}
void get_address(u8 *dptr){
	DataLastMB=0;
	DataLastMB=*dptr--;
	DataLastMB<<=8;
	DataLastMB|=*dptr;
}
void func_03_rtu_mode(void){
	u16 i;
	Word16_uType NRegs, REGISTER_ADDR;
	u8 *dptr;
	
	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
		NRegs.H=Modbus.Ascii2HexBuf[4];
		NRegs.L=Modbus.Ascii2HexBuf[5];
		if(NRegs.Word>=1&&NRegs.Word<=MB__ADD+1){	
			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
			mb_modbus_function = 3;
				if((REGISTER_ADDR.Word>=MB__MODEL)&&((REGISTER_ADDR.Word+NRegs.Word)<=MB__ADD+1)){
					dptr=(u8 *)&Value.Model.H;
					dptr-=REGISTER_ADDR.Word<<1;
					// dptr+=2;
					Modbus.ByteRsp=0;
					Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];				
					NRegs.Word<<=1;
					Modbus.RspBuf[Modbus.ByteRsp++]=NRegs.Word;
					for(i=0;i<NRegs.Word;i++,dptr--){
						Modbus.RspBuf[Modbus.ByteRsp++]=*dptr;
					}
					crc16(Modbus.RspBuf, Modbus.ByteRsp);
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
					MB_Dptr=Modbus.RspBuf;
					Flag.FTX=1;
					Modbus.TXTimeOut=0;
					tx_en();
					U2TXREG=*MB_Dptr++;
				}
				else{
					exeption_response(ILLEGAL_DATA_ADDRESS);	
				}
			}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
void func_06_rtu_mode(void){
	Word16_uType REGISTER_VAL, REGISTER_ADDR;
	u8 *dptr;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
		mb_modbus_function = 6;
				if((REGISTER_ADDR.Word>=MB__MODEL)&&(REGISTER_ADDR.Word<=MB__ADD)){
					REGISTER_VAL.H=Modbus.Ascii2HexBuf[4];
					REGISTER_VAL.L=Modbus.Ascii2HexBuf[5];
					Flag.DATA_NOT_SUPPORT=0;
					if(register_value_in_range(REGISTER_ADDR.Word, REGISTER_VAL.Word)){
						register_value_Save(REGISTER_ADDR.Word, REGISTER_VAL.Word);

						if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
							Modbus.ByteRsp=0;
							Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[1];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[2];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[3];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[4];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[5];
							crc16(Modbus.Ascii2HexBuf, Modbus.ByteRsp);	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
							MB_Dptr=Modbus.RspBuf;
							Flag.FTX=1;
							Modbus.TXTimeOut=0;
							tx_en();
							U2TXREG=*MB_Dptr++;
							}
						}
					else{
						exeption_response(ILLEGAL_DATA_VALUE);	
						}
					}
		else{
			exeption_response(ILLEGAL_DATA_ADDRESS);	
		}
	}
}
void func_16_rtu_mode(void){	
	Word16_uType QUANTITY, REGISTER_ADDR, REGISTER_VAL;
	u8 *dptr, i, BYTE_COUNT;

	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
		if(Modbus.ByteReq<11) return;	
		crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1])return;	
		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
		QUANTITY.H=Modbus.Ascii2HexBuf[4];
		QUANTITY.L=Modbus.Ascii2HexBuf[5];
		BYTE_COUNT=Modbus.Ascii2HexBuf[6];
		mb_modbus_function = 16;
		if(((QUANTITY.Word>=1)&&(QUANTITY.Word<=MB__ADD+1))&&((QUANTITY.Word<<1)==BYTE_COUNT)){
			if((REGISTER_ADDR.Word>=MB__MODEL)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=MB__ADD+1)){
				Flag.DATA_NOT_SUPPORT=0;
				for(i=0;i<QUANTITY.Word;i++){
					REGISTER_VAL.H=Modbus.Ascii2HexBuf[(i*2)+7];
					REGISTER_VAL.L=Modbus.Ascii2HexBuf[(i*2)+8];
					if(!register_value_in_range(REGISTER_ADDR.Word+i,REGISTER_VAL.Word)){
						Flag.DATA_NOT_SUPPORT=1;
						break;
					}
				}
				if(Flag.DATA_NOT_SUPPORT==0){
					for(i=0;i<QUANTITY.Word;i++){
						REGISTER_VAL.H=Modbus.Ascii2HexBuf[(i*2)+7];
						REGISTER_VAL.L=Modbus.Ascii2HexBuf[(i*2)+8];
						register_value_Save(REGISTER_ADDR.Word+i,REGISTER_VAL.Word);
					}
				
					if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
						Modbus.ByteRsp=0;
						Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[1];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[2];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[3];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[4];	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.Ascii2HexBuf[5];
						crc16(Modbus.Ascii2HexBuf, Modbus.ByteRsp);	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				MB_Dptr=Modbus.RspBuf;
				Flag.FTX=1;
				Modbus.TXTimeOut=0;
				tx_en();
				U2TXREG=*MB_Dptr++;
					}
				}
				else{
					exeption_response(ILLEGAL_DATA_VALUE);						
				}
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);	
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);		
		}	
	}
}
// void func_01_rtu_mode(void){
// 	u16 i;
// 	Word16_uType QUANTITY, REGISTER_ADDR;
// 	u8 *dptr, BYTE_COUNT;
	
// 	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 		if(Modbus.ByteReq!=8) return;	
// 		crc16(Modbus.ReqBuf, 6);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
// 		QUANTITY.H=Modbus.Ascii2HexBuf[4];
// 		QUANTITY.L=Modbus.Ascii2HexBuf[5];
// 		BYTE_COUNT=(QUANTITY.Word/8)+1;
// 		if(QUANTITY.Word>=1&&QUANTITY.Word<=3){	
// 			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
// 			if((REGISTER_ADDR.Word>=0x0000)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=0x0003)){
// 				dptr=&Value.CoilOutput;
// 				Modbus.ByteRsp=0;
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];		
// 				Modbus.RspBuf[Modbus.ByteRsp++]=BYTE_COUNT;
// 				for(i=0;i<BYTE_COUNT;i++,dptr--){
// 					Modbus.RspBuf[Modbus.ByteRsp++]=*dptr;
// 				}
// 				crc16(Modbus.RspBuf, Modbus.ByteRsp);
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 			}
// 		}
// 		else{	
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}	
// 	}
// }
// void func_01_ascii_mode(void){
// 	u16 i;
// 	Word16_uType QUANTITY, REGISTER_ADDR;
// 	u8 *dptr, BYTE_COUNT;
	
// 	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 		if(Modbus.ByteReq!=17) return;	
// 		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
// 		QUANTITY.H=Modbus.Ascii2HexBuf[4];
// 		QUANTITY.L=Modbus.Ascii2HexBuf[5];
// 		BYTE_COUNT=(QUANTITY.Word/8)+1;
// 		if(QUANTITY.Word>=1&&QUANTITY.Word<=3){	
// 			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
// 			if((REGISTER_ADDR.Word>=0x0000)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=0x0003)){
// 				dptr=&Value.CoilOutput;
// 				Modbus.RspBuf[Modbus.ByteRsp++]=':';
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[BYTE_COUNT>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[BYTE_COUNT&0x0F];	
// 				for(i=0;i<BYTE_COUNT;i++,dptr--){
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr>>4];
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr&0x0F];
// 				}
// 				ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
// 				LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 			}
// 		}
// 		else{	
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}	
// 	}
// }
// void func_03_ascii_mode(void){
// 	u16 i;
// 	Word16_uType NRegs, REGISTER_ADDR;
// 	u8 *dptr;

// 	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 		if(Modbus.ByteReq!=17) return;	
// 		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;			
// 		NRegs.H=Modbus.Ascii2HexBuf[4];
// 		NRegs.L=Modbus.Ascii2HexBuf[5];
// 		if(NRegs.Word>=1&&NRegs.Word<=MB__ADD+1){	
// 			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
// 			if((REGISTER_ADDR.Word>=MB__MODEL)&&((REGISTER_ADDR.Word+NRegs.Word)<=MB__ADD+1)){
// //				dptr=(u8 *)&Value.Chart[3].H;
// 				dptr-=REGISTER_ADDR.Word<<1;
					
// 				Modbus.ByteRsp=0;
// 				Modbus.RspBuf[Modbus.ByteRsp++]=':';
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress>>4];
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Value.SlaveAddress&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];					
// 				NRegs.Word<<=1;
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[NRegs.Word>>4];
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[NRegs.Word&0x0F];
// 				for(i=0;i<NRegs.Word;i++,dptr--){
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr>>4];
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[*dptr&0x0F];
// 				}
// 				ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
// 				LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 				}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 				}
// 		}
// 		else{
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}	
// 	}
// }
// void func_05_rtu_mode(void){
// 	u16 i;
// 	Word16_uType OUTPUT_VALUE, REGISTER_ADDR;
	
// 	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 		if(Modbus.ByteReq!=8) return;	
// 		crc16(Modbus.ReqBuf, 6);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;
// 		OUTPUT_VALUE.H=Modbus.Ascii2HexBuf[4];
// 		OUTPUT_VALUE.L=Modbus.Ascii2HexBuf[5];
// 		if((OUTPUT_VALUE.Word==0x0000)||(OUTPUT_VALUE.Word==0xFF00)){	
// 			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
// 			if((REGISTER_ADDR.Word>=0)&&(REGISTER_ADDR.Word<=3)){
// 				if(OUTPUT_VALUE.Word==0xFF00){
// 					Flag.CoilsOn=1;
// 				}
// 				else{
// 					Flag.CoilsOn=0;
// 				}
// 				switch(REGISTER_ADDR.Word){
// 					case 0:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT0);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT0);
// 						}
// 						break;
// 					case 1:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT1);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT1);
// 						}
// 						break;
// 					case 2:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT2);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT2);
// 						}
// 						break;
// 				}
// 				for(i=0;i<Modbus.ByteReq;i++){
// 					Modbus.RspBuf[i]=Modbus.ReqBuf[i];
// 				}
// 				Modbus.ByteRsp=Modbus.ByteReq;
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 			}
// 		}
// 		else{	
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}	
// 	}
// }
// void func_05_ascii_mode(void){
// 	Word16_uType OUTPUT_VALUE, REGISTER_ADDR;
	
// 	if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 		if(Modbus.ByteReq!=17) return;	
// 		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
// 		OUTPUT_VALUE.H=Modbus.Ascii2HexBuf[4];
// 		OUTPUT_VALUE.L=Modbus.Ascii2HexBuf[5];
// 		if((OUTPUT_VALUE.Word==0x0000)||(OUTPUT_VALUE.Word==0xFF00)){	
// 			REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 			REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];
// 			if((REGISTER_ADDR.Word>=0)&&(REGISTER_ADDR.Word<=0)){
// 				if(OUTPUT_VALUE.Word==0xFF00){
// 					Flag.CoilsOn=1;
// 				}
// 				else{
// 					Flag.CoilsOn=0;
// 				}
// 				switch(REGISTER_ADDR.Word){
// 					case 0:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT0);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT0);
// 						}
// 						break;
// 					case 1:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT1);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT1);
// 						}
// 						break;
// 					case 2:
// 						if(Flag.CoilsOn){
// 							sbi(Value.CoilOutput, BIT2);
// 						}
// 						else{
// 							cbi(Value.CoilOutput, BIT2);
// 						}
// 						break;
// 				}
// 				Modbus.RspBuf[Modbus.ByteRsp++]=':';
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[6]>>4];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[6]&0x0F];	
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\r';
// 				Modbus.RspBuf[Modbus.ByteRsp++]='\n';
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 			}
// 		}
// 		else{	
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}	
// 	}
// }
// void func_06_ascii_mode(void){
// 	Word16_uType REGISTER_VAL, REGISTER_ADDR;
// 	u8 *dptr;

// 	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
// 		if(Modbus.ByteReq!=17) return;	
// 		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
// 		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
// 		if((REGISTER_ADDR.Word>=MB__MODEL)&&(REGISTER_ADDR.Word<=MB__ADD)){
// 			REGISTER_VAL.H=Modbus.Ascii2HexBuf[4];
// 			REGISTER_VAL.L=Modbus.Ascii2HexBuf[5];
// 			Flag.DATA_NOT_SUPPORT=0;
// 			if(register_value_in_range(REGISTER_ADDR.Word, REGISTER_VAL.Word)){
// //				dptr=(u8 *)&Value.Chart[3].H;
// 				dptr-=REGISTER_ADDR.Word<<1;
				
// 				*dptr--=REGISTER_VAL.H;
// 				*dptr=REGISTER_VAL.L;
				
// 				if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 					Modbus.RspBuf[Modbus.ByteRsp++]=':';
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
// 					ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
// 					LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
// 					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
// 					Modbus.RspBuf[Modbus.ByteRsp++]='\r';
// 					Modbus.RspBuf[Modbus.ByteRsp++]='\n';
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 				}
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_VALUE);	
// 			}
// 		}
// 		else{
// 			exeption_response(ILLEGAL_DATA_ADDRESS);	
// 		}
// 	}
// }
// void func_16_ascii_mode(void){
// 	u16 BYTE_COUNT;
// 	Word16_uType QUANTITY, REGISTER_ADDR, REGISTER_VAL;
// 	u8 *dptr, i;

// 	if((Modbus.Ascii2HexBuf[0]==Value.SlaveAddress)||(Modbus.Ascii2HexBuf[0]==0)){
// 		if(Modbus.ByteReq<27) return;	
// 		LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
// 		if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])return;	
// 		REGISTER_ADDR.H=Modbus.Ascii2HexBuf[2];
// 		REGISTER_ADDR.L=Modbus.Ascii2HexBuf[3];	
// 		QUANTITY.H=Modbus.Ascii2HexBuf[4];
// 		QUANTITY.L=Modbus.Ascii2HexBuf[5];
// 		BYTE_COUNT=Modbus.Ascii2HexBuf[6];
// 		if(((QUANTITY.Word>=1)&&(QUANTITY.Word<=MB__ADD+1))&&((QUANTITY.Word<<1)==BYTE_COUNT)){
// 			if((REGISTER_ADDR.Word>=MB__MODEL)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=MB__ADD+1)){
// 				Flag.DATA_NOT_SUPPORT=0;
// 				for(i=0;i<QUANTITY.Word;i++){
// 					REGISTER_VAL.H=Modbus.Ascii2HexBuf[(i*2)+7];
// 					REGISTER_VAL.L=Modbus.Ascii2HexBuf[(i*2)+8];
// 					if(!register_value_in_range(REGISTER_ADDR.Word+i, REGISTER_VAL.Word)){
// 						Flag.DATA_NOT_SUPPORT=1;
// 						break;
// 					}
// 				}
// 				if(Flag.DATA_NOT_SUPPORT==0){
// //					dptr=(u8 *)&Value.Chart[3].H;
// 					dptr-=REGISTER_ADDR.Word<<1;
					
// 					for(i=7;i<BYTE_COUNT+7;i++, dptr--){
// 						*dptr=Modbus.Ascii2HexBuf[i];
// 					}
// 					if(Modbus.Ascii2HexBuf[0]==Value.SlaveAddress){
// 						Modbus.RspBuf[Modbus.ByteRsp++]=':';
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]>>4];
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[0]&0x0F];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]>>4];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[1]&0x0F];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]>>4];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[2]&0x0F];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]>>4];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[3]&0x0F];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]>>4];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[4]&0x0F];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]>>4];	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=HEX2ASCII[Modbus.Ascii2HexBuf[5]&0x0F];	
// 						ASCII2HEX(&Modbus.RspBuf[0], Modbus.ByteRsp+2);
// 						LRC(Modbus.Ascii2HexBuf, (Modbus.ByteRsp-1)/2);	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
// 						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
// 						Modbus.RspBuf[Modbus.ByteRsp++]='\r';
// 						Modbus.RspBuf[Modbus.ByteRsp++]='\n';
// 				MB_Dptr=Modbus.RspBuf;
// 				Flag.FTX=1;
// 				Modbus.TXTimeOut=0;
// 				tx_en();
// 				U2TXREG=*MB_Dptr++;
// 					}
// 				}
// 				else{
// 					exeption_response(ILLEGAL_DATA_VALUE);	
// 				}
// 			}
// 			else{
// 				exeption_response(ILLEGAL_DATA_ADDRESS);	
// 			}
// 		}
// 		else{
// 			exeption_response(ILLEGAL_DATA_VALUE);		
// 		}
// 	}
// }
void modbus(void){
	if(Flag.FTX){
		if(++Modbus.TXTimeOut>=5){
			Modbus.TXTimeOut=0;
			Flag.FTX=0;
			rx_en();
		}
	}
	if(Flag.FRX){
		if(++Modbus.RXTimeOut>=5){
			Modbus.RXTimeOut=0;
			Flag.FRX=0;
			ASCII2HEX(&Modbus.ReqBuf[0], Modbus.ByteReq);
			switch(Modbus.Ascii2HexBuf[1]){
				// case 0x01:
				// 	read_coils[Value.Protocol]();
				// 	break;
				case 0x03:
				case 0x04:
					read_multi_registers[Value.Protocol]();
					break;
				// case 0x05:
				// 	preset_a_single_coils[Value.Protocol]();
				// 	break;
				case 0x06:
					preset_a_single_register[Value.Protocol]();
					break;
				// case 0x0F:
				// 	preset_multi_registers[Value.Protocol]();
				// 	break;
				case 0x10:
					preset_multi_registers[Value.Protocol]();
					break;
				default:
					if(Value.Protocol==RTUs){
						crc16(Modbus.Ascii2HexBuf, Modbus.ByteReq-2);
						if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1]) break;	
					}
					else{
						LRC(Modbus.Ascii2HexBuf, (Modbus.ByteReq-5)/2);
						if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-4]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-3])break;	
					}
					exeption_response(ILLEGAL_FUNCTION);
					break;
			}
			Modbus.ByteReq=0;
		}
	}
}
#endif

