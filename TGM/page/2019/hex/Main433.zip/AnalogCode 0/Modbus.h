
#ifndef MODBUS_PROTOCOL

#include "config.h"
#include "typedef.h"

//extern MB_sType Modbus;


#endif

