#ifndef CONFIG

#if 1
#define	SIZE_S
#endif
#if 0
#define	SIZE_M
#endif
#if 0
#define	SIZE_L
#endif
#if 0
#define	SIZE_XL
#endif

#ifdef SIZE_S
#define SIZE_2_3_INCH
#elif defined SIZE_M
#define SIZE_4_INCH
#elif defined SIZE_L
#define SIZE_8_INCH
#else
#define SIZE_12_INCH
#endif

#define	_T1ON	T1CONbits.TON
#define	_T2ON	T2CONbits.TON
#define	_T3ON	T3CONbits.TON
#define	_T4ON	T4CONbits.TON

#define	DS1307_R		0b11010001
#define	DS1307_W		0b11010000

#define	IrDataLogic_0	0x0050

#define	TMR1_PERIOD	0x0240
#define	TMR2_PERIOD	0xFFFF
#define	TMR3_PERIOD	0x0060
#define	TMR4_PERIOD	0x0240

#define	TIME4SEC	400
#define	TIME2SEC	200
#define	TIME1SEC	100
#define	TIME500mSEC	50
#define	TIME250mSEC	25
#define	TIME100mSEC	10
#define	TIME50mSEC	5
#define	TIME20mSEC	2
#define	TBLINK	50

#define	RX_START	0x3A
#define	RX_STOP		0x0D
#define	DOT			0x2E
#define	MINUS		0x2D
#define	PLUS		0x2B

#define	SEG_TARGET		0
#define	SEG_ACTUAL1		5
#define	SEG_DEFF		10
#define	SEG_ACTUAL3		17

#define	SEG_LIMITMAX		99999
#define	SEG_LIMITMIN		0

#define	TIMER_CHANNEL	10
#define	TIMER_CHANNEL_MAX	TIMER_CHANNEL-1

#define	EDIT_LENGTH		5
#define	SEGMENT_COLUMN	5
#define	MATRIX_COLUMN	5

#define	SEGMENT_LENGTH	15
#define	MATRIX_LENGTH	8

#define	MATRIX_LENG		8
#define	TIME_RESET_LENGTH	2
#define	PROGRAM_LENGTH	20
#define	SLAVE_ADDR		10

#define	CD4051_A	_RB6
#define	CD4051_B	_RB7
#define	ADC_CS	_RB8

#define	OUT1	_RD1
#define	OUT2	_RD3
#define	OUT3	_RD2

#define	ST_CLK	_RE0
#define	SER		_RE1
#define	SH_CLK	_RE2
#define	RD_485	_RE3

#define	CLK		_RF0
#define	DAT 	_RE4
#define	STR 	_RD0

#define 	SDAIO	_TRISF1
#define	SDA		_RF1
#define	SCL		_RE5

#define	EEPROM_OFFSET			0x7FFC00
#define EEP_PROGRAM_HOURS		0x0000
#define EEP_PROGRAM_MINUTES		0x0028
#define EEP_PROGRAM_EVENT		0x0050
#define EEP_T_RESET_HOURS		0x0002
#define EEP_T_RESET_MINUTES		0x0004

#define EEP_MUL					0x0006	//   6 : 16 bit
#define EEP_DIV					0x0008	//   8 : 16 bit
#define EEP_SV					0x0008	//   8 : 16 bit

#define EEP_SCALE_HI_HW			0x000A	//  10 : 16 bit
#define EEP_SCALE_HI_LW			0x000C	//  12 : 16 bit
#define EEP_SCALE_LO_HW			0x0010	//  16 : 16 bit
#define EEP_SCALE_LO_LW			0x0012	//  18 : 16 bit

#define EEP_DP					0x0016	//  22 : 16 bit
#define EEP_RTU					0x0018	//  24 : 16 bit
#define EEP_SLAVE_ADDRESS		0x001A	//  26 : 16 bit
#define EEP_BAUDRATE			0x001C	//  28 : 16 bit
#define EEP_PARITY				0x001E	//  30 : 16 bit
#define EEP_BITS				0x0020	//  32 : 16 bit

#define EEP_INPUTDELAY			0x0022	//  34 : 16 bit

#define EEP_TARGET				0x0024	//  36 : 32 bit
#define EEP_ACTUAL1				0x0028	//  38 : 32 bit
#define EEP_ACTUAL2				0x003C	//  40 : 32 bit
#define EEP_ACTUAL3				0x0030	//  42 : 32 bit

#define EEP_MUL1				0x0034	//  44 : 16 bit
#define EEP_MUL2				0x0036	//  46 : 16 bit
#define EEP_MUL3				0x0038	//  58 : 16 bit
#define EEP_MUL4				0x003A	//  60 : 16 bit

#define EEP_DIV1				0x0044	//  68 : 16 bit
#define EEP_DIV2				0x0046	//  70 : 16 bit
#define EEP_DIV3				0x0048	//  72 : 16 bit
#define EEP_DIV4				0x004A	//  74 : 16 bit

#define EEP_CYCLEPLAN			0x003E	//  76 : 16 bit
#define EEP_CYCLETARGET			0x0040	//  78 : 16 bit
#define EEP_INPUT_TYPE			0x0042	//  80 : 16 bit

#define EEP_SETPOINT1_H			0x0080	// 128 : 16 bit
#define EEP_SETPOINT1_L			0x0082	// 130 : 16 bit
#define EEP_SETPOINT2_H			0x0084	// 132 : 16 bit
#define EEP_SETPOINT2_L			0x0086	// 134 : 16 bit
#define EEP_SETPOINT3_H			0x0088	// 136 : 16 bit
#define EEP_SETPOINT3_L			0x008A	// 138 : 16 bit

#define EEP_SETPOINT1_M			0x008C	// 140 : 16 bit
#define EEP_SETPOINT2_M			0x008E	// 142 : 16 bit
#define EEP_SETPOINT3_M			0x0090	// 144 : 16 bit

/* EEPROM << TIME  	>> 	158 */
#define EEP_TIME_EN				0x009E	//  158
#define TIME2400				6144

/* EEPROM << TIME ON 	>> 	160 - 180 		*/
#define EEP_TIMEON_00			0x00A0 // - 0x00B4

/* EEPROM << TIME OFF 	>> 	182 - 202 		*/
#define EEP_TIMEOFF_00			0x00B6 // - 0x00CA

/* EEPROM << TIME RESET >> 	204 - 224	*/
#define EEP_TIMERESET_00		0x00CC // - 0x00E0

/* EEPROM << Summary Time >> 	230	-236*/
#define EEP_SUMMARYTIME_DAY		0x00E6	// 230
#define EEP_SUMMARYTIME_HOUR	0x00E8	// 232
#define EEP_SUMMARYTIME_MINUTE	0x00EA	// 234
#define EEP_SUMMARYTIME_SECOND	0x00EC	// 236

/* EEPROM << Down Time >> 	238	- 244 || 0x00EE - 0x00F5 */
#define EEP_DOWNTIME_DAY		0x00EE	// 238
#define EEP_DOWNTIME_HOUR		0x00F0	// 240
#define EEP_DOWNTIME_MINUTE		0x00F2	// 242
#define EEP_DOWNTIME_SECOND		0x00F4	// 244

/* EEPROM << Chart >> 	256	- 272 || 0x0100 - 0x010F */
#define EEP_CHART_ASCII			0x0100	// 256


/***************************************************************/
#define RAM_MASTER				10
#define RAM_ACTUAL				0x000E

#define RAM_TARGET_			16
#define RAM_ACTUAL1_		20
#define RAM_ACTUAL2_		24
#define RAM_ACTUAL3_		28
#define RAM_ACTUAL2_R		32
#define RAM_ACTUAL3_R		36
#define RAM_CYCLEPLAN_		40
#define RAM_CYCLETARGET_	44
										//         11  10  9   8   7   6   5   4   3   2   1   0
#define BUTTON_SET_TIME			0x0290	// LHHHHH  LH  LH  LHH LH  LHH LH  LH  LHH LH  LH  LH  LH
#define BUTTON_DSP				0x05D0	// 
#define BUTTON_POWER			0x0A90	// 
#define BUTTON_OP_MODE			0x0FD0	// 
#define BUTTON_ADD				0x0A50	// 
#define BUTTON_OSD				0x01D0	// 
#define BUTTON_SIGN				0x0B90	// 
#define BUTTON_F1				0x0150	// 
#define BUTTON_F2				0x0E90	// 
#define BUTTON_F3				0x03D0	// 
#define BUTTON_F4				0x06D0	// 
#define BUTTON_SCALE_PLUS		0x0490	// 
#define BUTTON_SCALE_MINUS		0x0C90	// 
#define BUTTON_VOL_PLUS			0x0090	// 
#define BUTTON_VOL_MINUS		0x0890	// 
#define BUTTON_CANCEL			0x02F0	// 
#define BUTTON_MENU				0x0AF0	// 
#define BUTTON_ENTER			0x03F0	// 
#define BUTTON_DP				0x0270	// 
#define BUTTON_0				0x0910	// 
#define BUTTON_1				0x0010	// 
#define BUTTON_2				0x0810	// 
#define BUTTON_3				0x0410	// 
#define BUTTON_4				0x0C10	// 
#define BUTTON_5				0x0210	// 
#define BUTTON_6				0x0A10	// 
#define BUTTON_7				0x0610	// 
#define BUTTON_8				0x0E10	// 
#define BUTTON_9				0x0110	// 

#define BIT0		0x0001
#define BIT1		0x0002
#define BIT2		0x0004
#define BIT3		0x0008
#define BIT4		0x0010
#define BIT5		0x0020
#define BIT6		0x0040
#define BIT7		0x0080
#define BIT8		0x0100
#define BIT9		0x0200
#define BIT10		0x0400
#define BIT11		0x0800
#define BIT12		0x1000
#define BIT13		0x2000
#define BIT14		0x4000
#define BIT15		0x8000


#ifndef _MACRO
#define togglebi(b,x) (b^=x)
#define sbi(b,x) (b|=x)
#define cbi(b,x) (b&=~x)
#define bis(b,x) (b&x)
#define bic(b,x) (!(b&x))
#endif

enum BAUDRATE{
//	BR2400,					// = 0
	BR4800,  				// = 1
	BR9600,      			// = 2
	BR19200,    			// = 3
	BR38400,    			// = 4
	BR57600,    			// = 5
	BR115200   				// = 6
};
enum SETPOINTMODE{
	SETPOINT_ACTUAL_, 		// = 0
	SETPOINT_TARGET_, 		// = 1
	SETPOINT_PLAN_,   		// = 2
};
enum PARITY{
	b8n1,      				// = 0
	b8e1,      				// = 1
	b8o1   					// = 2
};
enum {
	RTUs,					// = 0
	ASCII					// = 1
};
enum {
	STRING,					// = 0
	VOLUE					// = 1
};
enum {
	REQ_PV,      			// = 0
	RSP_PV,      			// = 1
	REQ_DP,      			// = 2
	RSP_DP     				// = 3
};
enum {
	_W,     				// = 0
	_R     					// = 1
};
enum {
	_BREAK,     			// = 0
	_RUN     				// = 1
};
enum {
	RX,      				// = 0
	TX     					// = 1
};
enum {
	DIS,     				// = 0
	EN    					// = 1
};
enum {
	CLR,	     			// = 0
	SET 	   				// = 1
};
enum {
	RISING,     			// = 0
	FALLING    				// = 1
};
enum {
	OUTPUT,     			// = 0
	INPUT    				// = 1
};
enum {
	_FALSE, 	    		// = 0
	_TRUE    				// = 1
};
enum {
	TRIG,     				// = 0
	DEBOUNCE,     			// = 1
	RELEASE    				// = 2
};
enum {
	ILLEGAL_FUNCTION=1,     // = 0
	ILLEGAL_DATA_ADDRESS,   // = 1
	ILLEGAL_DATA_VALUE    	// = 2
};
enum {
	PRIORITY_1=1,     		// = 0
	PRIORITY_2,     		// = 1
	PRIORITY_3,     		// = 2
	PRIORITY_4,     		// = 3
	PRIORITY_5,     		// = 4
	PRIORITY_6,     		// = 5
	PRIORITY_7    			// = 6
};
enum {
	Monday,    				// = 0
	Tuesday,    			// = 1
	Wednesday,    			// = 2
	Thursday,    			// = 3
	Friday,    				// = 4
	Saterday,    			// = 5
	Sunday   				// = 6
};
enum IPType{
		SWITCH,				// = 0
		S_NPN,				// = 1
		S_PNP				// = 2
};
enum {
		January,  			// = 0
		February,  			// = 1
		March,	  			// = 2
		April,  			// = 3
		May,   				// = 4
		June,   			// = 5
		July,   			// = 6
		August,  			// = 7
		September,  		// = 8
		October,  			// = 9
		November,   		// = 10
		December  			// = 11
};
enum {
	SECONDS_REG,  			// = 0
	MINUTES_REG,	  		// = 1
	HOURS_REG,  			// = 2
	DAY_REG,  				// = 3
	DATE_REG,  				// = 4
	MONTH_REG,  			// = 5
	YEAR_REG, 				// = 6
	CONTROL_REG,  			// = 7
	RAM_REG 				// = 8
};
enum {
	INIT_MODE, 							// =  0
	OPERATE_MODE, 						// =  1
	
	EDIT_WARNING_MODE, 					// =  2
	EDIT_MUL_MODE, 						// =  3
	EDIT_DIV_MODE, 						// =  4
	EDIT_DP_MODE,  						// =  5
	EDIT_INPUT_DELAY, 					// =  6
	
	EDIT_ADDRESS_MODE,  				// =  7
	EDIT_BAUDRATE_MODE,  				// =  8
	EDIT_PARITY_MODE,  					// =  9
	
	EDIT_DELAY_POLLS_MODE,  			// = 10
	EDIT_RESPONSE_TIMEOUT_MODE,  		// = 11
	CAL_ANALOG_MODE,  					// = 12
	IDLE_MODE,		 					// = 13
	
	EDIT_TARGET,						// = 14
	EDIT_ACTUAL1,						// = 15
	EDIT_CHARTMENU_MODE,				// = 16
	EDIT_CHARTVALUE_MODE,				// = 17
	EDIT_CYCLETIME,						// = 18
	EDIT_TIMERESET_MODE,				// = 19
	EDIT_TIMEMENU_MODE,					// = 20
	EDIT_TIMEON_MODE,					// = 21
	EDIT_TIMEOFF_MODE,					// = 22
	EDIT_TIMEEN_MODE,						// = 23
	EDIT_INPUT_TYPE,					// = 24
	
	EDIT_SETDATE,						// = 25
	EDIT_SETTIME,						// = 26
	EDIT_SUMTIME_MODE,					// = 27
	EDIT_DOWNTIME_MODE,					// = 28
	EDIT_ALS_MODE,						// = 29
};
enum TIMER_MENU{
	MENU_TIME_ON,
	MENU_TIME_OFF,
	MENU_TIME_RESET,
	MENU_TIME_EN,
	MENU_TIME_SUM,
	MENU_TIME_DOWN
};
enum COIL_ADDRESS{
	 COIL_001B=0x0000,						// = 0
	 COIL_002B,	 							// = 1
	 COIL_003B,	 							// = 2	
	 COIL_004B,	 		 					// = 3
	 COIL_005B,	 		 					// = 4
	 COIL_006B,	 		 					// = 5
	 COIL_007B,	 		 					// = 6
	 COIL_008B,	 		 					// = 7
	 COIL_009B,	 		 					// = 8
	 COIL_010B		 						// = 9
};
enum MB_FUNC{
	READ_COILS=1, 										// = 01
	READ_DISCRETE_INPUT,  								// = 02
	READ_HOLDING_REGISTERS,  							// = 03
	READ_INPUT_REGISTERS,  								// = 04
	WRITE_SINGLE_COIL,  								// = 05
	WRITE_SINGLE_REGISTER,  							// = 06
	READ_EXCEPTION_STATUS,  							// = 07
	DIAGNOSTICS,  										// = 08
	RESERVED_COMMAND1,  								// = 09
	RESERVED_COMMAND2,  								// = 0A
	GET_COMM_EVENT_COUNTER, 							// = 0B
	GET_COMM_EVENT_LOG, 								// = 0C
	RESERVED_COMMAND3,  								// = 0D
	RESERVED_COMMAND4,  								// = 0E
	WRITE_MULTIPLE_COIL,  								// = 0F
	WRITE_MULTIPLE_REGISTER,  						// = 10
};
enum Warning{
	WN_NONE,
	WN_ALARM,
	WN_TIMEON,
	WN_TIMEOFF,
	WN_TIMERESET,
};
enum ISL{
	SC_REG,
	MN_REG,
	HR_REG,
	DT_REG,
	MO_REG,
	YR_REG,
	DW_REG,
	SR_REG,
	INT_REG
};
enum REGISTER_ADDRESS{
	 DATA_SEG_1_REGS=0x0000,
	 DATA_SEG_2_REGS,	 	
	 DATA_SEG_3_REGS,	 	
	 DATA_SEG_4_REGS,	
	 DATA_SEG_5_REGS,
	 DATA_SEG_6_REGS
	
};
enum {
	MB__MODEL,  					// = 00
	MB__FUNC,  						// = 01
	MB__HWRLYEAR,  					// = 02
	MB__HWMJVER,					// = 03
	MB__HWMIVER, 					// = 04
	MB__SWRLYEAR, 					// = 05
	MB__SWMJVER,  					// = 06
	MB__SWMIVER,  					// = 07

	MB__TARGET_H,  					// = 08
	MB__TARGET_L,  					// = 09
	MB__ACTUAL_H,  					// = 10
	MB__ACTUAL_L,  					// = 11
	MB__DEFF_H,  					// = 12
	MB__DEFF_L,  					// = 13
	MB__MASTER_H,  					// = 14
	MB__MASTER_L,  					// = 15
	MB__PEREFF_H,  					// = 16
	MB__PEREFF_L,  					// = 17

	MB__INPUT_TYPE,					// = 18
	MB__DI_STATUS, 					// = 19
	MB__DO_STATUS, 					// = 20
	MB__MULTI,  					// = 21
	MB__DIVISOR,  					// = 22

	MB__STEPOINT1_H,				// = 23
	MB__STEPOINT1_L,				// = 24
	MB__STEPOINT2_H,				// = 25
	MB__STEPOINT2_L,				// = 26

	MB__DECIMALPOINT,				// = 27
	MB__CYCLETIME, 					// = 28
	MB__INPUT_DELAY,				// = 29

	MB__CHART_0,  					// = 30
	MB__CHART_1,  					// = 31
	MB__CHART_2,  					// = 32
	MB__CHART_3,  					// = 33
	MB__CHART_4,  					// = 34
	MB__CHART_5,  					// = 35
	MB__CHART_6,  					// = 36
	MB__CHART_7,  					// = 37

	MB__DAY2WEEK,  					// = 38
	MB__DATE, 	 					// = 39
	MB__MONTH,  					// = 40
	MB__YEAR,	  					// = 41
	MB__HOUR,	  					// = 42
	MB__MINUTE,  					// = 43
	MB__SECOND,  					// = 44

	MB__DOWNTIME_STATUS,			// = 45
	MB__DOWNTIME_DAY,  				// = 46
	MB__DOWNTIME_HOUR,  			// = 47
	MB__DOWNTIME_MINUTE,  			// = 48
	MB__DOWNTIME_SECOND,  			// = 49

	MB__SUMTIME_DAY,  				// = 50
	MB__SUMTIME_HOUR,  				// = 51
	MB__SUMTIME_MINUTE,  			// = 52
	MB__SUMTIME_SECOND,  			// = 53

	MB__TIME_EN,  					// = 54

	MB__TIME_ON_0, 					// = 55
	MB__TIME_ON_1, 					// = 56
	MB__TIME_ON_2, 					// = 57
	MB__TIME_ON_3, 					// = 58
	MB__TIME_ON_4, 					// = 59
	MB__TIME_ON_5, 					// = 60
	MB__TIME_ON_6, 					// = 61
	MB__TIME_ON_7, 					// = 62
	MB__TIME_ON_8, 					// = 63
	MB__TIME_ON_9, 					// = 64

	MB__TIME_OFF_0,					// = 65
	MB__TIME_OFF_1,					// = 66
	MB__TIME_OFF_2,					// = 67
	MB__TIME_OFF_3,					// = 68
	MB__TIME_OFF_4,					// = 69
	MB__TIME_OFF_5,					// = 70
	MB__TIME_OFF_6,					// = 71
	MB__TIME_OFF_7,					// = 72
	MB__TIME_OFF_8,					// = 73
	MB__TIME_OFF_9,					// = 74

	MB__TIME_RESET_0,				// = 75
	MB__TIME_RESET_1,				// = 76
	MB__TIME_RESET_2,				// = 77
	MB__TIME_RESET_3,				// = 78
	MB__TIME_RESET_4,				// = 79
	MB__TIME_RESET_5,				// = 80
	MB__TIME_RESET_6,				// = 81
	MB__TIME_RESET_7,				// = 82
	MB__TIME_RESET_8,				// = 83
	MB__TIME_RESET_9,				// = 84

	MB__BAUDRATE,  					// = 85
	MB__PARITY,  					// = 86
	MB__ADD,  						// = 87
};
enum {
	ADDw_E,
	DATAw_E,
	ADDr_E,
};
enum {
	GRADE_A_REG, 						// = 0
	GRADE_C_RJ_REG, 						// = 1
	SUMMARY_REG,  							// = 2
	PERCENT_GRADE_C_REG,  				// = 3
	MULTIPLIER_REG,  						// = 4
	DIVISOR_REG,  							// = 5
	DECIMAL_REG, 							// = 6
	COIL_1,									// = 7
	COIL_2,									// = 8
	COIL_3									// = 9
};
enum {
	IN_NUM1,							// = 0
	IN_NUM2,							// = 1
	SUM_MODE,							// = 2
};
#endif