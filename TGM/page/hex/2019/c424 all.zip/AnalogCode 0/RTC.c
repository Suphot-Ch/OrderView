#include <p30f4011.h>
#include "config.h"
#include "global.h"

#if 0

/*
void convert_read(void){
	RTC.Seconds=(RTC.Seconds/0x10)*10+(RTC.Seconds%0x10);
	RTC.Minutes=(RTC.Minutes/0x10)*10+(RTC.Minutes%0x10);
	RTC.Hours=(RTC.Hours/0x10)*10+(RTC.Hours%0x10);
	RTC.Date=(RTC.Date/0x10)*10+(RTC.Date%0x10);
	RTC.Month=(RTC.Month/0x10)*10+(RTC.Month%0x10);
	RTC.Year=(RTC.Year/0x10)*10+(RTC.Year%0x10);
}
void convert_write(void){
	RTC.Seconds=(RTC.Seconds/10)*0x10+(RTC.Seconds%10);
	RTC.Minutes=(RTC.Minutes/10)*0x10+(RTC.Minutes%10);
	RTC.Hours=(RTC.Hours/10)*0x10+(RTC.Hours%10);
	RTC.Date=(RTC.Date/10)*0x10+(RTC.Date%10);
	RTC.Month=(RTC.Month/10)*0x10+(RTC.Month%10);
	RTC.Year=(RTC.Year/10)*0x10+(RTC.Year%10);
}
*/
void convert_rtc_data(s8 rw, u8 *dptr){
	*dptr=rw ? ((*dptr/0x10)*10+(*dptr%0x10)) : ((*dptr/10)*0x10+(*dptr%10));
}
void delayxNop(void){
	Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	//Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
}
void start_bit(void){
	SDAIO=OUTPUT;
	SDA=SET;
	SCL=SET;
	delayxNop();
	delayxNop();
	SDA=CLR;
	delayxNop();
	SCL=CLR;
}
void stop_bit(void){
	SDAIO=OUTPUT;
	SCL=SET;
	delayxNop();
	SDA=CLR;
	delayxNop();
	SDA=SET;
	delayxNop();
}
void ack(void){
	SDAIO=OUTPUT;
	SDA=CLR;
	//SDAIO=INPUT;
	delayxNop();
	SCL=SET;
	delayxNop();
	SCL=CLR;
	delayxNop();
	SDA=SET;
}
void nack(void){
	SDAIO=OUTPUT;
	SCL=CLR;
	SDA=SET;
	delayxNop();
	SCL=SET;
	delayxNop();
	SCL=CLR;
	delayxNop();
}
void send_byte(u8 value){
	u8 i;
	SDAIO=OUTPUT;
	for(i=0;i<8;i++){
		SCL=CLR;
		SDA=value&0x80 ? 1 : 0;
		delayxNop();
		SCL=SET;
		delayxNop();
		value<<=1;
	}
	SCL=CLR;
	delayxNop();
	SDA=CLR;
}
u8 read_byte(void){
	u8 i, value;
	value=CLR;
	SDAIO=INPUT;
	SCL=CLR;
	for(i=0;i<8;i++){
		delayxNop();
		SCL=SET;
		value<<=1;
		value|=SDA ? 1 : 0;
		delayxNop();
		SCL=CLR;
	}
	SCL=CLR;
	delayxNop();
	return value;
}
void write_current_time(void){
	u8 i, *dptr;
	
	//if((LAST.Year!=RTC.Year)||(LAST.Month!=RTC.Month)||(LAST.Date!=RTC.Date)||(LAST.Day!=RTC.Day)||(LAST.Hours!=RTC.Hours)||(LAST.Minutes!=RTC.Minutes)||(LAST.Seconds!=RTC.Seconds)){
		//convert_write();
		convert_rtc_data(_W, &RTC.Seconds);
		convert_rtc_data(_W, &RTC.Minutes);
		convert_rtc_data(_W, &RTC.Hours);
		convert_rtc_data(_W, &RTC.Day);
		convert_rtc_data(_W, &RTC.Date);
		convert_rtc_data(_W, &RTC.Month);
		convert_rtc_data(_W, &RTC.Year);
		RTC.Seconds=CLR;
		dptr=&RTC.Seconds;	
		for(i=0;i<7;i++,dptr++){
			start_bit();		
			send_byte(DS1307_W);
			ack();
			send_byte(i);
			ack();		
			send_byte(*dptr);
			ack();
			stop_bit();
			//*dptr=0;
		}
	//}
}
void read_current_time(void){
	u8 i, *dptr;
	switch(Status.Main){
		case OPERATE:
			if(++TimeUpdateRTC>=25){
				TimeUpdateRTC=CLR;
				dptr=&RTC.Seconds;	
				for(i=0;i<7;i++,dptr++){
					start_bit();		
					send_byte(DS1307_W);
					ack();
					send_byte(i);
					ack();
					start_bit();		
					send_byte(DS1307_R);
					ack();
					*dptr=read_byte();
					nack();	
					stop_bit();
				}
				//convert_read();
				convert_rtc_data(_R, &RTC.Seconds);
				convert_rtc_data(_R, &RTC.Minutes);
				convert_rtc_data(_R, &RTC.Hours);
				convert_rtc_data(_R, &RTC.Day);
				convert_rtc_data(_R, &RTC.Date);
				convert_rtc_data(_R, &RTC.Month);
				convert_rtc_data(_R, &RTC.Year);
			}
			break;
		default:
			break;
	}
}
void write_ram_RTC(u8 addr, u8 *dptr, u8 n){
	u8 i;
	
	for(i=0;i<n;i++,dptr++){
		start_bit();		
		send_byte(DS1307_W);
		ack();
		send_byte(addr+i);
		ack();		
		send_byte(*dptr);
		ack();
		stop_bit();
		//*dptr=0;
	}
}
void read_ram_RTC(u8 addr, u8 *dptr, u8 n){
	u8 i;
	
	for(i=0;i<n;i++,dptr++){
		start_bit();		
		send_byte(DS1307_W);
		ack();
		send_byte(addr+i);
		ack();
		start_bit();		
		send_byte(DS1307_R);
		ack();
		*dptr=read_byte();
		nack();	
		stop_bit();
	}
}

#endif

