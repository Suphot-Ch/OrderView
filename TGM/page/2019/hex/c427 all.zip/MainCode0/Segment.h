#ifndef COM_ANODE	
#define	COM_ANODE	

#ifdef	SIZE_2_3_INCH
#define	SEGA	0x80
#define	SEGB	0x01
#define	SEGC	0x02
#define	SEGD	0x04
#define	SEGE	0x08
#define	SEGF	0x20
#define	SEGG	0x10
#define	SEGDP	0x40

#define	SEGA_	0x40
#define	SEGB_	0x80
#define	SEGC_	0x02
#define	SEGD_	0x08
#define	SEGE_	0x10
#define	SEGF_	0x20
#define	SEGG_	0x01
#define	SEGDP_	0x04
#endif
#ifdef	SIZE_4_INCH
#define	SEGA	0x80
#define	SEGB	0x01
#define	SEGC	0x02
#define	SEGD	0x04
#define	SEGE	0x08
#define	SEGF	0x20
#define	SEGG	0x10
#define	SEGDP	0x40
// 0x01 A | 0x80 B | 0x02 C | 0x08 D | 0x04 E | 0x20 F | 0x40 G | 0x10 DP |
#define	SEGA_	0x01
#define	SEGB_	0x80
#define	SEGC_	0x02
#define	SEGD_	0x08
#define	SEGE_	0x04
#define	SEGF_	0x20
#define	SEGG_	0x40
#define	SEGDP_	0x10
#endif
#ifdef	SIZE_8_INCH
#define	SEGA	0x80
#define	SEGB	0x01
#define	SEGC	0x02
#define	SEGD	0x04
#define	SEGE	0x08
#define	SEGF	0x20
#define	SEGG	0x10
#define	SEGDP	0x40

#define	SEGA_	0x80
#define	SEGB_	0x40
#define	SEGC_	0x02
#define	SEGD_	0x08
#define	SEGE_	0x04
#define	SEGF_	0x20
#define	SEGG_	0x01
#define	SEGDP_	0x10
#endif
#ifdef	SIZE_12_INCH
#define	SEGA	0x80
#define	SEGB	0x40
#define	SEGC	0x20
#define	SEGD	0x10
#define	SEGE	0x08
#define	SEGF	0x04
#define	SEGG	0x02
#define	SEGDP	0x01

#define	SEGA_	0x80
#define	SEGB_	0x40
#define	SEGC_	0x02
#define	SEGD_	0x08
#define	SEGE_	0x04
#define	SEGF_	0x20
#define	SEGG_	0x01
#define	SEGDP_	0x10
#endif

#define FONT_BLANK				0x00
#define TEST_SEGMENT			0xFF

#define FONT_A			SEGA|SEGB|SEGC|SEGE|SEGF|SEGG
#define FONT_B			SEGC|SEGD|SEGE|SEGF|SEGG
#define FONT_C			SEGA|SEGD|SEGE|SEGF
#define FONT_D			SEGB|SEGC|SEGD|SEGE|SEGG
#define FONT_E			SEGA|SEGD|SEGE|SEGF|SEGG
#define FONT_F			SEGA|SEGE|SEGF|SEGG
#define FONT_G			SEGA|SEGC|SEGD|SEGE|SEGF
#define FONT_H			SEGB|SEGC|SEGE|SEGF|SEGG
#define FONT_h			SEGC|SEGE|SEGF|SEGG
#define FONT_I			SEGE|SEGF
#define FONT_J			SEGB|SEGC|SEGD|SEGE
#define FONT_K			SEGB|SEGD|SEGE|SEGF|SEGG
#define FONT_L			SEGD|SEGE|SEGF
#define FONT_M			SEGA|SEGC|SEGE
#define FONT_N			SEGC|SEGE|SEGG
#define FONT_O			SEGC|SEGD|SEGE|SEGG
#define FONT_P			SEGA|SEGB|SEGE|SEGF|SEGG
#define FONT_Q			SEGA|SEGB|SEGC|SEGF|SEGG
#define FONT_R			SEGE|SEGG
#define FONT_S			SEGA|SEGC|SEGD|SEGF|SEGG
#define FONT_T			SEGD|SEGE|SEGF|SEGG
#define FONT_U			SEGB|SEGC|SEGD|SEGE|SEGF
#define FONT_V			SEGC|SEGD|SEGE
#define FONT_W			SEGB|SEGD|SEGF|SEGG
#define FONT_X			SEGA|SEGC|SEGD|SEGE
#define FONT_Y			SEGB|SEGC|SEGD|SEGF|SEGG
#define FONT_0			SEGA|SEGB|SEGC|SEGD|SEGE|SEGF
#define FONT_1			SEGB|SEGC
#define FONT_2			SEGA|SEGB|SEGD|SEGE|SEGG
#define FONT_3			SEGA|SEGB|SEGC|SEGD|SEGG
#define FONT_4			SEGB|SEGC|SEGF|SEGG
#define FONT_5			SEGA|SEGC|SEGD|SEGF|SEGG
#define FONT_6			SEGA|SEGC|SEGD|SEGE|SEGF|SEGG
#define FONT_7			SEGA|SEGB|SEGC
#define FONT_8			SEGA|SEGB|SEGC|SEGD|SEGE|SEGF|SEGG
#define FONT_9			SEGA|SEGB|SEGC|SEGD|SEGF|SEGG	
#define FONT_SLASH		SEGB|SEGE|SEGG
#define FONT_UNIT		SEGA|SEGB|SEGF|SEGG
#define FONT_PLUS		SEGA|SEGB|SEGC|SEGD|SEGE|SEGF|SEGG
#define FONT_MINUS		SEGG
#define FONT_MINUS1	SEGA|SEGB|SEGC|SEGD|SEGE|SEGF|SEGG
#define FONT_DP			SEGDP
#define FONT_OVER		SEGA
#define FONT_UNDER		SEGD
#define FONT_MY			SEGA|SEGD
#define FONT_PLS		SEGE|SEGF|SEGG
#define FONT_less		SEGD|SEGE|SEGF
#define FONT_Overr		SEGD|SEGC|SEGF

#define FONT_A_			SEGA_|SEGB_|SEGC_|SEGE_|SEGF_|SEGG_
#define FONT_B_			SEGC_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_C_			SEGA_|SEGD_|SEGE_|SEGF_
#define FONT_D_			SEGB_|SEGC_|SEGD_|SEGE_|SEGG_
#define FONT_E_			SEGA_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_F_			SEGA_|SEGE_|SEGF_|SEGG_
#define FONT_G_			SEGA_|SEGB_|SEGC_|SEGD_|SEGF_|SEGG_
#define FONT_h_			SEGB_|SEGC_|SEGE_|SEGF_|SEGG_
#define FONT_I_			SEGE_|SEGF_
#define FONT_J_			SEGB_|SEGC_|SEGD_|SEGE_
#define FONT_L_			SEGD_|SEGE_|SEGF_
#define FONT_M_			SEGA_|SEGC_|SEGE_
#define FONT_N_			SEGC_|SEGE_|SEGG_
#define FONT_O_			SEGC_|SEGD_|SEGE_|SEGG_
#define FONT_P_			SEGA_|SEGB_|SEGE_|SEGF_|SEGG_
#define FONT_Q_			SEGA_|SEGB_|SEGC_|SEGF_|SEGG_
#define FONT_R_			SEGE_|SEGG_
#define FONT_S_			SEGA_|SEGC_|SEGD_|SEGF_|SEGG_
#define FONT_T_			SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_U_			SEGB_|SEGC_|SEGD_|SEGE_|SEGF_
#define FONT_V_			SEGC_|SEGD_|SEGE_
#define FONT_W_			SEGB_|SEGD_|SEGF_
#define FONT_Y_			SEGB_|SEGC_|SEGD_|SEGF_|SEGG_
#define FONT_0_			SEGA_|SEGB_|SEGC_|SEGD_|SEGE_|SEGF_
#define FONT_1_			SEGB_|SEGC_
#define FONT_2_			SEGA_|SEGB_|SEGD_|SEGE_|SEGG_
#define FONT_3_			SEGA_|SEGB_|SEGC_|SEGD_|SEGG_
#define FONT_4_			SEGB_|SEGC_|SEGF_|SEGG_
#define FONT_5_			SEGA_|SEGC_|SEGD_|SEGF_|SEGG_
#define FONT_6_			SEGA_|SEGC_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_7_			SEGA_|SEGB_|SEGC_
#define FONT_8_			SEGA_|SEGB_|SEGC_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_9_			SEGA_|SEGB_|SEGC_|SEGD_|SEGF_|SEGG_	
#define FONT_SLASH_		SEGB_|SEGE_|SEGG_
#define FONT_UNIT_		SEGA_|SEGB_|SEGF_|SEGG_
#define FONT_PLUS_		SEGA_|SEGB_|SEGC_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_MINUS_	SEGG_
#define FONT_MINUS1_	SEGA_|SEGB_|SEGC_|SEGD_|SEGE_|SEGF_|SEGG_
#define FONT_DP_		SEGDP_
#define FONT_OVER_		SEGA_
#define FONT_UNDER_	SEGD_

#endif

