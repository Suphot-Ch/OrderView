#ifndef GLOBAL_H
#include "typedef.h"

extern void TPIC6B595_init(void);

extern void shift_data(u8 *dptr);
extern void TPIC6B595_LATCH(u8 *dptr);
extern void TPIC6B595_scan(void);

extern void shift_data2(u8 *dptr);
extern void TPIC6B595_LATCH2(u8 *dptr);
extern void HC595_SCAN(void);

extern void ir_decode(void);

/*      I2C Function        */
// extern void start_bit(void);
// extern void stop_bit(void);
// extern void ack(void);
// extern void nack(void);
// extern char mack(void);
// extern void m_ack(void);
// extern void send_byte(u8 value);
// extern u8 read_byte(void);

/*      Input Channel       */
extern void trig_0(void);
extern void trig_1(void);
extern void trig_2(void);
extern void trig_3(void);
extern void trig_4(void);
extern void trig_5(void);
extern void trig_6(void);
extern void trig_7(void);

/*      Display Edit        */
extern void (*update_segment_page[])(void);
extern void operate_mode(void);
extern void edit_Warning_Mode(u8 warn);
extern void edit_slave_address_mode(void);
extern void edit_baudrate_mode(void);
extern void edit_parity_mode(void);
extern void edit_delay_polls_mode(void);
extern void edit_response_timeout_mode(void);

extern void edit_Ide_mode(void);

extern void edit_Input_mode(void);
extern void edit_InputType_mode(void);

extern void edit_Mul_mode(void);
extern void edit_Div_mode(void);
extern void edit_Decimal_mode(void);

extern void edit_Target(void);
extern void edit_Actual1(void);
extern void edit_MasterPlan(void);
extern void edit_CycleTimeMasterPlan(void);
extern void edit_CycleTimeTarget(void);

extern void edit_SummaryTime_mode(void);
extern void edit_DownTime_mode(void);

extern void edit_SetPoint1(void);
extern void edit_SetPoint2(void);

extern void edit_SetTime(void);
extern void edit_SetDate(void);
extern void edit_GetTime(void);
extern void edit_GetDate(void);

extern void edit_Chart_MENU_mode(u8 channel);
extern void edit_Chart_Value_mode(u8 channel);

extern void edit_Time_MENU_mode(u8 channel);
extern void edit_Time_ON_mode(u8 channel);
extern void edit_Time_OFF_mode(u8 channel);
extern void edit_Time_RESET_mode(u8 channel);

extern void cal_analog_mode(void);
extern void check_cal_analog(void);

extern void shift_edit_buffer(void);
extern void shift_edit_buffer_4digit(void);

extern void load_edit_buffer(s32 val);
extern void load_edit_buffer_4digit(s16 val);

extern void reload_Time_mode(u16 *val);
extern s32 reload_edit_buffer(void);
extern s16 reload_edit_buffer_4digit(void);

/*      Alarm / Timer   */
extern void AlarmOutput(void);
extern void TimeOnOffReset(void);
/*      Modbus RTU      */
extern void modbus(void);
extern void config_uart2(void);
extern void tx_en(void);
extern void rx_en(void);

/*      EEPROM  Function    */
extern void write_ram_RTC(u8 addr, u8 *dptr, u8 n);
extern void read_ram_RTC(u8 addr, u8 *dptr, u8 n);
extern void eeprom_erase_word(unsigned long addr);
extern void write_eeprom(unsigned long addr, u16 value);
extern u16 read_eeprom(unsigned long addr);
extern void write_eeprom_timer(unsigned long addr, u8 channel, u16 *val);
extern void read_eeprom_timer(unsigned long addr, u8 channel, u16 *val);
extern void write_eeprom_32(unsigned long addr, s32 *val);
extern void read_eeprom_32(unsigned long addr, s32 *val);

/*      Save Function       */
extern void save(void);
extern void clk(void);
extern void TimerCounter(void);
/*      Paramerer Command   */
extern u8 TimeUpdateRTC;
extern u16 TimeBlink;
extern u16 TimeSwitch;
extern u16 MatrixDigit;
extern u16 X_Time_ON_OFF;
extern u16 X_Time_RESET;
extern Word16_uType BreakOn, BreakOff, ResetTime;

extern u8 StatusAlarm[3];
extern s8 MatrixData[MATRIX_LENGTH];
extern u8 Data_DIGR[8];
extern u8 Data_DIGG[8];
extern u8 SegmentDigit;
extern u8 SegmentData[SEGMENT_LENGTH];
extern u8 EditBuffer[EDIT_LENGTH];
extern u8 EditTimeBuffer[6];
extern u8 EditcharBuffer[8];
extern u8 EditNum;
extern u8 EditSet;
extern u16 Dp;
extern u8 ProgramIndex;
extern u8 TimeResetIndex;
extern u16 WorkingProgram;
extern u8 CurrentProgram;
extern s16 DataLastMB;
extern s8 DataLastChart[MATRIX_LENGTH];
//extern u16 Time_OFF[];
//extern u16 Time_ON[];
extern u8 *MB_Dptr;

extern Status_sType Status;
extern IR_sType IrData;
extern RTC_sType RTC;
extern Value_sType Value;
extern MB_sType Modbus;
extern Trig_sType Trig0;
extern Trig_sType Trig1;
extern Trig_sType Trig2;
extern Trig_sType Trig3;
extern Trig_sType Trig4;
extern Trig_sType Trig5;
extern Trig_sType Trig6;
extern Trig_sType Trig7;
extern Program_sType TimeReset[2];
extern Program_sType TimeResetBuff[2];
extern Program_sType Program[20];
extern Program_sType ProgramBuff[20];
extern Flag_uType Flag;
extern ADC_sType ADC;
#endif

