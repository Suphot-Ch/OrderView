
#ifndef HC595

#include "config.h"
#include "typedef.h"

#endif

