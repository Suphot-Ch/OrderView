#ifndef GLOBAL_H
#include "typedef.h"

extern void TPIC6B595_LATCH(u8 *dptr);
extern void TPIC6B595_scan(void);
extern void TPIC6B595_init(void);
extern void read_data(void);
extern void ir_decode(void);
extern void read_current_time(void);
extern void write_current_time(unsigned char *dptr);
extern void rtc_init(void);

extern void trig_0(void);
extern void trig_1(void);
extern void trig_2(void);
extern void trig_3(void);
extern void trig_4(void);
extern void trig_5(void);
extern void trig_6(void);
extern void trig_7(void);
extern void (*update_segment_page[])(void);

extern void seg_cal(void);
extern void modbus(void);
extern void tx_en(void);
extern void rx_en(void);
extern void show_current_time(void);
extern void read_program(void);
extern void program_sort(void);
extern void reset_target_actual(void);

extern void write_ram(u8 addr, u8 *dptr, u8 n);
extern void read_ram(u8 addr, u8 *dptr, u8 n);

extern void eeprom_erase_word(unsigned long addr);
extern void write_eeprom(unsigned long addr, u16 value);
extern u16 read_eeprom(unsigned long addr);

extern void save(void);
extern void load_edit_buffer(s32 val);
extern s32 reload_edit_buffer(void);
extern void shift_edit_buffer(void);

extern void operate_mode(void);
extern void edit_TimeVal_mode(void);
extern void edit_TimeSetVal_mode(void);
extern void edit_TimeMode_mode(void);
extern void edit_TimeReset_mode(void);

extern void edit_SetTime(void);
extern void edit_SetDate(void);
extern void edit_GetTime(void);
extern void edit_GetDate(void);

extern void write_time_rtc(unsigned char add, unsigned char dptr);
extern void config_uart2(void);

extern void Alarm_4_Function(s32 val, s32 mode, s32 high, s32 low, s32 conn, u8 *Pin);
extern u8 AlarmStatus[3];
extern u8 TimeUpdateRTC;
extern u16 TimeBlink;
extern u16 TimeSwitch;
extern u16 MatrixDigit;
extern u16 X_Time_ON_OFF;
extern u16 X_Time_RESET;
extern U16_uType BreakOn, BreakOff, ResetTime;
extern s8 MatrixData[MATRIX_LENGTH];
extern u8 Data_DIGR[8];
extern u8 Data_DIGG[8];
extern u8 Data_DIGr[MATRIX_LENGTH][8];
extern u8 Data_DIGg[MATRIX_LENGTH][8];
extern u8 SegmentDigit;
extern u8 SegmentData[SEGMENT_LENGTH];
extern u8 EditBuffer[EDIT_LENGTH];
extern u8 EditTimeBuffer[6];
extern u16 Dp;
extern u8 EditNum;
extern u8 ProgramIndex;
extern u8 TimeResetIndex;
extern u16 WorkingProgram;
extern u8 CurrentProgram;
extern s16 DataLastMB;
//extern u16 Break_ON[];
//extern u16 Break_OFF[];
extern u8 *MB_Dptr;
extern u32 x11,x33,x44;

extern Status_sType Status;
extern IR_sType IrData;
extern RTC_sType RTC;
extern Value_sType Value;
extern Mode_sType Mode;
extern MB_sType Modbus;
extern Trig_sType Trig0;
extern Trig_sType Trig1;
extern Trig_sType Trig2;
extern Trig_sType Trig3;
extern Trig_sType Trig4;
extern Trig_sType Trig5;
extern Trig_sType Trig6;
extern Trig_sType Trig7;
extern Trig_sType Encoder0;
extern Program_sType TimeReset[2];
extern Program_sType TimeResetBuff[2];
extern Program_sType Program[20];
extern Program_sType ProgramBuff[20];
extern Flag_uType Flag;
extern ADC_sType ADC;


#endif

