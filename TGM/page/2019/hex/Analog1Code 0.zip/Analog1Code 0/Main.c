#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"

_FOSC(CSW_FSCM_OFF & XT_PLL8);
_FWDT(WDT_OFF);
_FBORPOR(PBOR_ON & BORV_27 & PWRT_OFF & MCLR_DIS);

/*
Fcy=Fosc/4=(Xtal*PLL)/(POST*4)
Fcy=(7.3728MHz*8)/(4)
Fcy=14.7456MHz
Tcy=6.7816840277777777777777777777778e-8
*/

void io_init(void){
	ADPCFG=0xFFFF; // ADC Port
	TRISB=0xF00F;
	TRISC=0xFFFF;
	TRISD=0xFFF0;
	TRISE=0xFF00;
	TRISF=0xFFD2;

#ifdef ADCEN
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();

	/// CH0 ///
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	ADC_CS=0;
	delayxNop();
	delayxNop();
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
#endif	
}
void int0_init(void){
	_INT0EP=FALLING;
	_INT0IE=EN;
	_INT0IP=PRIORITY_7;
}
void timer1_init(void){
	TMR1=CLR;
	PR1=TMR1_PERIOD;
	_T1IP=PRIORITY_3;
	T1CON=0x0030;
	_T1IE=EN;
	_T1ON=EN;
}
void timer2_init(void){
	TMR2=CLR;
	PR2=TMR2_PERIOD;
	T2CON=0x0030;
	_T2IP=PRIORITY_2;
	_T2IE=EN;
	//_T2ON=SET;
}
void timer3_init(void){
	TMR3=CLR;
	PR3=TMR3_PERIOD;
	T3CON=0x0030;
	_T3IP=PRIORITY_1;
	_T3IE=EN;
	_T3ON=EN;
}
void timer4_init(void){
	TMR4=CLR;
	PR4=TMR4_PERIOD;
	T4CON=0x0030;
	_T4IP=PRIORITY_5;
	_T4IE=EN;
	_T4ON=EN;
}
void config_uart2(void){
	switch(Value.Baudrate){
		case BR1200:
			U2BRG=767;
			break;
		case BR2400:
			U2BRG=383;
			break;
		case BR4800:
			U2BRG=191;
			break;
		case BR19200:
			U2BRG=47;
			break;
		case BR38400:
			U2BRG=23;
			break;
		case BR57600:
			U2BRG=15;
			break;
		case BR115200:
			U2BRG=7;
			break;
		default:
			U2BRG=95;
			break;
	}
	switch(Value.Parity){
		case b8o1:
			cbi(U2MODE, BIT1);
			sbi(U2MODE, BIT2);
			break;
		case b8e1:
			sbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
		default:
			cbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
	}
}
void uart2_init(void){
	U2MODE=0x8000;
	U2STA=0x8400;
	config_uart2();
	_U2RXIP=PRIORITY_6;
	_U2TXIP=PRIORITY_4;
	_U2RXIE=EN;
	_U2TXIE=EN;
	rx_en();
}
void Start_Program(void){
	if(read_eeprom(EEP_START_PROGRAM)!=1){
		Value.SystemZeroScale[0].LWord = 0x2810;
		write_eeprom(EEP_AN_ZERO_HW0,Value.SystemZeroScale[0].WordHi);
		write_eeprom(EEP_AN_ZERO_LW0,Value.SystemZeroScale[0].WordLo);
		Value.SystemZeroScale[1].LWord = 0x2810;
		write_eeprom(EEP_AN_ZERO_HW1,Value.SystemZeroScale[1].WordHi);
		write_eeprom(EEP_AN_ZERO_LW1,Value.SystemZeroScale[1].WordLo);
		Value.SystemZeroScale[2].LWord = 0x2810;
		write_eeprom(EEP_AN_ZERO_HW2,Value.SystemZeroScale[2].WordHi);
		write_eeprom(EEP_AN_ZERO_LW2,Value.SystemZeroScale[2].WordLo);

		Value.SystemFullScale[0].LWord = 0xC8D0;
		write_eeprom(EEP_AN_FULL_HW0,Value.SystemFullScale[0].WordHi);
		write_eeprom(EEP_AN_FULL_LW0,Value.SystemFullScale[0].WordLo);
		Value.SystemFullScale[1].LWord = 0xC8D0;
		write_eeprom(EEP_AN_FULL_HW1,Value.SystemFullScale[1].WordHi);
		write_eeprom(EEP_AN_FULL_LW1,Value.SystemFullScale[1].WordLo);
		Value.SystemFullScale[2].LWord = 0xC8D0;
		write_eeprom(EEP_AN_FULL_HW2,Value.SystemFullScale[2].WordHi);
		write_eeprom(EEP_AN_FULL_LW2,Value.SystemFullScale[2].WordLo);
	
		Value.ScaleHiLimit[0].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW0, Value.ScaleHiLimit[0].WordHi);
		write_eeprom(EEP_SCALE_HI_LW0, Value.ScaleHiLimit[0].WordLo);
		Value.ScaleHiLimit[1].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW1, Value.ScaleHiLimit[1].WordHi);
		write_eeprom(EEP_SCALE_HI_LW1, Value.ScaleHiLimit[1].WordLo);
		Value.ScaleHiLimit[2].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW2, Value.ScaleHiLimit[2].WordHi);
		write_eeprom(EEP_SCALE_HI_LW2, Value.ScaleHiLimit[2].WordLo);
		
		Value.ScaleLoLimit[0].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW0, Value.ScaleLoLimit[0].WordHi);
		write_eeprom(EEP_SCALE_LO_LW0, Value.ScaleLoLimit[0].WordLo);
		Value.ScaleLoLimit[1].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW1, Value.ScaleLoLimit[1].WordHi);
		write_eeprom(EEP_SCALE_LO_LW1, Value.ScaleLoLimit[1].WordLo);
		Value.ScaleLoLimit[2].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW2, Value.ScaleLoLimit[2].WordHi);
		write_eeprom(EEP_SCALE_LO_LW2, Value.ScaleLoLimit[2].WordLo);
		
		Value.PVS[0].LWord=0; 
		write_eeprom(EEP_PUS1, Value.PVS[0].WordHi);
		write_eeprom(EEP_PUS11, Value.PVS[0].WordLo);
		Value.PVS[1].LWord=0; 
		write_eeprom(EEP_PUS2, Value.PVS[1].WordHi);
		write_eeprom(EEP_PUS22, Value.PVS[1].WordLo);
		Value.PVS[2].LWord=0; 
		write_eeprom(EEP_PUS3, Value.PVS[2].WordHi);
		write_eeprom(EEP_PUS33, Value.PVS[2].WordLo);
		
		Value.DecimalPoint[0]=1;
		write_eeprom(EEP_DP1, Value.DecimalPoint[0]);
		Value.DecimalPoint[1]=1;
		write_eeprom(EEP_DP2, Value.DecimalPoint[1]);
		Value.DecimalPoint[2]=1;
		write_eeprom(EEP_DP3, Value.DecimalPoint[2]);
		
		Value.SlaveAddress=1;
		write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
		Value.Baudrate=BR9600;
		write_eeprom(EEP_BAUDRATE, Value.Baudrate);
		Value.Parity=b8n1;
		write_eeprom(EEP_PARITY, Value.Parity);
		Value.DelayBetweenPolls=50;
		write_eeprom(EEP_DELAY_POLLS, Value.DelayBetweenPolls);
		Value.ResponseTimeOut=50;
		write_eeprom(EEP_RESP_TIME_OUT, Value.ResponseTimeOut);
#if 0
		Value.ALH[AL1_PV0].LWord=1600; 
		write_eeprom(EEP_ALH2, Value.ALH[AL1_PV0].WordHi);
		write_eeprom(EEP_ALH22, Value.ALH[AL1_PV0].WordLo);
		Value.ALH[AL0_PV0].LWord=1400; 
		write_eeprom(EEP_ALH1, Value.ALH[AL0_PV0].WordHi);
		write_eeprom(EEP_ALH11, Value.ALH[AL0_PV0].WordLo);
		
		Value.ALL[AL0_PV0].LWord=1000; 
		write_eeprom(EEP_ALL1, Value.ALL[AL0_PV0].WordHi);
		write_eeprom(EEP_ALL11, Value.ALL[AL0_PV0].WordLo);
		Value.ALL[AL1_PV0].LWord=800; 
		write_eeprom(EEP_ALL2, Value.ALL[AL1_PV0].WordHi);
		write_eeprom(EEP_ALL22, Value.ALL[AL1_PV0].WordLo);
		
		Value.ALH[AL1_PV1].LWord=1600; 
		write_eeprom(EEP_ALH4, Value.ALH[AL1_PV1].WordHi);
		write_eeprom(EEP_ALH44, Value.ALH[AL1_PV1].WordLo);
		Value.ALH[AL0_PV1].LWord=1400; 
		write_eeprom(EEP_ALH3, Value.ALH[AL0_PV1].WordHi);
		write_eeprom(EEP_ALH33, Value.ALH[AL0_PV1].WordLo);
		
		Value.ALL[AL0_PV1].LWord=1000; 
		write_eeprom(EEP_ALL3, Value.ALL[AL0_PV1].WordHi);
		write_eeprom(EEP_ALL33, Value.ALL[AL0_PV1].WordLo);
		Value.ALL[AL1_PV1].LWord=800; 
		write_eeprom(EEP_ALL4, Value.ALL[AL1_PV1].WordHi);
		write_eeprom(EEP_ALL44, Value.ALL[AL1_PV1].WordLo);
		
		Value.Mode[0]=1;
		write_eeprom(EEP_MODE1, Value.Mode[0]);
		Value.Mode[1]=1;
		write_eeprom(EEP_MODE2, Value.Mode[1]);
		Value.Mode[2]=1;
		write_eeprom(EEP_MODE3, Value.Mode[2]);
#endif
		write_eeprom(EEP_START_PROGRAM,1);
		}

}
void ram_init(void){
	u8 i, ctrl,ks;
	u16 val[12];

	Start_Program();
	
	Value.SystemZeroScale[0].WordHi=read_eeprom(EEP_AN_ZERO_HW0);
	Value.SystemZeroScale[0].WordLo=read_eeprom(EEP_AN_ZERO_LW0);
	Value.SystemZeroScale[1].WordHi=read_eeprom(EEP_AN_ZERO_HW1);
	Value.SystemZeroScale[1].WordLo=read_eeprom(EEP_AN_ZERO_LW1);
	Value.SystemZeroScale[2].WordHi=read_eeprom(EEP_AN_ZERO_HW2);
	Value.SystemZeroScale[2].WordLo=read_eeprom(EEP_AN_ZERO_LW2);
	
	Value.SystemFullScale[0].WordHi=read_eeprom(EEP_AN_FULL_HW0);
	Value.SystemFullScale[0].WordLo=read_eeprom(EEP_AN_FULL_LW0);
	Value.SystemFullScale[1].WordHi=read_eeprom(EEP_AN_FULL_HW1);
	Value.SystemFullScale[1].WordLo=read_eeprom(EEP_AN_FULL_LW1);
	Value.SystemFullScale[2].WordHi=read_eeprom(EEP_AN_FULL_HW2);
	Value.SystemFullScale[2].WordLo=read_eeprom(EEP_AN_FULL_LW2);
	
	Value.ScaleHiLimit[0].WordHi=read_eeprom(EEP_SCALE_HI_HW0);
	Value.ScaleHiLimit[0].WordLo=read_eeprom(EEP_SCALE_HI_LW0);
	Value.ScaleHiLimit[1].WordHi=read_eeprom(EEP_SCALE_HI_HW1);
	Value.ScaleHiLimit[1].WordLo=read_eeprom(EEP_SCALE_HI_LW1);
	Value.ScaleHiLimit[2].WordHi=read_eeprom(EEP_SCALE_HI_HW2);
	Value.ScaleHiLimit[2].WordLo=read_eeprom(EEP_SCALE_HI_LW2);

	if(Value.ScaleHiLimit[0].LWord>999||Value.ScaleHiLimit[0].LWord<-199){
		Value.ScaleHiLimit[0].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW0, Value.ScaleHiLimit[0].WordHi);
		write_eeprom(EEP_SCALE_HI_LW0, Value.ScaleHiLimit[0].WordLo);
		}
	if(Value.ScaleHiLimit[1].LWord>999||Value.ScaleHiLimit[1].LWord<-199){
		Value.ScaleHiLimit[1].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW1, Value.ScaleHiLimit[1].WordHi);
		write_eeprom(EEP_SCALE_HI_LW1, Value.ScaleHiLimit[1].WordLo);
		}
	if(Value.ScaleHiLimit[2].LWord>999||Value.ScaleHiLimit[2].LWord<-199){
		Value.ScaleHiLimit[2].LWord = 200 ;
		write_eeprom(EEP_SCALE_HI_HW2, Value.ScaleHiLimit[2].WordHi);
		write_eeprom(EEP_SCALE_HI_LW2, Value.ScaleHiLimit[2].WordLo);
		}

	Value.ScaleLoLimit[0].WordHi=read_eeprom(EEP_SCALE_LO_HW0);
	Value.ScaleLoLimit[0].WordLo=read_eeprom(EEP_SCALE_LO_LW0);
	Value.ScaleLoLimit[1].WordHi=read_eeprom(EEP_SCALE_LO_HW1);
	Value.ScaleLoLimit[1].WordLo=read_eeprom(EEP_SCALE_LO_LW1);
	Value.ScaleLoLimit[2].WordHi=read_eeprom(EEP_SCALE_LO_HW2);
	Value.ScaleLoLimit[2].WordLo=read_eeprom(EEP_SCALE_LO_LW2);

	if(Value.ScaleLoLimit[0].LWord>999||Value.ScaleLoLimit[0].LWord<-199){
		Value.ScaleLoLimit[0].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW0, Value.ScaleLoLimit[0].WordHi);
		write_eeprom(EEP_SCALE_LO_LW0, Value.ScaleLoLimit[0].WordLo);
		}
	if(Value.ScaleLoLimit[1].LWord>999||Value.ScaleLoLimit[1].LWord<-199){
		Value.ScaleLoLimit[1].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW1, Value.ScaleLoLimit[1].WordHi);
		write_eeprom(EEP_SCALE_LO_LW1, Value.ScaleLoLimit[1].WordLo);
		}
	if(Value.ScaleLoLimit[2].LWord>999||Value.ScaleLoLimit[2].LWord<-199){
		Value.ScaleLoLimit[2].LWord = 40 ;
		write_eeprom(EEP_SCALE_LO_HW2, Value.ScaleLoLimit[2].WordHi);
		write_eeprom(EEP_SCALE_LO_LW2, Value.ScaleLoLimit[2].WordLo);
		}
	
	Value.PVS[0].WordHi=read_eeprom(EEP_PUS1);
	Value.PVS[0].WordLo=read_eeprom(EEP_PUS11);
	Value.PVS[1].WordHi=read_eeprom(EEP_PUS2);
	Value.PVS[1].WordLo=read_eeprom(EEP_PUS22);
	Value.PVS[2].WordHi=read_eeprom(EEP_PUS3);
	Value.PVS[2].WordLo=read_eeprom(EEP_PUS33);

	if(Value.PVS[0].LWord>999||Value.PVS[0].LWord<-199){
		Value.PVS[0].LWord=0; 
		write_eeprom(EEP_PUS1, Value.PVS[0].WordHi);
		write_eeprom(EEP_PUS11, Value.PVS[0].WordLo);
		}
	if(Value.PVS[1].LWord>999||Value.PVS[1].LWord<-199){
		Value.PVS[1].LWord=0; 
		write_eeprom(EEP_PUS2, Value.PVS[1].WordHi);
		write_eeprom(EEP_PUS22, Value.PVS[1].WordLo);
		}
	if(Value.PVS[2].LWord>999||Value.PVS[2].LWord<-199){
		Value.PVS[2].LWord=0; 
		write_eeprom(EEP_PUS3, Value.PVS[2].WordHi);
		write_eeprom(EEP_PUS33, Value.PVS[2].WordLo);
		}
#if 0
	// Value.ALH[AL0_PV0].WordHi	=read_eeprom(EEP_ALH1);
	// Value.ALH[AL0_PV0].WordLo	=read_eeprom(EEP_ALH11);
	// Value.ALH[AL1_PV0].WordHi	=read_eeprom(EEP_ALH2);
	// Value.ALH[AL1_PV0].WordLo	=read_eeprom(EEP_ALH22);
	// Value.ALL[AL0_PV0].WordHi	=read_eeprom(EEP_ALL1);
	// Value.ALL[AL0_PV0].WordLo	=read_eeprom(EEP_ALL11);
	// Value.ALL[AL1_PV0].WordHi	=read_eeprom(EEP_ALL2);
	// Value.ALL[AL1_PV0].WordLo	=read_eeprom(EEP_ALL22);
		
	// if(Value.ALH[AL0_PV0].LWord>9999||Value.ALH[AL0_PV0].LWord<-1999){// 		ALH1 ALH0 ALL0 ALL1
	// 	Value.ALH[AL0_PV0].LWord=1600; 
	// 	write_eeprom(EEP_ALH1, Value.ALH[AL0_PV0].WordHi);
	// 	write_eeprom(EEP_ALH11, Value.ALH[AL0_PV0].WordLo);
	// 	}
	// if(Value.ALH[AL1_PV0].LWord>9999||Value.ALH[AL1_PV0].LWord<-1999){
	// 	Value.ALH[AL1_PV0].LWord=1400; 
	// 	write_eeprom(EEP_ALH2, Value.ALH[AL1_PV0].WordHi);
	// 	write_eeprom(EEP_ALH22, Value.ALH[AL1_PV0].WordLo);
	// 	}
	
	// if(Value.ALL[AL0_PV0].LWord>9999||Value.ALL[AL0_PV0].LWord<-1999){
	// 	Value.ALL[AL0_PV0].LWord=1000; 
	// 	write_eeprom(EEP_ALL1, Value.ALL[AL0_PV0].WordHi);
	// 	write_eeprom(EEP_ALL11, Value.ALL[AL0_PV0].WordLo);
	// 	}
	// if(Value.ALL[AL1_PV0].LWord>9999||Value.ALL[AL1_PV0].LWord<-1999){
	// 	Value.ALL[AL1_PV0].LWord=800; 
	// 	write_eeprom(EEP_ALL2, Value.ALL[AL1_PV0].WordHi);
	// 	write_eeprom(EEP_ALL22, Value.ALL[AL1_PV0].WordLo);
	// 	}
	
	// Value.ALH[AL0_PV1].WordHi	=read_eeprom(EEP_ALH3);
	// Value.ALH[AL0_PV1].WordLo	=read_eeprom(EEP_ALH33);
	// Value.ALH[AL1_PV1].WordHi	=read_eeprom(EEP_ALH4);
	// Value.ALH[AL1_PV1].WordLo	=read_eeprom(EEP_ALH44);

	// Value.ALL[AL0_PV1].WordHi	=read_eeprom(EEP_ALL3);
	// Value.ALL[AL0_PV1].WordLo	=read_eeprom(EEP_ALL33);
	// Value.ALL[AL1_PV1].WordHi	=read_eeprom(EEP_ALL4);
	// Value.ALL[AL1_PV1].WordLo	=read_eeprom(EEP_ALL44);
	
	// if(Value.ALH[AL0_PV1].LWord>9999||Value.ALH[AL0_PV1].LWord<-1999){ //		ALH3 ALH2 ALL2 ALL3
	// 	Value.ALH[AL0_PV1].LWord=1600; 
	// 	write_eeprom(EEP_ALH3, Value.ALH[AL0_PV1].WordHi);
	// 	write_eeprom(EEP_ALH33, Value.ALH[AL0_PV1].WordLo);
	// 	}
	// if(Value.ALH[AL1_PV1].LWord>9999||Value.ALH[AL1_PV1].LWord<-1999){
	// 	Value.ALH[AL1_PV1].LWord=1400; 
	// 	write_eeprom(EEP_ALH4, Value.ALH[AL1_PV1].WordHi);
	// 	write_eeprom(EEP_ALH44, Value.ALH[AL1_PV1].WordLo);
	// 	}
	
	// if(Value.ALL[AL0_PV1].LWord>9999||Value.ALL[AL0_PV1].LWord<-1999){
	// 	Value.ALL[AL0_PV1].LWord=1000; 
	// 	write_eeprom(EEP_ALL3, Value.ALL[AL0_PV1].WordHi);
	// 	write_eeprom(EEP_ALL33, Value.ALL[AL0_PV1].WordLo);
	// 	}
	// if(Value.ALL[AL1_PV1].LWord>9999||Value.ALL[AL1_PV1].LWord<-1999){
	// 	Value.ALL[AL1_PV1].LWord=800; 
	// 	write_eeprom(EEP_ALL4, Value.ALL[AL1_PV1].WordHi);
	// 	write_eeprom(EEP_ALL44, Value.ALL[AL1_PV1].WordLo);
	// 	}
	
	// Value.ALC[0].WordHi	=read_eeprom(EEP_ALC1);
	// Value.ALC[0].WordLo	=read_eeprom(EEP_ALC11);
	// Value.ALC[1].WordHi	=read_eeprom(EEP_ALC2);
	// Value.ALC[1].WordLo	=read_eeprom(EEP_ALC22);

	// if(Value.ALC[0].LWord>999||Value.ALC[0].LWord<-199){
	// 	Value.ALC[0].LWord=0; 
	// 	write_eeprom(EEP_ALC1, Value.ALC[0].WordHi);
	// 	write_eeprom(EEP_ALC11, Value.ALC[0].WordLo);
	// 	}
	// if(Value.ALC[1].LWord>999||Value.ALC[1].LWord<-199){
	// 	Value.ALC[1].LWord=0; 
	// 	write_eeprom(EEP_ALC2, Value.ALC[1].WordHi);
	// 	write_eeprom(EEP_ALC22, Value.ALC[1].WordLo);
	// 	}

	// Value.Mode[0]	=read_eeprom(EEP_MODE1);
	// Value.Mode[1]	=read_eeprom(EEP_MODE2);
	// Value.Mode[2]	=read_eeprom(EEP_MODE3);

	// if(Value.Mode[0]>=5||Value.Mode[0]<0) write_eeprom(EEP_MODE1, Value.Mode[0]=0);
	// if(Value.Mode[1]>=5||Value.Mode[1]<0) write_eeprom(EEP_MODE2, Value.Mode[1]=0);
	// if(Value.Mode[2]>=5||Value.Mode[2]<0) write_eeprom(EEP_MODE3, Value.Mode[2]=0);
#endif

	Value.DecimalPoint[0]=read_eeprom(EEP_DP1);
	Value.DecimalPoint[1]=read_eeprom(EEP_DP2);
	Value.DecimalPoint[2]=read_eeprom(EEP_DP3);

	if(Value.DecimalPoint[0]>4||Value.DecimalPoint[0]<0){Value.DecimalPoint[0]=0; write_eeprom(EEP_DP1, Value.DecimalPoint[0]);}
	if(Value.DecimalPoint[1]>4||Value.DecimalPoint[1]<0){Value.DecimalPoint[1]=0; write_eeprom(EEP_DP2, Value.DecimalPoint[1]);}
	if(Value.DecimalPoint[2]>4||Value.DecimalPoint[2]<0){Value.DecimalPoint[2]=0; write_eeprom(EEP_DP3, Value.DecimalPoint[2]);}
	
	Value.SlaveAddress=read_eeprom(EEP_SLAVE_ADDRESS);
	Value.Baudrate=read_eeprom(EEP_BAUDRATE);
	Value.Parity=read_eeprom(EEP_PARITY);
	Value.DelayBetweenPolls=read_eeprom(EEP_DELAY_POLLS);
	Value.ResponseTimeOut=read_eeprom(EEP_RESP_TIME_OUT);

	if(Value.SlaveAddress>255||Value.SlaveAddress<0){
		Value.SlaveAddress=1;
		write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
	}
	if(Value.Baudrate>BR57600||Value.Baudrate<BR4800){
		Value.Baudrate=BR9600;
		write_eeprom(EEP_BAUDRATE, Value.Baudrate);
	}
	if(Value.Parity>b8e1||Value.Parity<b8n1){
		Value.Parity=b8n1;
		write_eeprom(EEP_PARITY, Value.Parity);
	}
	if(Value.DelayBetweenPolls>1000||Value.DelayBetweenPolls<5){
		Value.DelayBetweenPolls=50;
		write_eeprom(EEP_DELAY_POLLS, Value.DelayBetweenPolls);
	}
	if(Value.ResponseTimeOut>1000||Value.ResponseTimeOut<5){
		Value.ResponseTimeOut=50;
		write_eeprom(EEP_RESP_TIME_OUT, Value.ResponseTimeOut);
	}
	
		
	ADC.channel = 0;
	Value.ResponseTimeOut = 20;
	Value.DelayBetweenPolls = 20;
	Value.Channel = 0;
	
	Modbus.Poll = 0;
	Modbus.Response = 0;
	Modbus.Status = RSP_PV;

	Value.Order = 62073;
	Value.Code	= 435;

	Flag.Word = CLR;
	Status.Main = INIT;
}
s16 main(void){
	u16 i;
	
	io_init();
	ram_init();
	rtc_init();
	timer1_init();
	timer2_init();
	timer3_init();
	timer4_init();
	uart2_init();
	int0_init();
	TPIC6B595_init();

	while(1){
	};
	return 0;
}

