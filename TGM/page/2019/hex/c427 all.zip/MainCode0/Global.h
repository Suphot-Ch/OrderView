#ifndef GLOBAL_H
#include "typedef.h"

extern void TPIC6B595_LATCH(u8 *dptr);
extern void TPIC6B595_scan(void);
extern void TPIC6B595_init(void);
extern void display_1(void);
extern void display_2(void);
extern void read_data(void);
extern void sum(u8 rw, u8 *dptr);
extern u8 get_addr(u8 addr0, u8 addr1);
extern u8 get_dp(void);
extern u8 get_sign(void);
extern s8 incorrect_data(u8 *dptr);
extern void ir_decode(void);
extern void read_current_time(void);
extern void write_current_time(unsigned char *dptr);
extern void rtc_init(void);

extern void trig_0(void);
extern void trig_1(void);
extern void trig_2(void);
extern void trig_3(void);
extern void trig_4(void);
extern void trig_5(void);
extern void trig_6(void);
extern void trig_7(void);
extern void (*update_segment_page[])(void);

extern s32 exturn_num(void);
extern void eeprom_mode(void);
extern void Clear_buffer(void);
extern void seg_cal(void);
extern void modbus(void);
extern void tx_en(void);
extern void rx_en(void);
extern void edit_event(void);
extern void get_hour(u8 *dptr);
extern void get_minutes(u8 *dptr);
extern void get_event(u8 *dptr);
extern void get_num(s16 *dptr);
extern void set_run(void);
extern void set_break(void);
extern void show_current_time(void);
extern void read_program(void);
extern void program_sort(void);
extern void reset_target_actual(void);
extern void write_ram(u8 addr, u8 *dptr, u8 n);
extern void read_ram(u8 addr, u8 *dptr, u8 n);
extern void eeprom_erase_word(unsigned long addr);
extern void write_eeprom(unsigned long addr, u16 value);
extern u16 read_eeprom(unsigned long addr);
extern void clear_program(u8 *hours, u8 *minutes);
extern void clear_event(u8 *event);
extern void save(void);
extern void Open(void);
extern void set_char(s8 a,s8 b,s8 c,s8 d,s8 e, s8 f, u8 * segment);
extern void clk(void);
extern void load_edit_buffer(s32 val);
extern s32 reload_edit_buffer(void);
extern void load_edit_buffer_4digit(s16 val);
extern s16 reload_edit_buffer_4digit(void);
extern void shift_edit_buffer(void);
extern void shift_edit_buffer_4digit(void);
extern void check_cal_analog(void);

extern void operate_mode(void);

extern void edit_slave_address_mode(void);
extern void edit_baudrate_mode(void);
extern void edit_parity_mode(void);
extern void edit_delay_polls_mode(void);
extern void edit_response_timeout_mode(void);

extern void cal_analog_mode(void);
extern void idle_mode(void);

extern void EDIT_CIRCUMFERENCE_mode(void);
extern void edit_InputDelay_mode(void);
extern void edit_InputType_mode(void);

extern void edit_Mul_mode(void);
extern void edit_Div_mode(void);

extern void edit_Target(void);
extern void edit_Actual1(void);
extern void edit_Total(void);

extern void edit_TactTime(void);
extern void edit_SetTactTime(void);
extern void edit_CycleTimeTotal(void);
extern void edit_CycleTimeTarget(void);

extern void edit_SetPoint1(void);;
extern void edit_SetPoint2(void);

extern void edit_SetTime(void);
extern void edit_SetDate(void);
extern void edit_GetTime(void);
extern void edit_GetDate(void);

extern void edit_Break_ON(u8 Date);
extern void edit_Break_OFF(u8 Date);
extern void Reload_TimeON(u8 Date);
extern void Reload_TimeOFF(u8 Date);
extern u16 Time_On(u8 add);
extern u16 Time_Off(u8 add);
extern void edit_TimeRESET();
extern void Reload_TimeRESET();
extern void write_time_rtc(unsigned char add, unsigned char dptr);

extern void DateTime(void);
extern void Dis_Edit(void);
extern void Data_set01(void);

extern void config_uart2(void);

extern void set_mode_in_num(void);
extern void summary_and_percent_grade_c(void);
extern void edit_set_Grade_sum(void);
extern void retern_grade(s16* data);
extern void _delay(u32* val);
extern void Alarm_4_Function(s32 val, s32 mode, s32 high, s32 low, s32 conn, u8 Pin);
extern void Encoder(void);


extern u8 TimeUpdateRTC;
extern u16 TimeBlink;
extern u16 TimeSwitch;
extern u16 MatrixDigit;
extern u16 X_Time_ON_OFF;
extern u16 X_Time_RESET;
extern U16_uType BreakOn, BreakOff, ResetTime;
extern s8 MatrixData[MATRIX_LENGTH];
extern u8 Data_DIGR[8];
extern u8 Data_DIGG[8];
extern u8 Data_DIGr[MATRIX_LENGTH][8];
extern u8 Data_DIGg[MATRIX_LENGTH][8];
extern u8 SegmentDigit;
extern u8 SegmentData[SEGMENT_LENGTH];
extern u8 EditBuffer[EDIT_LENGTH];
extern u16 Dp;
extern u8 EditNum;
extern u8 ProgramIndex;
extern u8 TimeResetIndex;
extern u16 WorkingProgram;
extern u8 CurrentProgram;
extern s16 DataLastMB;
//extern u16 Break_ON[];
//extern u16 Break_OFF[];
extern u8 *MB_Dptr;
extern u32 x11,x33,x44;

extern Status_sType Status;
extern IR_sType IrData;
extern RTC_sType RTC;
extern Value_sType Value;
extern Mode_sType Mode;
extern MB_sType Modbus;
extern Trig_sType Trig0;
extern Trig_sType Trig1;
extern Trig_sType Trig2;
extern Trig_sType Trig3;
extern Trig_sType Trig4;
extern Trig_sType Trig5;
extern Trig_sType Trig6;
extern Trig_sType Trig7;
extern Trig_sType Encoder0;
extern Program_sType TimeReset[2];
extern Program_sType TimeResetBuff[2];
extern Program_sType Program[20];
extern Program_sType ProgramBuff[20];
extern Flag_uType Flag;
extern ADC_sType ADC;


#endif

