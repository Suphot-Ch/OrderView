#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

#define fData		SEGMENT_LENGTH//+4

void shift_data(u8 *dptr){
	u8 i;

	for(i=0x80;i>0;i=i/2){
		SER=(i&*dptr) ? 1 : 0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=1;
		SH_CLK=0;
	}
}
void shift_data2(u8 *dptr){
	u8 i;
 
	for(i=0x80;i>0;i=i/2){
		SER_2=(i&*dptr) ? 1 : 0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK_2=1;
		SH_CLK_2=0;
	}
}
void TPIC6B595_LATCH(u8 *dptr){
	u8 i;
	ST_CLK=0;
	SH_CLK=0;
	for(i=0;i<fData;i++,dptr++){
		shift_data(dptr);
	}
	ST_CLK=1;
	ST_CLK=0;	
}
void TPIC6B595_LATCH11(u8 val){
	u8 i;

	ST_CLK=0;
	SH_CLK=0;

	for(i=0x80;i>0;i=i/2){
		SER=(i&val) ? 0 : 1;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=1;
		SH_CLK=0;
	}

	ST_CLK=1;
	ST_CLK=0;
	
}
void TPIC6B595_LATCH2(u8 val){
	u8 i;

	ST_CLK_2=0;
	SH_CLK_2=0;

	for(i=0x80;i>0;i=i/2){
		SER_2=(i&val) ? 1 : 0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK_2=1;
		SH_CLK_2=0;
	}

	ST_CLK_2=1;
	ST_CLK_2=0;
	
}
void TPIC6B595_scan(void){
	u8 i, data[fData];
	u8 us;
u8 fixData[fData] = {
		0,0,	SegmentData[0],	SegmentData[1],	SegmentData[2],	SegmentData[3],
		0,0,	SegmentData[4],	SegmentData[5],	SegmentData[6],	SegmentData[7],
		};
	for(i=0; i<fData; i++){
		data[i]=0x00;
		data[i]=SegmentData[i];
		}
/*
	data[SegmentDigit]						= SegmentData[SegmentDigit];
	data[SegmentDigit+SEGMENT_COLUMN]		= SegmentData[SegmentDigit+SEGMENT_COLUMN];
	data[SegmentDigit+(SEGMENT_COLUMN*2)]	= SegmentData[SegmentDigit+(SEGMENT_COLUMN*2)];
	data[SegmentDigit+(SEGMENT_COLUMN*3)]	= SegmentData[SegmentDigit+(SEGMENT_COLUMN*3)];
	
	if(++SegmentDigit>=SEGMENT_LENGTH) SegmentDigit=0;
*/
	TPIC6B595_LATCH(data);
}

void TPIC6B595_init(void){
	u8 i,a;
	for(i=0;i<fData;i++){
		SegmentData[i]=FONT_BLANK;
	}
	//TPIC6B595_LATCH2(0x01);
}

