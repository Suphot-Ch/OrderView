#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"
//IR_sType IrData;
s8 IR_SW ;
extern u8 modeBlank;
void BUTTON_SET_TIME_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case EDIT_VALUE_TIME:
			break;
		case EDIT_VALUE_DATE:
			break;
		case EDIT_VALUE_YEAR:
			break;
		default:
			break;
	}
}
void BUTTON_DSP_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case EDIT_TIMER:
			break;
		default:
			break;
	}
}
void BUTTON_POWER_event(void){
	switch(Status.Main){
		case OPERATE:
			idle_mode();	
			break;
		case IDLE:
			operate_mode();
			break;
		default:
			break;
	}
}
void BUTTON_OP_MODE_event(void){
	switch(Status.Main){
		case OPERATE:
			// Value.Channel=0;
			// choose_mode();
			break;
		case CHOOSE_MODE:
			//if(!Value.Channel)Value.Channel=1;
//			else Value.Channel=0;
//			choose_mode();
			break;
		default:
			break;
	}
}
void BUTTON_ADD_event(void){
	switch(Status.Main){
		case OPERATE:
			edit_slave_address_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		default:
			break;
	}
}
void BUTTON_OSD_event(void){
	switch(Status.Main){
		case OPERATE:
//			edit_baudrate_mode();
			break;
		case EDIT_BAUDRATE:
//			edit_parity_mode();
			break;
		case EDIT_PARITY:
//			edit_baudrate_mode();
			break;
		default:
			break;
	}
}
void BUTTON_SIGN_event(void){
	switch(Status.Main){
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case ALH_MODE:
		case ALL_MODE:
		case ALC_MODE:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) return;
			Flag.Sign = Flag.Sign? 0 : 1 ;
			if(Flag.Sign==1&&EditBuffer[0]>1){
				EditBuffer[0]=1;
				EditBuffer[1]=9;
				EditBuffer[2]=9;
				EditBuffer[3]=9;
				EditBuffer[4]=9;
				}
			break;
		default:
			break;
	}
}
void BUTTON_F1_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case ALH_MODE:
			break;
		case ALL_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_F2_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case ALH_MODE:
			break;
		case ALL_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_F3_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case ALC_MODE:
			break;
		default:
			break;
	}
}
void BUTTON_F4_event(void){
	switch(Status.Main){
		case OPERATE:
			Value.Channel=0;
			pus_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_PLUS_event(void){
	switch(Status.Main){
		case OPERATE:
			Value.Channel=0;
			edit_scale_hi_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		default:
			break;
	}
}
void BUTTON_SCALE_MINUS_event(void){
	switch(Status.Main){
		case OPERATE:
			Value.Channel=0;
			edit_scale_lo_mode();  
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		default:
			break;
	}
}
void BUTTON_VOL_PLUS_event(void){

	switch(Status.Main){
		case CAL_ANALOG:
			if(Value.Channel<SETT_LENGTH-1)Value.Channel++;
			break;
		// case EDIT_SCALE_HI:
		// 	edit_scale_lo_mode();  
		// 	break;
		// case EDIT_SCALE_LO:
		// 	edit_scale_hi_mode();  
		// 	break;
		// case ALH_MODE:
		// 	if(++Value.Channel>=4)Value.Channel=0;
		// 	alarm_high_mode();
		// 	break;
		// case ALL_MODE:
		// 	if(++Value.Channel>=4)Value.Channel=0;
		// 	alarm_low_mode();
		// 	break;
		case EDIT_SCALE_HI:
			if(Value.Channel<SETT_LENGTH-1)Value.Channel++;
			edit_scale_hi_mode();
			break;
		case EDIT_SCALE_LO:
			if(Value.Channel<SETT_LENGTH-1)Value.Channel++;
			edit_scale_lo_mode();  
			break;
		case EDIT_PUS_MODE:
			if(Value.Channel<SETT_LENGTH-1)Value.Channel++;
			pus_mode();
			break;
		case EDIT_DP:
			if(Value.Channel<SETT_LENGTH-1)Value.Channel++;
			edit_decimalpoint_mode();
			break;
		default:
			break;
	}
}
void BUTTON_VOL_MINUS_event(void){

	switch(Status.Main){
		case CAL_ANALOG:
			if(Value.Channel>0)Value.Channel--;
			break;
		// case ALH_MODE:
		// 	if(--Value.Channel < 0)Value.Channel = 3;
		// 	alarm_high_mode();
		// 	break;
		// case ALL_MODE:
		// 	if(--Value.Channel < 0)Value.Channel = 3;
		// 	alarm_low_mode();
		// 	break;
		case EDIT_SCALE_HI:
			if(Value.Channel>0)Value.Channel--;
			edit_scale_hi_mode();
			break;
		case EDIT_SCALE_LO:
			if(Value.Channel>0)Value.Channel--;
			edit_scale_lo_mode();  
			break;
		case EDIT_PUS_MODE:
			if(Value.Channel>0)Value.Channel--;
			pus_mode();
			break;
		case EDIT_DP:
			if(Value.Channel>0)Value.Channel--;
			edit_decimalpoint_mode();
			break;
		default:
			break;
	}
}
void BUTTON_CANCEL_event(void){
	switch(Status.Main){
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case SETPOINT_2_MODE:
		case HYS_MODE:
		case EDIT_PUS_MODE:	
		case ALL_MODE:
		case ALH_MODE:	
		case ALC_MODE:
		case CHOOSE_MODE:
			operate_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_BAUDRATE:
		case EDIT_PARITY:
		case EDIT_DELAY_POLLS:
		case EDIT_RESPONSE_TIMEOUT:
		case CHANGE_DSP:
		case EDIT_DP:
		case EDIT_TIMER:
			operate_mode();
			break;
		default:
			operate_mode();
			break;
	}
}
void BUTTON_ENTER_event(void){
	switch(Status.Main){
		case CAL_ANALOG:
			if(!Flag.Edit&&!Flag.CalPoint){ Flag.Edit=1; Flag.CalPoint=0; }
			else if(Flag.Edit&&!Flag.CalPoint){save();	 Flag.Edit=0; Flag.CalPoint=1; }
			else if(!Flag.Edit&&Flag.CalPoint){ Flag.Edit=1; Flag.CalPoint=1; }
			else if(Flag.Edit&&Flag.CalPoint){ save();	Flag.Edit=0; Flag.CalPoint=0; operate_mode();}
			break;
		case MODE_INP:
			if(!Flag.Stage){
				Flag.Stage=1;
				}
			else{
				if(modeBlank==CAL_ANALOG){
					if(Flag.Edit&&Flag.CalPoint)
						operate_mode();
					}
				}
			break;
		case EDIT_SCALE_HI:		
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				if((reload_edit_buffer()>Value.ScaleLoLimit[Value.Channel].LWord)&&(reload_edit_buffer()<=999&&reload_edit_buffer()>=-199)){
					Value.ScaleHiLimit[Value.Channel].LWord=reload_edit_buffer();
					save();
					operate_mode();
					// edit_scale_lo_mode();
					}
				}
			break;
		case EDIT_SCALE_LO:		
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				if((reload_edit_buffer()<Value.ScaleHiLimit[Value.Channel].LWord)&&(reload_edit_buffer()<=999&&reload_edit_buffer()>=-199)){
					Value.ScaleLoLimit[Value.Channel].LWord=reload_edit_buffer();
					save();
					operate_mode();
					}
				}		
			break;
		case EDIT_PUS_MODE:
				if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				if(reload_edit_buffer()<=999&&reload_edit_buffer()>=-199){
					Value.PVS[Value.Channel].LWord=reload_edit_buffer();
					save();
					operate_mode();
					}
				}
			break;
		case EDIT_DP:			
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				Value.DecimalPoint[Value.Channel]=reload_edit_buffer();
				save();
				operate_mode();
				}		
			break;
#ifdef ALARM_EN
		case ALL_MODE:
				if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
					 if(Value.Channel == AL0_PV0){
					if((reload_edit_buffer()>Value.ALL[AL1_PV0].LWord)&&(reload_edit_buffer()<Value.ALH[AL0_PV0].LWord)){
						Value.ALL[AL0_PV0].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL1_PV0){
					if((reload_edit_buffer()<Value.ALL[AL0_PV0].LWord)){
						Value.ALL[AL1_PV0].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL0_PV1){
					if((reload_edit_buffer()>Value.ALL[AL1_PV1].LWord)&&(reload_edit_buffer()<Value.ALH[AL0_PV1].LWord)){
						Value.ALL[AL0_PV1].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL1_PV1){
					if((reload_edit_buffer()<Value.ALL[AL0_PV1].LWord)){
						Value.ALL[AL1_PV1].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				}
			break;
		case ALH_MODE:
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
					 if(Value.Channel == AL0_PV0){
					if((reload_edit_buffer()>Value.ALL[AL0_PV0].LWord)&&(reload_edit_buffer()<Value.ALH[AL1_PV0].LWord)){
						Value.ALH[AL0_PV0].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL1_PV0){
					if((reload_edit_buffer()>Value.ALH[AL0_PV0].LWord)){
						Value.ALH[AL1_PV0].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL0_PV1){
					if((reload_edit_buffer()>Value.ALL[AL0_PV1].LWord)&&(reload_edit_buffer()<Value.ALH[AL1_PV1].LWord)){
						Value.ALH[AL0_PV1].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				else if(Value.Channel == AL1_PV1){
					if((reload_edit_buffer()>Value.ALH[AL0_PV1].LWord)){
						Value.ALH[AL1_PV1].LWord=reload_edit_buffer();
						save();
						operate_mode();
						}
					}
				}
			break;
		case ALC_MODE:
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				if(reload_edit_buffer()<=9999&&reload_edit_buffer()>=-1999){
					Value.ALC[Value.Channel].LWord=reload_edit_buffer();
					save();
					operate_mode();
					}
				}
			break;	
		case CHOOSE_MODE:
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
				}
			else{
				if(EditBuffer[2]<=5){
					Value.Mode[Value.Channel]=reload_edit_buffer();
					save();
					operate_mode();
					}
				}
			break;
#endif
#ifndef RS485_MODBUS_RTU
		case EDIT_ADDRESS:
			if(!Flag.Edit){			
				Flag.Edit=1;
				load_edit_buffer(Value.SlaveAddress);
				EditNum=1;
			}
			else{
				if(reload_edit_buffer()>=1&&reload_edit_buffer()<=255){
					Value.SlaveAddress=reload_edit_buffer();
					save();
				}
				operate_mode();
			}
			break;
		case EDIT_BAUDRATE:
			if(!Flag.Edit){			
				Flag.Edit=1;
				EditNum=1;
			}
			else{
				if(EditBuffer[EDIT_LENGTH-1]<=5){
					Value.Baudrate=EditBuffer[EDIT_LENGTH-1];
					save();
					config_uart2();
				}
				Flag.Edit=0;
				operate_mode();
			}
			break;
		case EDIT_PARITY:
			if(!Flag.Edit){			
				Flag.Edit=1;
				load_edit_buffer(Value.Parity);
				EditNum=1;
			}
			else{
				if(reload_edit_buffer()<=2){
					Value.Parity=reload_edit_buffer();
					save();
					config_uart2();
				}
				Flag.Edit=0;
				operate_mode();
			}
			break;
#endif
#ifdef RS485_MODBUS_RTU_MASTER

		case EDIT_DELAY_POLLS:
			if(!Flag.Edit){			
				Flag.Edit=1;
				load_edit_buffer(Value.DelayBetweenPolls);
				EditNum=1;
			}
			else{
				if((reload_edit_buffer()<=1000)&&(reload_edit_buffer()>=5)){
					Value.DelayBetweenPolls=reload_edit_buffer();
					save();
					config_uart2();
				}
				Flag.Edit=0;
				//operate_mode();
			}
			break;
		case EDIT_RESPONSE_TIMEOUT:
			if(!Flag.Edit){			
				Flag.Edit=1;
				load_edit_buffer(Value.ResponseTimeOut);
				EditNum=1;
			}
			else{
				if((reload_edit_buffer()<=1000)&&(reload_edit_buffer()>=5)){
					Value.ResponseTimeOut=reload_edit_buffer();
					save();
					config_uart2();
				}
				Flag.Edit=0;
				//operate_mode();
			}
			break;
#endif
		default:
			break;
	}
}
void BUTTON_MENU_event(void){
	switch(Status.Main){
		case OPERATE:
			break;
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
		case EDIT_DP:
		case CAL_ANALOG:
		case EDIT_ADDRESS:
		case EDIT_PARITY:
		case EDIT_BAUDRATE:
			Mode_Blank();
			break;
		case MODE_INP:
			LoadMode_Blank();
			break;
		case ALL_MODE:
		case ALH_MODE:	
			Clear_Buffer();
			break;
		case IDLE:
			if(++Value.Analog_cal>=5)
				{
				cal_analog_mode();
		#ifdef master2
			Mode_Blank();
		#endif
				}
			Value.TimeOut_cal = 300;
			break;
		default:
			break;
	}
}
void BUTTON_DP_event(void){
	switch(Status.Main){
		case OPERATE:
			Value.Channel=0;
			edit_decimalpoint_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		case EDIT_DP:
		default:
			break;
		}
}
void BUTTON_Time_edit(u8 RF){
	switch(EditNum){
		case 1:
			if(Status.Main == EDIT_VALUE_TIME){
				if(RF<=2){	EditBuffer[0]=RF;		EditNum = 2;	}
				}
			else if(Status.Main == EDIT_VALUE_DATE){
				if(RF<=3){	EditBuffer[0]=RF;		EditNum = 2;	}
				}
			else {
							EditBuffer[0]=RF;		EditNum = 2;
				}
			break;
		case 2:
			if(Status.Main == EDIT_VALUE_TIME){
				if(EditBuffer[0]>=2){
					if(RF<=3){ 	EditBuffer[1]=RF;		EditNum = 3;	}
					else {break;}//		EditBuffer[1]=RF;		EditNum = 3;	}
					}
				else {			EditBuffer[1]=RF;		EditNum = 3;	}
				}
			else if(Status.Main == EDIT_VALUE_DATE){
				if(EditBuffer[0]>=3){
					if(RF<=1){ 	EditBuffer[1]=RF;		EditNum = 3;	}
					else {break;}//		EditBuffer[1]=RF;		EditNum = 3;	}
					}
				else if(EditBuffer[0]<=0){
					if(RF>=1){ 	EditBuffer[1]=RF;		EditNum = 3;	}
					else {break;}//		EditBuffer[1]=RF;		EditNum = 3;	}
					}
				else {			EditBuffer[1]=RF;		EditNum = 3;	}
				}
			else {
								EditBuffer[1]=RF;		EditNum = 3;
				}
			break;
		case 3:
			if(Status.Main == EDIT_VALUE_TIME){
				if(RF<=5){	EditBuffer[2]=RF;		EditNum = 4;	}
				}
			else if(Status.Main == EDIT_VALUE_DATE){
				if(RF<=1){	EditBuffer[2]=RF;		EditNum = 4;	}
				}
			else {
							EditBuffer[2]=RF;		EditNum = 4;
				}
			break;
		case 4:
			if(Status.Main == EDIT_VALUE_TIME){
								EditBuffer[3]=RF;		EditNum = 5;
				reload_buffer_Time();
				edit_value_date();
				}
			else if(Status.Main == EDIT_VALUE_DATE){
				if(EditBuffer[2]>=1){
					if(RF<=2){ 	EditBuffer[3]=RF;		EditNum = 5;	}
					else {break;}//		EditBuffer[3]=RF;		EditNum = 5;	}
					}
				else if(EditBuffer[2]<=0){
					if(RF>=1){ 	EditBuffer[3]=RF;		EditNum = 5;	}
					else {break;}//		EditBuffer[1]=RF;		EditNum = 3;	}
					}
				else {			EditBuffer[3]=RF;		EditNum = 5;	}
				reload_buffer_Date();
				edit_value_year();
				}
			else {
								EditBuffer[3]=RF;		EditNum = 5;
				reload_buffer_Year();
				operate_mode();
				}
			break;
		}
}
void BUTTON_BUFFER3(s8 _SW){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				if(Flag.Sign) Flag.Sign=0;
			}
			EditBuffer[2]=_SW;
			EditNum++;
			break;
		default:
			break;
	}
}
void BUTTON_BUFFER4(s8 _SW){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
		case 4:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
				if(Flag.Sign) Flag.Sign=0;
			}
			EditBuffer[3]=_SW;
			EditNum++;
			break;
		default:
			break;
	}
}
void BUTTON_BUFFER(s8 _SW){
	switch(EditNum){
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			if(EditNum!=1){
				shift_edit_buffer();
			}
			else{
				EditBuffer[0]=0;
				EditBuffer[1]=0;
				EditBuffer[2]=0;
				if(Flag.Sign) Flag.Sign=0;
			}
			EditBuffer[3]=_SW;
			EditNum++;
			break;
		default:
			break;
	}
}
void BUTTON_0_event(void){	
	IR_SW=0;
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case CHOOSE_MODE:
		case EDIT_DP:
		case EDIT_BAUDRATE:
		case EDIT_PARITY:
			if(!Flag.Edit) break;;
			switch(EditNum){
				case 1:
					EditBuffer[EDIT_LENGTH-1]=IR_SW;
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}
void BUTTON_1_event(void){	
	IR_SW=1;
	switch(Status.Main){
		case OPERATE:
			edit_baudrate_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case EDIT_BAUDRATE:
			if(!Flag.Edit){
				Mode_Blank();
			}
			else{
				switch(EditNum){
					case 1:
						EditBuffer[EDIT_LENGTH-1]=IR_SW;
						break;
					default:
						break;
				}
			}
			break;
		case EDIT_DP:
		case CHOOSE_MODE:
		case EDIT_PARITY:
			if(!Flag.Edit) break;;
			switch(EditNum){
				case 1:
					EditBuffer[EDIT_LENGTH-1]=IR_SW;
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}
void BUTTON_2_event(void){
	IR_SW=2;	
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case EDIT_DP:
		case CHOOSE_MODE:
		case EDIT_BAUDRATE:
		case EDIT_PARITY:
			if(!Flag.Edit) break;;
			switch(EditNum){
				case 1:
					EditBuffer[EDIT_LENGTH-1]=IR_SW;
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}
void BUTTON_3_event(void){	
	IR_SW=3;
	switch(Status.Main){
		case OPERATE:
			edit_parity_mode();
		#ifdef master2
			Mode_Blank();
		#endif
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
//		case EDIT_DP:
		case CHOOSE_MODE:
		case EDIT_BAUDRATE:
			if(!Flag.Edit) break;;
			switch(EditNum){
				case 1:
					EditBuffer[EDIT_LENGTH-1]=IR_SW;
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}
void BUTTON_4_event(void){	
	IR_SW=4;
	switch(Status.Main){
		case OPERATE:
//			switch(EditNum){
//				case 3:
//					EditBuffer[3]=4;
//					EditNum++;
//					Value.CalAnTimeOut=0;
//					break;
//				default:
//					break;
//			}
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
//		case EDIT_DP:
		case CHOOSE_MODE:
		case EDIT_BAUDRATE:
			if(!Flag.Edit) break;;
			switch(EditNum){
				case 1:
					EditBuffer[EDIT_LENGTH-1]=IR_SW;
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}
}
void BUTTON_5_event(void){	
	IR_SW=5;
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		default:
			break;
	}
}
void BUTTON_6_event(void){	
	IR_SW=6;
	switch(Status.Main){
		case OPERATE:
//			switch(EditNum){
//				case 1:
//					EditBuffer[1]=6;
//					EditNum++;
//					Value.CalAnTimeOut=0;
//					break;
//				default:
//					break;
//			}
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		default:
			break;
	}
}
void BUTTON_7_event(void){	
	IR_SW=7;
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		default:
			break;
	}
}
void BUTTON_8_event(void){	
	IR_SW=8;
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		default:
			break;
	}
}
void BUTTON_9_event(void){	
	IR_SW=9;
	switch(Status.Main){
		case OPERATE:
			//cal_mode();
			break;
		case EDIT_ADDRESS:
		case EDIT_SCALE_HI:
		case EDIT_SCALE_LO:
		case EDIT_PUS_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER3(IR_SW);
			break;
		case ALH_MODE:
		case ALL_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		case ALC_MODE:
			if(!Flag.Edit) break;;
				BUTTON_BUFFER4(IR_SW);
			break;
		default:
			break;
	}
}
void ir_decode(void){
	u8 i;
	/*insert code here for active*/
	if(Flag.IrDecode){
		if(++IrData.TimeOut>=TIME20mSEC){
			IrData.TimeOut=CLR;
			if(IrData.ByteCount==11){
				//Flag.IrDecode=CLR;	
				IrData.Decode=CLR;
				for(i=0;i<IrData.ByteCount;i++){
					if(IrData.Buffer[i]>=IrDataLogic_0) IrData.Decode+=1;
					IrData.Decode<<=1;
				}
				if(IrData.Decode!=IrData.DecodeLast){
					IrData.DecodeLast=IrData.Decode;
					Flag.Blink = 0;
					TimeBlink = 0;
					switch(IrData.Decode){
						case BUTTON_A1:
							BUTTON_SET_TIME_event();
							break;
						case BUTTON_A2:
							BUTTON_DSP_event();
							break;
						case BUTTON_A3:
							BUTTON_POWER_event();
							break;
						case BUTTON_A4:
							BUTTON_OP_MODE_event();
							break;
						case BUTTON_A5:
							BUTTON_ADD_event();
							break;
						case BUTTON_A6:
							BUTTON_OSD_event();
							break;
						case BUTTON_A7:
							BUTTON_SIGN_event();
							break;
						case BUTTON_A8:
							BUTTON_F1_event();
							break;
						case BUTTON_A9:
							BUTTON_SCALE_PLUS_event();
							break;
						case BUTTON_A10:
							BUTTON_VOL_PLUS_event();
							break;
						case BUTTON_A11:
							BUTTON_F2_event();
							break;
						case BUTTON_A12:
							BUTTON_SCALE_MINUS_event();
							break;
						case BUTTON_A13:
							BUTTON_VOL_MINUS_event();
							break;
						case BUTTON_A14:
							BUTTON_F3_event();
							break;
						case BUTTON_A15:
							BUTTON_CANCEL_event();
							break;
						case BUTTON_A16:
							BUTTON_ENTER_event();
							break;
						case BUTTON_A17:
							BUTTON_F4_event();
							break;
						case BUTTON_A18:
							BUTTON_MENU_event();
							break;
						case BUTTON_A19:
							BUTTON_DP_event();
							break;
						case BUTTON_0:
							BUTTON_0_event();
							break;
						case BUTTON_1:
							BUTTON_1_event();
							break;
						case BUTTON_2:
							BUTTON_2_event();
							break;
						case BUTTON_3:
							BUTTON_3_event();
							break;
						case BUTTON_4:
							BUTTON_4_event();
							break;
						case BUTTON_5:
							BUTTON_5_event();
							break;
						case BUTTON_6:
							BUTTON_6_event();
							break;
						case BUTTON_7:
							BUTTON_7_event();
							break;
						case BUTTON_8:
							BUTTON_8_event();
							break;
						case BUTTON_9:
							BUTTON_9_event();
							break;
						default:
							break;
					}
				}
			}
			IrData.Status=CLR;
			Flag.IrDecode=CLR;	
			IrData.ByteCount=CLR;
		}
	}
	else{
		if(++IrData.TimeOut>=5){
			IrData.TimeOut=CLR;
			IrData.Decode=CLR;
			IrData.DecodeLast=CLR;
		}
	}
}

