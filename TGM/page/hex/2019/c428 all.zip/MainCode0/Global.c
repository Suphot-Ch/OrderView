#ifndef GLOBAL_C
#include "config.h"
#include "typedef.h"

//enum{INITIAL, OPERATION, SET};
//enum{ key_mute=0b001010010000,  key_display=0b010111010000,  key_power=0b101010010000,  key_text=0b111111010000, key_video=0b101001010000, key_tv=0b000111010000, key0=0b100100010000, key1=0b000000010000, key2=0b100000010000, key3=0b010000010000, key4=0b110000010000, key5=0b001000010000, key6=0b101000010000, key7=0b011000010000, key8=0b111000010000, key9=0b000100010000, key__=0b101110010000, key_sleep=0b011011010000, key_menu_plus=0b001011110000, key_menu_sub=0b101011110000, key_menu=0b000001110000, key_enter=0b101001110000, key_a_b=0b111010010000, key_vol_plus=0b010010010000, key_vol_sub=0b110010010000, key_prog_plus=0b000010010000,key_prog_sub=0b100010010000};
u8 MainStatus;
u8 TimeUpdateRTC;
u16 TimeBlink;
u32 TimeSwitch;
u16 MatrixDigit;
u16 X_Time_ON_OFF;
u16 X_Time_RESET;
U16_uType BreakOn, BreakOff, ResetTime;
	
u8 MatrixData[MATRIX_LENG];
u8 Data_DIGR[8];
u8 Data_DIGG[8];
u8 Data_DIGr[MATRIX_LENGTH+1][8];
u8 Data_DIGg[MATRIX_LENGTH+1][8];
u8 SegmentDigit;
u8 SegmentData[SEGMENT_LENGTH];	// Segmant ALL 
u8 EditBuffer[EDIT_LENGTH];
u16 Dp;
u8 EditNum;
u8 ProgramIndex;
u8 TimeResetIndex;
u16 WorkingProgram;
u16 CurrentProgram;
s16 DataLastMB;
//u16 Break_ON[];
//u16 Break_OFF[];

u8 *MB_Dptr;

Status_sType Status;
IR_sType IrData;
Value_sType Value;
Mode_sType Mode;
RTC_sType RTC;
MB_sType Modbus;
Trig_sType Trig0;
Trig_sType Trig1;
Trig_sType Trig2;
Trig_sType Trig3;
Trig_sType Trig4;
Trig_sType Trig5;
Trig_sType Trig6;
Trig_sType Trig7;
Program_sType TimeReset[2];
Program_sType TimeResetBuff[2];
Program_sType Program[20];
Program_sType ProgramBuff[20];
Flag_uType Flag;
ADC_sType ADC;
#endif

