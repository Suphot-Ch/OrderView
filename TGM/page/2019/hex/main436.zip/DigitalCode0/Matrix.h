

#define S1A1 0x01
#define S1A2 0x02
#define S1A3 0x04
#define S1A4 0x08
#define S1A5 0x10
/******************************************/
#define S1B5 0x20
#define S1B4 0x40
#define S1B3 0x80

#define S2B2 0x01
#define S2B1 0x02
/******************************************/
#define S2C5 0x04
#define S2C4 0x08
#define S2C3 0x10
#define S2C2 0x20
#define S2C1 0x40
/******************************************/
#define S2D5 0x80

#define S3D4 0x01
#define S3D3 0x02
#define S3D2 0x04
#define S3D1 0x08
/******************************************/

/******************************************/
#define S3E1 0x10
#define S3E2 0x20
#define S3E3 0x40
#define S3E4 0x80
#define S4E5 0x01
/******************************************/
#define S4F1 0x02
#define S4F2 0x04
#define S4F3 0x08
#define S4F4 0x10
#define S4F5 0x20
/******************************************/
#define S4G1 0x40
#define S4G2 0x80
#define S5G3 0x01
#define S5G4 0x02
#define S5G5 0x04

 /*     BLANK               */																						
#define S1FONT_BLANK 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font BLANK																						
#define S2FONT_BLANK 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font BLANK																						
#define S3FONT_BLANK 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font BLANK																						
#define S4FONT_BLANK 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font BLANK																						
#define S5FONT_BLANK 0x00|0x00|0x00                                                                        // IC 5 Set Font BLANK																						

 /*     EXC     !          */																						
#define S1FONT_EXC 0x00|0x00|S1A3|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font EXC																						
#define S2FONT_EXC 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font EXC																						
#define S3FONT_EXC 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font EXC																						
#define S4FONT_EXC 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font EXC																						
#define S5FONT_EXC S5G3|0x00|0x00                                                                        // IC 5 Set Font EXC																						

 /*     QUOTE_2     ″          */																						
#define S1FONT_QUOTE_2 S1A5|S1A4|0x00|S1A2|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font QUOTE_2																						
#define S2FONT_QUOTE_2 S2B2|0x00|S2C1|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font QUOTE_2																						
#define S3FONT_QUOTE_2 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font QUOTE_2																						
#define S4FONT_QUOTE_2 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font QUOTE_2																						
#define S5FONT_QUOTE_2 0x00|0x00|0x00                                                                        // IC 5 Set Font QUOTE_2																						

 /*     HASH     #          */																						
#define S1FONT_HASH 0x00|S1A4|0x00|S1A2|0x00|0x00|S1B4|0x00                    // IC 1 Set Font HASH																						
#define S2FONT_HASH S2B2|0x00|S2C1|S2C2|S2C3|S2C4|S2C5|0x00                    // IC 2 Set Font HASH																						
#define S3FONT_HASH S3D4|0x00|S3D2|0x00|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font HASH																						
#define S4FONT_HASH S4E5|0x00|S4F2|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font HASH																						
#define S5FONT_HASH 0x00|S5G4|0x00                                                                        // IC 5 Set Font HASH																						

 /*     DOLLAR     $          */																						
#define S1FONT_DOLLAR 0x00|0x00|S1A3|0x00|0x00|S1B5|S1B4|S1B3                    // IC 1 Set Font DOLLAR																						
#define S2FONT_DOLLAR S2B2|0x00|S2C1|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font DOLLAR																						
#define S3FONT_DOLLAR S3D4|S3D3|S3D2|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font DOLLAR																						
#define S4FONT_DOLLAR S4E5|S4F1|S4F2|S4F3|S4F4|0x00|0x00|0x00                    // IC 4 Set Font DOLLAR																						
#define S5FONT_DOLLAR S5G3|0x00|0x00                                                                        // IC 5 Set Font DOLLAR																						

 /*     PERCENT     %          */																						
#define S1FONT_PERCENT S1A5|S1A4|0x00|0x00|0x00|S1B5|0x00|0x00                    // IC 1 Set Font PERCENT																						
#define S2FONT_PERCENT S2B2|S2B1|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font PERCENT																						
#define S3FONT_PERCENT 0x00|S3D3|0x00|0x00|0x00|S3E2|0x00|0x00                    // IC 3 Set Font PERCENT																						
#define S4FONT_PERCENT 0x00|S4F1|0x00|0x00|S4F4|S4F5|0x00|0x00                    // IC 4 Set Font PERCENT																						
#define S5FONT_PERCENT 0x00|S5G4|S5G5                                                                        // IC 5 Set Font PERCENT																						

 /*     AM     &          */																						
#define S1FONT_AM 0x00|S1A4|0x00|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font AM																						
#define S2FONT_AM 0x00|S2B1|S2C1|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font AM																						
#define S3FONT_AM 0x00|0x00|S3D2|0x00|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font AM																						
#define S4FONT_AM S4E5|S4F1|0x00|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font AM																						
#define S5FONT_AM S5G3|0x00|S5G5                                                                        // IC 5 Set Font AM																						

 /*     QUOTE_1     ′          */																						
#define S1FONT_QUOTE_1 0x00|0x00|S1A3|S1A2|0x00|0x00|S1B4|0x00                    // IC 1 Set Font QUOTE_1																						
#define S2FONT_QUOTE_1 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font QUOTE_1																						
#define S3FONT_QUOTE_1 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font QUOTE_1																						
#define S4FONT_QUOTE_1 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font QUOTE_1																						
#define S5FONT_QUOTE_1 0x00|0x00|0x00                                                                        // IC 5 Set Font QUOTE_1																						

 /*     PER_O     (          */																						
#define S1FONT_PER_O 0x00|0x00|S1A3|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font PER_O																						
#define S2FONT_PER_O S2B2|0x00|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font PER_O																						
#define S3FONT_PER_O 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font PER_O																						
#define S4FONT_PER_O 0x00|0x00|S4F2|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font PER_O																						
#define S5FONT_PER_O S5G3|0x00|0x00                                                                        // IC 5 Set Font PER_O																						

 /*     PER_C     )          */																						
#define S1FONT_PER_C 0x00|0x00|S1A3|0x00|0x00|0x00|S1B4|0x00                    // IC 1 Set Font PER_C																						
#define S2FONT_PER_C 0x00|0x00|0x00|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font PER_C																						
#define S3FONT_PER_C 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font PER_C																						
#define S4FONT_PER_C S4E5|0x00|0x00|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font PER_C																						
#define S5FONT_PER_C S5G3|0x00|0x00                                                                        // IC 5 Set Font PER_C																						

 /*     AS     *          */																						
#define S1FONT_AS 0x00|0x00|0x00|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font AS																						
#define S2FONT_AS 0x00|0x00|S2C1|0x00|S2C3|0x00|S2C5|0x00                    // IC 2 Set Font AS																						
#define S3FONT_AS S3D4|S3D3|S3D2|0x00|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font AS																						
#define S4FONT_AS S4E5|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font AS																						
#define S5FONT_AS 0x00|0x00|0x00                                                                        // IC 5 Set Font AS																						

 /*     PLUS     +          */																						
#define S1FONT_PLUS 0x00|0x00|0x00|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font PLUS																						
#define S2FONT_PLUS 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|S2D5                    // IC 2 Set Font PLUS																						
#define S3FONT_PLUS S3D4|S3D3|S3D2|S3D1|0x00|0x00|S3E3|0x00                    // IC 3 Set Font PLUS																						
#define S4FONT_PLUS 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font PLUS																						
#define S5FONT_PLUS 0x00|0x00|0x00                                                                        // IC 5 Set Font PLUS																						

 /*     COMA     ,          */																						
#define S1FONT_COMA 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font COMA																						
#define S2FONT_COMA 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font COMA																						
#define S3FONT_COMA 0x00|0x00|0x00|0x00|0x00|0x00|S3E3|S3E4                    // IC 3 Set Font COMA																						
#define S4FONT_COMA 0x00|0x00|0x00|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font COMA																						
#define S5FONT_COMA S5G3|0x00|0x00                                                                        // IC 5 Set Font COMA																						

 /*     HYPHEN     -          */																						
#define S1FONT_HYPHEN 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font HYPHEN																						
#define S2FONT_HYPHEN 0x00|0x00|0x00|0x00|0x00|0x00|0x00|S2D5                    // IC 2 Set Font HYPHEN																						
#define S3FONT_HYPHEN S3D4|S3D3|S3D2|S3D1|0x00|0x00|0x00|0x00                    // IC 3 Set Font HYPHEN																						
#define S4FONT_HYPHEN 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font HYPHEN																						
#define S5FONT_HYPHEN 0x00|0x00|0x00                                                                        // IC 5 Set Font HYPHEN																						

 /*     FULLSTOP     .          */																						
#define S1FONT_FULLSTOP 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font FULLSTOP																						
#define S2FONT_FULLSTOP 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font FULLSTOP																						
#define S3FONT_FULLSTOP 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font FULLSTOP																						
#define S4FONT_FULLSTOP 0x00|S4F1|S4F2|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font FULLSTOP																						
#define S5FONT_FULLSTOP 0x00|0x00|0x00                                                                        // IC 5 Set Font FULLSTOP																						

 /*     SLASH     /          */																						
#define S1FONT_SLASH 0x00|0x00|0x00|0x00|0x00|S1B5|0x00|0x00                    // IC 1 Set Font SLASH																						
#define S2FONT_SLASH 0x00|0x00|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font SLASH																						
#define S3FONT_SLASH 0x00|S3D3|0x00|0x00|0x00|S3E2|0x00|0x00                    // IC 3 Set Font SLASH																						
#define S4FONT_SLASH 0x00|S4F1|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font SLASH																						
#define S5FONT_SLASH 0x00|0x00|0x00                                                                        // IC 5 Set Font SLASH																						

 /*     0     0          */																						
#define S1FONT_0 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 0																						
#define S2FONT_0 0x00|S2B1|S2C1|0x00|0x00|S2C4|S2C5|S2D5                    // IC 2 Set Font 0																						
#define S3FONT_0 0x00|S3D3|0x00|S3D1|S3E1|S3E2|0x00|0x00                    // IC 3 Set Font 0																						
#define S4FONT_0 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 0																						
#define S5FONT_0 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 0																						

 /*     1     1          */																						
#define S1FONT_1 0x00|0x00|S1A3|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font 1																						
#define S2FONT_1 S2B2|0x00|S2C1|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font 1																						
#define S3FONT_1 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font 1																						
#define S4FONT_1 0x00|0x00|0x00|S4F3|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 1																						
#define S5FONT_1 S5G3|S5G4|S5G5                                                                        // IC 5 Set Font 1																						

 /*     2     2          */																						
#define S1FONT_2 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 2																						
#define S2FONT_2 0x00|S2B1|0x00|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font 2																						
#define S3FONT_2 S3D4|S3D3|0x00|0x00|0x00|S3E2|0x00|0x00                    // IC 3 Set Font 2																						
#define S4FONT_2 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 2																						
#define S5FONT_2 S5G3|S5G4|S5G5                                                                        // IC 5 Set Font 2																						

 /*     3     3          */																						
#define S1FONT_3 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 3																						
#define S2FONT_3 0x00|S2B1|0x00|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font 3																						
#define S3FONT_3 S3D4|S3D3|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font 3																						
#define S4FONT_3 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 3																						
#define S5FONT_3 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 3																						

 /*     4     4          */																						
#define S1FONT_4 0x00|0x00|0x00|S1A2|0x00|0x00|S1B4|S1B3                    // IC 1 Set Font 4																						
#define S2FONT_4 0x00|0x00|0x00|S2C2|0x00|S2C4|0x00|0x00                    // IC 2 Set Font 4																						
#define S3FONT_4 S3D4|0x00|0x00|S3D1|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font 4																						
#define S4FONT_4 S4E5|0x00|0x00|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font 4																						
#define S5FONT_4 0x00|S5G4|0x00                                                                        // IC 5 Set Font 4																						

 /*     5     5          */																						
#define S1FONT_5 S1A5|S1A4|S1A3|S1A2|S1A1|0x00|0x00|0x00                    // IC 1 Set Font 5																						
#define S2FONT_5 0x00|S2B1|S2C1|S2C2|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font 5																						
#define S3FONT_5 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font 5																						
#define S4FONT_5 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 5																						
#define S5FONT_5 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 5																						

 /*     6     6          */																						
#define S1FONT_6 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 6																						
#define S2FONT_6 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font 6																						
#define S3FONT_6 S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font 6																						
#define S4FONT_6 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 6																						
#define S5FONT_6 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 6																						

 /*     7     7          */																						
#define S1FONT_7 S1A5|S1A4|S1A3|S1A2|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font 7																						
#define S2FONT_7 0x00|0x00|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font 7																						
#define S3FONT_7 0x00|S3D3|0x00|0x00|0x00|S3E2|0x00|0x00                    // IC 3 Set Font 7																						
#define S4FONT_7 0x00|0x00|S4F2|0x00|0x00|0x00|0x00|S4G2                    // IC 4 Set Font 7																						
#define S5FONT_7 0x00|0x00|0x00                                                                        // IC 5 Set Font 7																						

 /*     8     8          */																						
#define S1FONT_8 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 8																						
#define S2FONT_8 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font 8																						
#define S3FONT_8 S3D4|S3D3|S3D2|0x00|S3E1|0x00|0x00|0x00                    // IC 3 Set Font 8																						
#define S4FONT_8 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 8																						
#define S5FONT_8 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 8																						

 /*     9     9          */																						
#define S1FONT_9 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font 9																						
#define S2FONT_9 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font 9																						
#define S3FONT_9 S3D4|S3D3|S3D2|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font 9																						
#define S4FONT_9 S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 9																						
#define S5FONT_9 S5G3|S5G4|0x00                                                                        // IC 5 Set Font 9																						

 /*     COLON     :          */																						
#define S1FONT_COLON 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font COLON																						
#define S2FONT_COLON 0x00|0x00|0x00|S2C2|S2C3|0x00|0x00|0x00                    // IC 2 Set Font COLON																						
#define S3FONT_COLON 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font COLON																						
#define S4FONT_COLON 0x00|0x00|S4F2|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font COLON																						
#define S5FONT_COLON 0x00|0x00|0x00                                                                        // IC 5 Set Font COLON																						

 /*     SEMI     ;          */																						
#define S1FONT_SEMI 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font SEMI																						
#define S2FONT_SEMI 0x00|0x00|0x00|0x00|S2C3|S2C4|0x00|0x00                    // IC 2 Set Font SEMI																						
#define S3FONT_SEMI 0x00|0x00|0x00|0x00|0x00|0x00|S3E3|S3E4                    // IC 3 Set Font SEMI																						
#define S4FONT_SEMI 0x00|0x00|0x00|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font SEMI																						
#define S5FONT_SEMI S5G3|0x00|0x00                                                                        // IC 5 Set Font SEMI																						

 /*     CHEV_L     <          */																						
#define S1FONT_CHEV_L 0x00|0x00|0x00|S1A2|0x00|0x00|0x00|S1B3                    // IC 1 Set Font CHEV_L																						
#define S2FONT_CHEV_L 0x00|0x00|0x00|S2C2|0x00|0x00|0x00|0x00                    // IC 2 Set Font CHEV_L																						
#define S3FONT_CHEV_L 0x00|0x00|0x00|S3D1|0x00|S3E2|0x00|0x00                    // IC 3 Set Font CHEV_L																						
#define S4FONT_CHEV_L 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font CHEV_L																						
#define S5FONT_CHEV_L 0x00|S5G4|0x00                                                                        // IC 5 Set Font CHEV_L																						

 /*     EQUALS     =          */																						
#define S1FONT_EQUALS 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font EQUALS																						
#define S2FONT_EQUALS 0x00|0x00|S2C1|S2C2|S2C3|S2C4|S2C5|0x00                    // IC 2 Set Font EQUALS																						
#define S3FONT_EQUALS 0x00|0x00|0x00|0x00|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font EQUALS																						
#define S4FONT_EQUALS S4E5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font EQUALS																						
#define S5FONT_EQUALS 0x00|0x00|0x00                                                                        // IC 5 Set Font EQUALS																						

 /*     CHEV_R     >          */																						
#define S1FONT_CHEV_R S1A5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font CHEV_R																						
#define S2FONT_CHEV_R S2B2|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font CHEV_R																						
#define S3FONT_CHEV_R S3D4|0x00|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font CHEV_R																						
#define S4FONT_CHEV_R 0x00|0x00|S4F2|0x00|0x00|0x00|S4G1|0x00                    // IC 4 Set Font CHEV_R																						
#define S5FONT_CHEV_R 0x00|0x00|0x00                                                                        // IC 5 Set Font CHEV_R																						

#define S1FONT_QUES 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font QUES																						
#define S2FONT_QUES 0x00|S2B1|0x00|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font QUES																						
#define S3FONT_QUES S3D4|0x00|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font QUES																						
#define S4FONT_QUES 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font QUES																						
#define S5FONT_QUES S5G3|0x00|0x00                                                                        // IC 5 Set Font QUES																						


 /*     AT     @          */																						
#define S1FONT_AT 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font AT																						
#define S2FONT_AT 0x00|S2B1|0x00|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font AT																						
#define S3FONT_AT 0x00|S3D3|S3D2|0x00|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font AT																						
#define S4FONT_AT S4E5|S4F1|0x00|S4F3|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_AT S5G3|S5G4|0x00                                                                               // IC 5 Set Font AT																						

 /*     A     A          */																						
#define S1FONT_A 0x00|0x00|S1A3|0x00|0x00|0x00|S1B4|0x00                    // IC 1 Set Font A																						
#define S2FONT_A S2B2|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font A																						
#define S3FONT_A 0x00|0x00|0x00|S3D1|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font A																						
#define S4FONT_A S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_A 0x00|0x00|S5G5                                                                               // IC 5 Set Font A																						

 /*     B     B          */																						
#define S1FONT_B S1A5|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font B																						
#define S2FONT_B 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font B																						
#define S3FONT_B S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font B																						
#define S4FONT_B S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_B S5G3|S5G4|0x00                                                                               // IC 5 Set Font B																						

 /*     C     C          */																						
#define S1FONT_C 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font C																						
#define S2FONT_C 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font C																						
#define S3FONT_C 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font C																						
#define S4FONT_C 0x00|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_C S5G3|S5G4|0x00                                                                               // IC 5 Set Font C																						

 /*     D     D          */																						
#define S1FONT_D S1A5|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font D																						
#define S2FONT_D 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font D																						
#define S3FONT_D 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font D																						
#define S4FONT_D S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_D S5G3|S5G4|0x00                                                                               // IC 5 Set Font D																						

 /*     E     E          */																						
#define S1FONT_E S1A5|S1A4|S1A3|S1A2|S1A1|0x00|0x00|0x00                    // IC 1 Set Font E																						
#define S2FONT_E 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font E																						
#define S3FONT_E S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font E																						
#define S4FONT_E 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_E S5G3|S5G4|S5G5                                                                               // IC 5 Set Font E																						

 /*     F     F          */																						
#define S1FONT_F S1A5|S1A4|S1A3|S1A2|S1A1|0x00|0x00|0x00                    // IC 1 Set Font F																						
#define S2FONT_F 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font F																						
#define S3FONT_F S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font F																						
#define S4FONT_F 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_F 0x00|0x00|0x00                                                                               // IC 5 Set Font F																						

 /*     G     G          */																						
#define S1FONT_G 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font G																						
#define S2FONT_G 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|S2D5                    // IC 2 Set Font G																						
#define S3FONT_G S3D4|S3D3|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font G																						
#define S4FONT_G S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_G S5G3|S5G4|0x00                                                                               // IC 5 Set Font G																						

 /*     H     H          */																						
#define S1FONT_H S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font H																						
#define S2FONT_H 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font H																						
#define S3FONT_H S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font H																						
#define S4FONT_H S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_H 0x00|0x00|S5G5                                                                               // IC 5 Set Font H																						

 /*     I     I          */																						
#define S1FONT_I 0x00|S1A4|S1A3|S1A2|0x00|0x00|0x00|S1B3                    // IC 1 Set Font I																						
#define S2FONT_I 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font I																						
#define S3FONT_I 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font I																						
#define S4FONT_I 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_I S5G3|S5G4|0x00                                                                               // IC 5 Set Font I																						

 /*     J     J          */																						
#define S1FONT_J 0x00|0x00|S1A3|S1A2|S1A1|0x00|S1B4|0x00                    // IC 1 Set Font J																						
#define S2FONT_J 0x00|0x00|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font J																						
#define S3FONT_J S3D4|0x00|0x00|0x00|0x00|0x00|0x00|S3E4                    // IC 3 Set Font J																						
#define S4FONT_J 0x00|S4F1|0x00|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_J S5G3|0x00|0x00                                                                               // IC 5 Set Font J																						

 /*     K     K          */																						
#define S1FONT_K S1A5|0x00|0x00|0x00|S1A1|0x00|S1B4|0x00                    // IC 1 Set Font K																						
#define S2FONT_K 0x00|S2B1|S2C1|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font K																						
#define S3FONT_K 0x00|0x00|S3D2|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font K																						
#define S4FONT_K 0x00|S4F1|0x00|0x00|S4F4|0x00|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_K 0x00|0x00|S5G5                                                                               // IC 5 Set Font K																						

 /*     L     L          */																						
#define S1FONT_L S1A5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font L																						
#define S2FONT_L 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font L																						
#define S3FONT_L 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font L																						
#define S4FONT_L 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_L S5G3|S5G4|S5G5                                                                               // IC 5 Set Font L																						

 /*     M     M          */																						
#define S1FONT_M S1A5|0x00|0x00|0x00|S1A1|S1B5|S1B4|0x00                    // IC 1 Set Font M																						
#define S2FONT_M S2B2|S2B1|S2C1|0x00|S2C3|0x00|S2C5|S2D5                    // IC 2 Set Font M																						
#define S3FONT_M 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font M																						
#define S4FONT_M S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_M 0x00|0x00|S5G5                                                                               // IC 5 Set Font M																						

 /*     N     N          */																						
#define S1FONT_N S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font N																						
#define S2FONT_N S2B2|S2B1|S2C1|0x00|S2C3|0x00|S2C5|S2D5                    // IC 2 Set Font N																						
#define S3FONT_N 0x00|S3D3|0x00|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font N																						
#define S4FONT_N S4E5|S4F1|0x00|0x00|S4F4|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_N 0x00|0x00|S5G5                                                                               // IC 5 Set Font N																						

 /*     O     O          */																						
#define S1FONT_O 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font O																						
#define S2FONT_O 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font O																						
#define S3FONT_O 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font O																						
#define S4FONT_O S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_O S5G3|S5G4|0x00                                                                               // IC 5 Set Font O																						

 /*     P     P          */																						
#define S1FONT_P S1A5|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font P																						
#define S2FONT_P 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font P																						
#define S3FONT_P S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font P																						
#define S4FONT_P 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_P 0x00|0x00|0x00                                                                               // IC 5 Set Font P																						

 /*     Q     Q          */																						
#define S1FONT_Q 0x00|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font Q																						
#define S2FONT_Q 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font Q																						
#define S3FONT_Q 0x00|0x00|0x00|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font Q																						
#define S4FONT_Q S4E5|S4F1|0x00|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_Q S5G3|0x00|S5G5                                                                               // IC 5 Set Font Q																						

 /*     R     R          */																						
#define S1FONT_R S1A5|S1A4|S1A3|S1A2|0x00|S1B5|0x00|0x00                    // IC 1 Set Font R																						
#define S2FONT_R 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font R																						
#define S3FONT_R S3D4|S3D3|S3D2|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font R																						
#define S4FONT_R 0x00|S4F1|0x00|0x00|S4F4|0x00|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_R 0x00|0x00|S5G5                                                                               // IC 5 Set Font R																						

 /*     S     S          */																						
#define S1FONT_S 0x00|S1A4|S1A3|S1A2|S1A1|0x00|0x00|0x00                    // IC 1 Set Font S																						
#define S2FONT_S 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font S																						
#define S3FONT_S S3D4|S3D3|S3D2|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font S																						
#define S4FONT_S S4E5|0x00|0x00|0x00|0x00|S4F5|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_S S5G3|S5G4|0x00                                                                               // IC 5 Set Font S																						

 /*     T     T          */																						
#define S1FONT_T S1A5|S1A4|S1A3|S1A2|S1A1|0x00|0x00|S1B3                    // IC 1 Set Font T																						
#define S2FONT_T 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font T																						
#define S3FONT_T 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font T																						
#define S4FONT_T 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_T S5G3|0x00|0x00                                                                               // IC 5 Set Font T																						

 /*     U     U          */																						
#define S1FONT_U S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font U																						
#define S2FONT_U 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font U																						
#define S3FONT_U 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font U																						
#define S4FONT_U S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font 																						
#define S5FONT_U S5G3|S5G4|0x00                                                                               // IC 5 Set Font U																						

 /*     V     V          */																						
#define S1FONT_V S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font V																						
#define S2FONT_V 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font V																						
#define S3FONT_V 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font V																						
#define S4FONT_V S4E5|0x00|S4F2|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_V S5G3|0x00|0x00                                                                               // IC 5 Set Font V																						

 /*     W     W          */																						
#define S1FONT_W S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font W																						
#define S2FONT_W 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font W																						
#define S3FONT_W 0x00|0x00|0x00|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font W																						
#define S4FONT_W S4E5|S4F1|S4F2|0x00|S4F4|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_W 0x00|0x00|S5G5                                                                               // IC 5 Set Font W																						

 /*     X     X          */																						
#define S1FONT_X S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font X																						
#define S2FONT_X 0x00|S2B1|0x00|S2C2|0x00|S2C4|0x00|0x00                    // IC 2 Set Font X																						
#define S3FONT_X 0x00|S3D3|0x00|0x00|0x00|S3E2|0x00|S3E4                    // IC 3 Set Font X																						
#define S4FONT_X 0x00|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font 																						
#define S5FONT_X 0x00|0x00|S5G5                                                                               // IC 5 Set Font X																						

 /*     Y     Y          */																						
#define S1FONT_Y S1A5|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font Y																						
#define S2FONT_Y 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font Y																						
#define S3FONT_Y S3D4|0x00|S3D2|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font Y																						
#define S4FONT_Y 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_Y S5G3|0x00|0x00                                                                               // IC 5 Set Font Y																						

 /*     Z     Z          */																						
#define S1FONT_Z S1A5|S1A4|S1A3|S1A2|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font Z																						
#define S2FONT_Z 0x00|0x00|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font Z																						
#define S3FONT_Z 0x00|S3D3|0x00|0x00|0x00|S3E2|0x00|0x00                    // IC 3 Set Font Z																						
#define S4FONT_Z 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_Z S5G3|S5G4|S5G5                                                                               // IC 5 Set Font Z																						

 /*     BRACK_O     [          */																						
#define S1FONT_BRACK_O S1A5|S1A4|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font BRACK_O																						
#define S2FONT_BRACK_O 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font BRACK_O																						
#define S3FONT_BRACK_O 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font BRACK_O																						
#define S4FONT_BRACK_O 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_BRACK_O 0x00|0x00|0x00                                                                               // IC 5 Set Font BRACK_O																						

 /*     BACKSLASH     \          */																						
#define S1FONT_BACKSLASH 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font BACKSLASH																						
#define S2FONT_BACKSLASH 0x00|S2B1|0x00|S2C2|0x00|0x00|0x00|0x00                    // IC 2 Set Font BACKSLASH																						
#define S3FONT_BACKSLASH 0x00|S3D3|0x00|0x00|0x00|0x00|0x00|S3E4                    // IC 3 Set Font BACKSLASH																						
#define S4FONT_BACKSLASH 0x00|0x00|0x00|0x00|0x00|S4F5|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_BACKSLASH 0x00|0x00|0x00                                                                               // IC 5 Set Font BACKSLASH																						

 /*     BRACK_C     ]          */																						
#define S1FONT_BRACK_C 0x00|0x00|0x00|S1A2|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font BRACK_C																						
#define S2FONT_BRACK_C 0x00|0x00|0x00|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font BRACK_C																						
#define S3FONT_BRACK_C 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font BRACK_C																						
#define S4FONT_BRACK_C S4E5|0x00|0x00|0x00|0x00|S4F5|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_BRACK_C 0x00|S5G4|S5G5                                                                               // IC 5 Set Font BRACK_C																						

 /*     CARET     ^          */																						
#define S1FONT_CARET 0x00|0x00|S1A3|0x00|0x00|0x00|S1B4|0x00                    // IC 1 Set Font CARET																						
#define S2FONT_CARET S2B2|0x00|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font CARET																						
#define S3FONT_CARET 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font CARET																						
#define S4FONT_CARET 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font 																						
#define S5FONT_CARET 0x00|0x00|0x00                                                                               // IC 5 Set Font CARET																						

 /*     UNDER     _          */																						
#define S1FONT_UNDER 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font UNDER																						
#define S2FONT_UNDER 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font UNDER																						
#define S3FONT_UNDER 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font UNDER																						
#define S4FONT_UNDER 0x00|0x00|0x00|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font 																						
#define S5FONT_UNDER S5G3|S5G4|S5G5                                                                               // IC 5 Set Font UNDER																						


 /*     QUOTE_3     ′          */																						
#define S1FONT_QUOTE_3 0x00|S1A4|S1A3|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font QUOTE_3																						
#define S2FONT_QUOTE_3 S2B2|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font QUOTE_3																						
#define S3FONT_QUOTE_3 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font QUOTE_3																						
#define S4FONT_QUOTE_3 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font QUOTE_3																						
#define S5FONT_QUOTE_3 0x00|0x00|0x00                                                                               // IC 5 Set Font QUOTE_3																						

 /*     a     a          */																						
#define S1FONT_a 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font a																						
#define S2FONT_a 0x00|0x00|0x00|S2C2|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font a																						
#define S3FONT_a 0x00|0x00|0x00|0x00|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font a																						
#define S4FONT_a S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font a																						
#define S5FONT_a S5G3|S5G4|S5G5                                                                               // IC 5 Set Font a																						

 /*     b     b          */																						
#define S1FONT_b S1A5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font b																						
#define S2FONT_b 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font b																						
#define S3FONT_b S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font b																						
#define S4FONT_b S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|S4G2                    // IC 4 Set Font b																						
#define S5FONT_b S5G3|S5G4|0x00                                                                               // IC 5 Set Font b																						

 /*     c     c          */																						
#define S1FONT_c 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font c																						
#define S2FONT_c 0x00|0x00|0x00|S2C2|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font c																						
#define S3FONT_c 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font c																						
#define S4FONT_c 0x00|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font c																						
#define S5FONT_c S5G3|S5G4|0x00                                                                               // IC 5 Set Font c																						

 /*     d     d          */																						
#define S1FONT_d 0x00|0x00|0x00|0x00|S1A1|S1B5|0x00|0x00                    // IC 1 Set Font d																						
#define S2FONT_d 0x00|0x00|0x00|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font d																						
#define S3FONT_d S3D4|S3D3|S3D2|0x00|S3E1|0x00|0x00|0x00                    // IC 3 Set Font d																						
#define S4FONT_d S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font d																						
#define S5FONT_d S5G3|S5G4|S5G5                                                                               // IC 5 Set Font d																						

 /*     e     e          */																						
#define S1FONT_e 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font e																						
#define S2FONT_e 0x00|0x00|0x00|S2C2|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font e																						
#define S3FONT_e 0x00|0x00|0x00|S3D1|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font e																						
#define S4FONT_e S4E5|S4F1|0x00|0x00|0x00|0x00|0x00|S4G2                    // IC 4 Set Font e																						
#define S5FONT_e S5G3|S5G4|0x00                                                                               // IC 5 Set Font e																						

 /*     f     f          */																						
#define S1FONT_f 0x00|0x00|0x00|0x00|0x00|0x00|S1B4|S1B3                    // IC 1 Set Font f																						
#define S2FONT_f 0x00|0x00|0x00|S2C2|0x00|0x00|S2C5|0x00                    // IC 2 Set Font f																						
#define S3FONT_f 0x00|0x00|S3D2|0x00|S3E1|S3E2|S3E3|0x00                    // IC 3 Set Font f																						
#define S4FONT_f 0x00|0x00|S4F2|0x00|0x00|0x00|0x00|S4G2                    // IC 4 Set Font f																						
#define S5FONT_f 0x00|0x00|0x00                                                                               // IC 5 Set Font f																						

 /*     g     g          */																						
#define S1FONT_g 0x00|0x00|0x00|0x00|0x00|S1B5|S1B4|S1B3                    // IC 1 Set Font g																						
#define S2FONT_g S2B2|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font g																						
#define S3FONT_g 0x00|0x00|0x00|S3D1|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font g																						
#define S4FONT_g S4E5|0x00|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font g																						
#define S5FONT_g S5G3|S5G4|0x00                                                                               // IC 5 Set Font g																						

 /*     h     h          */																						
#define S1FONT_h S1A5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font h																						
#define S2FONT_h 0x00|S2B1|S2C1|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font h																						
#define S3FONT_h S3D4|S3D3|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font h																						
#define S4FONT_h S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font h																						
#define S5FONT_h 0x00|0x00|S5G5                                                                               // IC 5 Set Font h																						

 /*     i     i          */																						
#define S1FONT_i 0x00|0x00|0x00|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font i																						
#define S2FONT_i 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 2 Set Font i																						
#define S3FONT_i 0x00|S3D3|S3D2|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font i																						
#define S4FONT_i 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|S4G2                    // IC 4 Set Font i																						
#define S5FONT_i S5G3|S5G4|0x00                                                                               // IC 5 Set Font i																						

 /*     j     j          */																						
#define S1FONT_j 0x00|0x00|0x00|S1A2|0x00|0x00|0x00|0x00                    // IC 1 Set Font j																						
#define S2FONT_j 0x00|0x00|0x00|0x00|S2C3|S2C4|0x00|0x00                    // IC 2 Set Font j																						
#define S3FONT_j S3D4|0x00|0x00|0x00|0x00|0x00|0x00|S3E4                    // IC 3 Set Font j																						
#define S4FONT_j 0x00|S4F1|0x00|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font j																						
#define S5FONT_j S5G3|0x00|0x00                                                                               // IC 5 Set Font j																						

 /*     k     k          */																						
#define S1FONT_k S1A5|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font k																						
#define S2FONT_k 0x00|S2B1|S2C1|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font k																						
#define S3FONT_k 0x00|S3D3|0x00|S3D1|S3E1|S3E2|S3E3|0x00                    // IC 3 Set Font k																						
#define S4FONT_k 0x00|S4F1|0x00|0x00|S4F4|0x00|S4G1|0x00                    // IC 4 Set Font k																						
#define S5FONT_k 0x00|0x00|S5G5                                                                               // IC 5 Set Font k																						

 /*     l     l          */																						
#define S1FONT_l 0x00|S1A4|S1A3|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font l																						
#define S2FONT_l 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font l																						
#define S3FONT_l 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font l																						
#define S4FONT_l 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|S4G2                    // IC 4 Set Font l																						
#define S5FONT_l S5G3|S5G4|0x00                                                                               // IC 5 Set Font l																						

 /*     m     m          */																						
#define S1FONT_m 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font m																						
#define S2FONT_m 0x00|0x00|S2C1|S2C2|0x00|S2C4|0x00|S2D5                    // IC 2 Set Font m																						
#define S3FONT_m 0x00|S3D3|0x00|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font m																						
#define S4FONT_m S4E5|S4F1|0x00|S4F3|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font m																						
#define S5FONT_m 0x00|0x00|S5G5                                                                               // IC 5 Set Font m																						

 /*     n     n          */																						
#define S1FONT_n 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font n																						
#define S2FONT_n 0x00|0x00|S2C1|0x00|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font n																						
#define S3FONT_n 0x00|0x00|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font n																						
#define S4FONT_n S4E5|S4F1|0x00|0x00|0x00|S4F5|S4G1|0x00                    // IC 4 Set Font n																						
#define S5FONT_n 0x00|0x00|S5G5                                                                               // IC 5 Set Font n																						

 /*     o     o          */																						
#define S1FONT_o 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font o																						
#define S2FONT_o 0x00|0x00|0x00|S2C2|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font o																						
#define S3FONT_o 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font o																						
#define S4FONT_o S4E5|S4F1|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font o																						
#define S5FONT_o S5G3|S5G4|0x00                                                                               // IC 5 Set Font o																						

 /*     p     p          */																						
#define S1FONT_p 0x00|0x00|0x00|0x00|0x00|0x00|S1B4|S1B3                    // IC 1 Set Font p																						
#define S2FONT_p S2B2|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font p																						
#define S3FONT_p 0x00|0x00|0x00|S3D1|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font p																						
#define S4FONT_p 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|0x00                    // IC 4 Set Font p																						
#define S5FONT_p 0x00|0x00|0x00                                                                               // IC 5 Set Font p																						

 /*     q     q          */																						
#define S1FONT_q 0x00|0x00|0x00|0x00|0x00|S1B5|S1B4|S1B3                    // IC 1 Set Font q																						
#define S2FONT_q S2B2|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font q																						
#define S3FONT_q 0x00|0x00|0x00|S3D1|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font q																						
#define S4FONT_q S4E5|0x00|0x00|0x00|0x00|S4F5|0x00|0x00                    // IC 4 Set Font q																						
#define S5FONT_q 0x00|0x00|S5G5                                                                               // IC 5 Set Font q																						

 /*     r     r          */																						
#define S1FONT_r 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font r																						
#define S2FONT_r 0x00|0x00|S2C1|0x00|S2C3|S2C4|0x00|S2D5                    // IC 2 Set Font r																						
#define S3FONT_r 0x00|0x00|S3D2|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font r																						
#define S4FONT_r 0x00|S4F1|0x00|0x00|0x00|0x00|S4G1|0x00                    // IC 4 Set Font r																						
#define S5FONT_r 0x00|0x00|0x00                                                                               // IC 5 Set Font r																						

 /*     s     s          */																						
#define S1FONT_s 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font s																						
#define S2FONT_s 0x00|0x00|0x00|S2C2|S2C3|S2C4|S2C5|0x00                    // IC 2 Set Font s																						
#define S3FONT_s 0x00|0x00|0x00|S3D1|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font s																						
#define S4FONT_s 0x00|0x00|0x00|0x00|0x00|S4F5|S4G1|S4G2                    // IC 4 Set Font s																						
#define S5FONT_s S5G3|S5G4|0x00                                                                               // IC 5 Set Font s																						

 /*     t     t          */																						
#define S1FONT_t 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font t																						
#define S2FONT_t S2B2|0x00|0x00|S2C2|0x00|0x00|0x00|0x00                    // IC 2 Set Font t																						
#define S3FONT_t 0x00|S3D3|S3D2|S3D1|0x00|S3E2|0x00|0x00                    // IC 3 Set Font t																						
#define S4FONT_t 0x00|0x00|S4F2|0x00|0x00|S4F5|0x00|0x00                    // IC 4 Set Font t																						
#define S5FONT_t S5G3|S5G4|0x00                                                                               // IC 5 Set Font t																						

 /*     u     u          */																						
#define S1FONT_u 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font u																						
#define S2FONT_u 0x00|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font u																						
#define S3FONT_u 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font u																						
#define S4FONT_u S4E5|S4F1|0x00|0x00|S4F4|S4F5|0x00|S4G2                    // IC 4 Set Font u																						
#define S5FONT_u S5G3|0x00|S5G5                                                                               // IC 5 Set Font u																						

 /*     v     v          */																						
#define S1FONT_v 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font v																						
#define S2FONT_v 0x00|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font v																						
#define S3FONT_v 0x00|0x00|0x00|S3D1|S3E1|0x00|0x00|0x00                    // IC 3 Set Font v																						
#define S4FONT_v S4E5|0x00|S4F2|0x00|S4F4|0x00|0x00|0x00                    // IC 4 Set Font v																						
#define S5FONT_v S5G3|0x00|0x00                                                                               // IC 5 Set Font v																						

 /*     w     w          */																						
#define S1FONT_w 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font w																						
#define S2FONT_w 0x00|0x00|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font w																						
#define S3FONT_w 0x00|0x00|0x00|S3D1|S3E1|0x00|S3E3|0x00                    // IC 3 Set Font w																						
#define S4FONT_w S4E5|S4F1|0x00|S4F3|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font w																						
#define S5FONT_w 0x00|S5G4|0x00                                                                               // IC 5 Set Font w																						

 /*     x     x          */																						
#define S1FONT_x 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font x																						
#define S2FONT_x 0x00|0x00|S2C1|0x00|0x00|0x00|S2C5|0x00                    // IC 2 Set Font x																						
#define S3FONT_x S3D4|0x00|S3D2|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font x																						
#define S4FONT_x 0x00|0x00|S4F2|0x00|S4F4|0x00|S4G1|0x00                    // IC 4 Set Font x																						
#define S5FONT_x 0x00|0x00|S5G5                                                                               // IC 5 Set Font x																						

 /*     y     y          */																						
#define S1FONT_y 0x00|0x00|0x00|0x00|0x00|S1B5|0x00|0x00                    // IC 1 Set Font y																						
#define S2FONT_y 0x00|S2B1|S2C1|0x00|0x00|0x00|S2C5|S2D5                    // IC 2 Set Font y																						
#define S3FONT_y 0x00|0x00|0x00|S3D1|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font y																						
#define S4FONT_y S4E5|0x00|0x00|0x00|0x00|S4F5|0x00|S4G2                    // IC 4 Set Font y																						
#define S5FONT_y S5G3|S5G4|0x00                                                                               // IC 5 Set Font y																						

 /*     z     z          */																						
#define S1FONT_z 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font z																						
#define S2FONT_z 0x00|0x00|S2C1|S2C2|S2C3|S2C4|S2C5|0x00                    // IC 2 Set Font z																						
#define S3FONT_z S3D4|0x00|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font z																						
#define S4FONT_z 0x00|0x00|S4F2|0x00|0x00|0x00|S4G1|S4G2                    // IC 4 Set Font z																						
#define S5FONT_z S5G3|S5G4|S5G5                                                                               // IC 5 Set Font z																						

 /*     BRACE_O     {          */																						
#define S1FONT_BRACE_O 0x00|0x00|S1A3|S1A2|0x00|0x00|0x00|0x00                    // IC 1 Set Font BRACE_O																						
#define S2FONT_BRACE_O S2B2|0x00|0x00|S2C2|0x00|0x00|0x00|0x00                    // IC 2 Set Font BRACE_O																						
#define S3FONT_BRACE_O 0x00|0x00|0x00|S3D1|0x00|S3E2|0x00|0x00                    // IC 3 Set Font BRACE_O																						
#define S4FONT_BRACE_O 0x00|0x00|S4F2|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font BRACE_O																						
#define S5FONT_BRACE_O S5G3|S5G4|0x00                                                                               // IC 5 Set Font BRACE_O																						

 /*     PIPE     |          */																						
#define S1FONT_PIPE 0x00|0x00|S1A3|0x00|0x00|0x00|0x00|S1B3                    // IC 1 Set Font PIPE																						
#define S2FONT_PIPE 0x00|0x00|0x00|0x00|S2C3|0x00|0x00|0x00                    // IC 2 Set Font PIPE																						
#define S3FONT_PIPE 0x00|S3D3|0x00|0x00|0x00|0x00|S3E3|0x00                    // IC 3 Set Font PIPE																						
#define S4FONT_PIPE 0x00|0x00|0x00|S4F3|0x00|0x00|0x00|0x00                    // IC 4 Set Font PIPE																						
#define S5FONT_PIPE S5G3|0x00|0x00                                                                               // IC 5 Set Font PIPE																						

 /*     BRACE_C     }          */																						
#define S1FONT_BRACE_C 0x00|S1A4|S1A3|0x00|0x00|0x00|S1B4|0x00                    // IC 1 Set Font BRACE_C																						
#define S2FONT_BRACE_C 0x00|0x00|0x00|0x00|0x00|S2C4|0x00|S2D5                    // IC 2 Set Font BRACE_C																						
#define S3FONT_BRACE_C 0x00|0x00|0x00|0x00|0x00|0x00|0x00|S3E4                    // IC 3 Set Font BRACE_C																						
#define S4FONT_BRACE_C 0x00|0x00|0x00|0x00|S4F4|0x00|0x00|S4G2                    // IC 4 Set Font BRACE_C																						
#define S5FONT_BRACE_C S5G3|0x00|0x00                                                                               // IC 5 Set Font BRACE_C																						

 /*     TILDE     ~          */																						
#define S1FONT_TILDE 0x00|S1A4|0x00|0x00|0x00|S1B5|0x00|S1B3                    // IC 1 Set Font TILDE																						
#define S2FONT_TILDE 0x00|S2B1|0x00|0x00|0x00|S2C4|0x00|0x00                    // IC 2 Set Font TILDE																						
#define S3FONT_TILDE 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 3 Set Font TILDE																						
#define S4FONT_TILDE 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font TILDE																						
#define S5FONT_TILDE 0x00|0x00|0x00                                                                               // IC 5 Set Font TILDE																						

 /*     HOLD               */																						
#define S1FONT_HOLD S1A5|S1A4|S1A3|S1A2|S1A1|S1B5|S1B4|S1B3                    // IC 1 Set Font HOLD																						
#define S2FONT_HOLD S2B2|S2B1|S2C1|S2C2|S2C3|S2C4|S2C5|S2D5                    // IC 2 Set Font HOLD																						
#define S3FONT_HOLD S3D4|S3D3|S3D2|S3D1|S3E1|S3E2|S3E3|S3E4                    // IC 3 Set Font HOLD																						
#define S4FONT_HOLD S4E5|S4F1|S4F2|S4F3|S4F4|S4F5|S4G1|S4G2                    // IC 4 Set Font HOLD																						
#define S5FONT_HOLD S5G3|S5G4|S5G5                                                                               // IC 5 Set Font HOLD																						

#define S1FONT_CENTER 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 1 Set Font CENTER																						
#define S2FONT_CENTER 0x00|0x00|0x00|S2C2|S2C3|S2C4|0x00|0x00                    // IC 2 Set Font CENTER																						
#define S3FONT_CENTER S3D4|0x00|S3D2|0x00|0x00|S3E2|S3E3|S3E4                    // IC 3 Set Font CENTER																						
#define S4FONT_CENTER 0x00|0x00|0x00|0x00|0x00|0x00|0x00|0x00                    // IC 4 Set Font CENTER																						
#define S5FONT_CENTER 0x00|0x00|0x00                                                                        // IC 5 Set Font CENTER																						

#define FONT_LENGHT 0x81-0x20
extern char MAP_FONT[FONT_LENGHT][5];  // 0x00   -   0x7F
