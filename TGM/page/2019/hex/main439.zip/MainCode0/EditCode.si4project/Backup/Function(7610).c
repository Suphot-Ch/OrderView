#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"

u16 Time_On(u8 add){
	switch(add){
	case 0: return EEP_TIMEON_00;  break;
	case 1: return EEP_TIMEON_01;  break;
	case 2: return EEP_TIMEON_02;  break;
	case 3: return EEP_TIMEON_03;  break;
	case 4: return EEP_TIMEON_04;  break;
	case 5: return EEP_TIMEON_05;  break;
	case 6: return EEP_TIMEON_06;  break;
	case 7: return EEP_TIMEON_07;  break;
	case 8: return EEP_TIMEON_08;  break;
	case 9: return EEP_TIMEON_09;  break;
	
	case 10: return EEP_TIMEON_10;  break;
	case 11: return EEP_TIMEON_11;  break;
	case 12: return EEP_TIMEON_12;  break;
	case 13: return EEP_TIMEON_13;  break;
	case 14: return EEP_TIMEON_14;  break;
	case 15: return EEP_TIMEON_15;  break;
	case 16: return EEP_TIMEON_16;  break;
	case 17: return EEP_TIMEON_17;  break;
	case 18: return EEP_TIMEON_18;  break;
	case 19: return EEP_TIMEON_19;  break;
	
	case 20: return EEP_TIMEON_20;  break;
	case 21: return EEP_TIMEON_21;  break;
	case 22: return EEP_TIMEON_22;  break;
	case 23: return EEP_TIMEON_23;  break;
	case 24: return EEP_TIMEON_24;  break;
	case 25: return EEP_TIMEON_25;  break;
	case 26: return EEP_TIMEON_26;  break;
	case 27: return EEP_TIMEON_27;  break;
	case 28: return EEP_TIMEON_28;  break;
	case 29: return EEP_TIMEON_29;  break;
	
	case 30: return EEP_TIMEON_30;  break;
	case 31: return EEP_TIMEON_31;  break;
	
		}
	/*
u16 Break_ON_[]={
	EEP_TIMEON_00, EEP_TIMEON_01,	EEP_TIMEON_02, EEP_TIMEON_03, 
	EEP_TIMEON_04, EEP_TIMEON_05,	EEP_TIMEON_06, EEP_TIMEON_07, 
	EEP_TIMEON_08, EEP_TIMEON_09,	EEP_TIMEON_10, EEP_TIMEON_11, 
	EEP_TIMEON_12, EEP_TIMEON_13, 	EEP_TIMEON_14, EEP_TIMEON_15, 
	EEP_TIMEON_16, EEP_TIMEON_17, 	EEP_TIMEON_18, EEP_TIMEON_19,
	EEP_TIMEON_20, EEP_TIMEON_21, 	EEP_TIMEON_22, EEP_TIMEON_23, 
	EEP_TIMEON_24, EEP_TIMEON_25, 	EEP_TIMEON_26, EEP_TIMEON_27, 
	EEP_TIMEON_28, EEP_TIMEON_29, 	EEP_TIMEON_30, EEP_TIMEON_31, 
};
u16 Break_OFF_[]={
	EEP_TIMEOFF_00, EEP_TIMEOFF_01,	EEP_TIMEOFF_02, EEP_TIMEOFF_03,
	EEP_TIMEOFF_04, EEP_TIMEOFF_05,	EEP_TIMEOFF_06, EEP_TIMEOFF_07,
	EEP_TIMEOFF_08, EEP_TIMEOFF_09,	EEP_TIMEOFF_10, EEP_TIMEOFF_11,
	EEP_TIMEOFF_12, EEP_TIMEOFF_13,	EEP_TIMEOFF_14, EEP_TIMEOFF_15,
	EEP_TIMEOFF_16, EEP_TIMEOFF_17,	EEP_TIMEOFF_18, EEP_TIMEOFF_19, 
	EEP_TIMEOFF_20, EEP_TIMEOFF_21,	EEP_TIMEOFF_22, EEP_TIMEOFF_23,
	EEP_TIMEOFF_24, EEP_TIMEOFF_25,	EEP_TIMEOFF_26, EEP_TIMEOFF_27,
	EEP_TIMEOFF_28, EEP_TIMEOFF_29,	EEP_TIMEOFF_30, EEP_TIMEOFF_31, 
};*/
}
u16 Time_Off(u8 add){
	switch(add){
	case 0: return EEP_TIMEOFF_00;  break;
	case 1: return EEP_TIMEOFF_01;  break;
	case 2: return EEP_TIMEOFF_02;  break;
	case 3: return EEP_TIMEOFF_03;  break;
	case 4: return EEP_TIMEOFF_04;  break;
	case 5: return EEP_TIMEOFF_05;  break;
	case 6: return EEP_TIMEOFF_06;  break;
	case 7: return EEP_TIMEOFF_07;  break;
	case 8: return EEP_TIMEOFF_08;  break;
	case 9: return EEP_TIMEOFF_09;  break;
	
	case 10: return EEP_TIMEOFF_10;  break;
	case 11: return EEP_TIMEOFF_11;  break;
	case 12: return EEP_TIMEOFF_12;  break;
	case 13: return EEP_TIMEOFF_13;  break;
	case 14: return EEP_TIMEOFF_14;  break;
	case 15: return EEP_TIMEOFF_15;  break;
	case 16: return EEP_TIMEOFF_16;  break;
	case 17: return EEP_TIMEOFF_17;  break;
	case 18: return EEP_TIMEOFF_18;  break;
	case 19: return EEP_TIMEOFF_19;  break;
	
	case 20: return EEP_TIMEOFF_20;  break;
	case 21: return EEP_TIMEOFF_21;  break;
	case 22: return EEP_TIMEOFF_22;  break;
	case 23: return EEP_TIMEOFF_23;  break;
	case 24: return EEP_TIMEOFF_24;  break;
	case 25: return EEP_TIMEOFF_25;  break;
	case 26: return EEP_TIMEOFF_26;  break;
	case 27: return EEP_TIMEOFF_27;  break;
	case 28: return EEP_TIMEOFF_28;  break;
	case 29: return EEP_TIMEOFF_29;  break;
	
	case 30: return EEP_TIMEOFF_30;  break;
	case 31: return EEP_TIMEOFF_31;  break;
		}
}
u32 DIVReg[]={1,10,100,1000,10000,100000,1000000};
void shift_edit_buffer(void){
	s8 i;
	for(i=0;i<EDIT_LENGTH;i++){
		EditBuffer[i]=EditBuffer[i+1];
	}
}
void shift_edit_buffer_4digit(void){
	s8 i;
	
	for(i=0;i<4;i++){
		EditBuffer[i]=EditBuffer[i+1];
	}
}
void shift_edit_buffer_5digit(void){
	s8 i;
	
	for(i=0;i<5;i++){
		EditBuffer[i]=EditBuffer[i+1];
	}
}
void load_edit_buffer(s32 val){
	u8 i,j;
	Flag.Sign=0;
	if(val<0){
		val=-val;
		Flag.Sign=1;
		}
	j=EDIT_LENGTH-1;
	for(i=0;i<EDIT_LENGTH;i++,j--){
		EditBuffer[i]=val/DIVReg[j]%10;
		}
}
s32 reload_edit_buffer(void){
	//Flag.Sign=(val<0) ? 1 : 0;
	u8 i,j;
	s32 val[EDIT_LENGTH];
	
	j=EDIT_LENGTH-1;
	val[0]=0;
	for(i=0;i<EDIT_LENGTH;i++){
		val[i]=EditBuffer[i]*DIVReg[j--];
		if(i!=0){
			val[0]+=val[i];
		}	
	}
	if(Flag.Sign) val[0]=-val[0];
	//if(Flag.Sign) val=-val;
	return val[0];
}
void load_edit_buffer_4digit(s16 val){
	Flag.Sign=(val<0) ? 1 : 0;

	if(Flag.Sign) val=-val;

	EditBuffer[0]=val/1000%10;
	EditBuffer[1]=val/100%10;
	EditBuffer[2]=val/10%10;
	EditBuffer[3]=val%10;
}
s16 reload_edit_buffer_4digit(void){
	//Flag.Sign=(val<0) ? 1 : 0;
	s16 val[5];

	val[0]=EditBuffer[0];
	val[1]=EditBuffer[1];
	val[2]=EditBuffer[2];
	val[3]=EditBuffer[3];

	val[0]=val[0]*1000;
	val[1]=val[1]*100;
	val[2]=val[2]*10;
	val[3]=val[3];

	val[0]=val[0]+val[1]+val[2]+val[3];

	if(Flag.Sign) val[0]=-val[0];
	
	//if(Flag.Sign) val=-val;
	return val[0];
}
void load_edit_buffer_3digit(s16 val){
	Flag.Sign=(val<0) ? 1 : 0;

	if(Flag.Sign) val=-val;

	EditBuffer[0]=val/100%10;
	EditBuffer[1]=val/10%10;
	EditBuffer[2]=val%10;
}

s16 reload_edit_buffer_3digit(void){
	//Flag.Sign=(val<0) ? 1 : 0;
	s16 val[5];

	val[0]=EditBuffer[0];
	val[1]=EditBuffer[1];
	val[2]=EditBuffer[2];

	val[0]=val[2]*100;
	val[1]=val[3]*10;
	val[2]=val[4];

	val[0]=val[0]+val[1]+val[2];

	if(Flag.Sign) val[0]=-val[0];
	
	//if(Flag.Sign) val=-val;
	return val[0];
}

void Clear_buffer(){
	EditNum=1;
	EditBuffer[0]=0;
	EditBuffer[1]=0;
	EditBuffer[2]=0;
	EditBuffer[3]=0;
	EditBuffer[4]=0;
}
void operate_mode(void){
	Status.Main=OPERATE_MODE;
	Flag.Edit=0;
	Flag.BlinkEn=1;
	EditNum=0;
	load_edit_buffer_4digit(0);
	Flag.CalAnalog=0;
}
void edit_slave_address_mode(void){
	Status.Main=EDIT_ADDRESS_MODE;
	Flag.Edit=0;
	EditNum=1;
	Value.Data16Last=Value.SlaveAddress;
	load_edit_buffer_4digit(Value.SlaveAddress);
}
void edit_baudrate_mode(void){
	Status.Main=EDIT_BAUDRATE_MODE;
	Flag.Edit=0;
	EditNum=1;
	Value.Data16Last=Value.Baudrate;
	load_edit_buffer_4digit(Value.Baudrate);
}
void edit_parity_mode(void){
	Status.Main=EDIT_PARITY_MODE;
	Flag.Edit=0;
	EditNum=1;
	Value.Data16Last=Value.Parity;
	load_edit_buffer_4digit(Value.Parity);
}

void edit_delay_polls_mode(void){
	Status.Main=EDIT_DELAY_POLLS_MODE;
	Flag.Edit=0;
	Value.DatamLast.LWord=Value.DelayBetweenPolls;
	load_edit_buffer(Value.DelayBetweenPolls);
}
void edit_response_timeout_mode(void){
	Status.Main=EDIT_RESPONSE_TIMEOUT_MODE;
	Flag.Edit=0;
	Value.DatamLast.LWord=Value.ResponseTimeOut;
	load_edit_buffer(Value.ResponseTimeOut);
}
void cal_analog_mode(void){
	Status.Main=CAL_ANALOG_MODE;
	Flag.CalAnalog=1;
	Flag.Edit=0;
	Flag.CalPoint=0;
}

void idle_mode(void){
	Status.Main=IDLE_MODE;
	Flag.Blink=0;
	Flag.BlinkEn=1;
//	Flag.Timer_En=0;
}
void edit_Input_mode(void){
	Status.Main=EDIT_INPUT_DELAY;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data16Last=Value.InputDelay;
	load_edit_buffer(Value.InputDelay);
}
void edit_Mul_mode(void){
	Status.Main=EDIT_MUL_MODE;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	switch(Value.Channel){
		case 0:	Value.Data16Last=Value.Multiplier1; break;
		case 1:	Value.Data16Last=Value.Multiplier2; break;
		case 2:	Value.Data16Last=Value.Multiplier3; break;
		case 3:	Value.Data16Last=Value.Multiplier4; break;
		}
	load_edit_buffer(Value.Data16Last);
}
void edit_Div_mode(void){
	Status.Main=EDIT_DIV_MODE;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	switch(Value.Channel){
		case 0:	Value.Data16Last=Value.Divisor1; break;
		case 1:	Value.Data16Last=Value.Divisor2; break;
		case 2:	Value.Data16Last=Value.Divisor3; break;
		case 3:	Value.Data16Last=Value.Divisor4; break;
		}
	load_edit_buffer(Value.Data16Last);
}
// Functoin Actual1 14
void edit_Target(void){
	Status.Main=EDIT_TARGET;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.Target;
	load_edit_buffer(Value.Data32Last);
}
// Functoin Actual1 15
void edit_Actual1(void){
	Status.Main=EDIT_ACTUAL1;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.Actual1;
	load_edit_buffer(Value.Data32Last);
}
// Functoin Actual2 17
void edit_Actual2(void){
	Status.Main=EDIT_ACTUAL3;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.Actual2;
	load_edit_buffer(Value.Data32Last);
}
// Functoin Actual3 18
void edit_Actual3(void){
	Status.Main=EDIT_ACTUAL4;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.Actual3;
	load_edit_buffer(Value.Data32Last);
}
// Functoin TotalSet 16
void edit_Total(void){
	Status.Main=EDIT_ACTUAL3;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;	
//	Flag.Timer_En=0;
	Value.Data32Last=Value.Total;
	load_edit_buffer(Value.Data32Last);
}
// Functoin TactTimeSet 17
void edit_TactTime(void){
	Status.Main=EDIT_ACTUAL4;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.TactTime;
	load_edit_buffer(Value.Data32Last);
}
void edit_SetTactTime(void){
	Status.Main=EDIT_SETTACTTIME;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Data32Last=Value.SetTactTime;
	load_edit_buffer(Value.Data32Last);
}
// Functoin CycleTimeTotal 18
void edit_CycleTimeTotal(void){
	Status.Main=EDIT_CYCLETIME;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Channel = 0;
	Value.Data32Last=Value.CycleTimeTarget;
	load_edit_buffer(Value.Data32Last);
}
void edit_CycleTimeTarget(void){
	Status.Main=EDIT_CYCLETIME;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Channel = 1;
	Value.Data32Last=Value.CycleTimeTarget;
	load_edit_buffer(Value.Data32Last);
}
void edit_SetPoint1(void){
	Status.Main=EDIT_ALS_MODE;
	Flag.Edit=0;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Channel = 0;
	Value.Data32Last=Value.SetPoint1;
	load_edit_buffer(Value.Data32Last);
}
void edit_SetPoint2(void){
	Status.Main=EDIT_ALS_MODE;
	Flag.Edit=0;
	EditNum=1;
	Flag.BlinkEn=1;
	Flag.Blink=0;
	Value.Channel = 1;
	Value.Data32Last=Value.SetPoint2;
	load_edit_buffer(Value.Data32Last);
}
void edit_SetTime(void){
	Status.Main=EDIT_SETTIME;
	Flag.Edit=1;
	EditNum=1;
	Flag.BlinkEn=1;
	EditBuffer[0] = RTC.Hours/10;
	EditBuffer[1] = RTC.Hours%10;
	EditBuffer[2] = RTC.Minutes/10;
	EditBuffer[3] = RTC.Minutes%10;
}
void edit_SetDate(void){
	Status.Main=EDIT_SETTIME;
	Flag.Edit=1;
	EditNum=0;
	Flag.BlinkEn=1;
	EditBuffer[0] = RTC.Date/10;
	EditBuffer[1] = RTC.Date%10;
	EditBuffer[2] = RTC.Month/10;
	EditBuffer[3] = RTC.Month%10;
}
void edit_GetTime(void){
	u8 sec,min,hour;
	sec = 0;
	hour = EditBuffer[0]*0x10 + EditBuffer[1];
	hour |=0x80;
	min = EditBuffer[2]*0x10 + EditBuffer[3];
	write_time_rtc(SC_REG, sec);
	write_time_rtc(MIN_REG, min);
	write_time_rtc(HR_REG, hour);
}
void edit_GetDate(void){
	u8 date,month,year;
	date = EditBuffer[0]*0x10 + EditBuffer[1];
	month = EditBuffer[2]*0x10 + EditBuffer[3];
	year = 18;
	write_time_rtc(DT_REG, date);
	write_time_rtc(MO_REG, month);
	write_time_rtc(YR_REG, year);
}
void edit_Break_EN(void){
	Status.Main = EDIT_BREAK_EN;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
}
void edit_Break_ON(u8 Date){
	Status.Main = EDIT_BREAK_ON;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	EditBuffer[0] = Value.Break_ON[Date]	/0x100	/10;
	EditBuffer[1] = Value.Break_ON[Date]	/0x100	%10;
	EditBuffer[2] = Value.Break_ON[Date]	%0x100	/10;
	EditBuffer[3] = Value.Break_ON[Date]	%0x100	%10;
}
void edit_Break_OFF(u8 Date){
	Status.Main = EDIT_BREAK_OFF;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	
	EditBuffer[0] = Value.Break_OFF[Date]	/0x100	/10;
	EditBuffer[1] = Value.Break_OFF[Date]	/0x100	%10;
	EditBuffer[2] = Value.Break_OFF[Date]	%0x100	/10;
	EditBuffer[3] = Value.Break_OFF[Date]	%0x100	%10;
}
void edit_TimeRESET(){
	Status.Main = EDIT_TIMERESET;
	Flag.Edit=0;
	EditNum=0;
	Flag.BlinkEn=1;
	EditBuffer[0] = Value.TimeReset/0x100/10;
	EditBuffer[1] = Value.TimeReset/0x100%10;
	EditBuffer[2] = Value.TimeReset%0x100/10;
	EditBuffer[3] = Value.TimeReset%0x100%10;
}
void Reload_TimeON(u8 Date){
	Value.Break_ON[Date] = 	(((EditBuffer[0]*10)+(EditBuffer[1]))*0x100)+((EditBuffer[2]*10)+(EditBuffer[3]));
	write_eeprom(Time_On(Date), Value.Break_ON[Date]);
}
void Reload_TimeOFF(u8 Date){
	Value.Break_OFF[Date] = 	(((EditBuffer[0]*10)+(EditBuffer[1]))*0x100)+((EditBuffer[2]*10)+(EditBuffer[3]));
	write_eeprom(Time_Off(Date), Value.Break_OFF[Date]);
}
void Reload_TimeRESET(){
	Value.TimeReset = 	(((EditBuffer[0]*10)+(EditBuffer[1]))*0x100)+((EditBuffer[2]*10)+(EditBuffer[3]));
	write_eeprom(EEP_TIMERESET, Value.TimeReset);
	write_eeprom(EEP_TIMERESET_M, Value.ResetMode);
}
void check_cal_analog(void){
	if(Status.Main!=OPERATE_MODE) return;
	if(!Flag.CalAnalog){
		if((EditNum>=1)&&(++Value.CalAnTimeOut>50)){
			if((EditBuffer[0]=1)&&(EditBuffer[1]==6)&&(EditBuffer[2]==3)&&(EditBuffer[3]==4)){
				cal_analog_mode();
			}
		}
	}
}

void save(void){
	switch(Status.Main){
		case EDIT_ADDRESS_MODE:
			if(Value.Data16Last!=Value.SlaveAddress){
				write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
			}
			break;
		case EDIT_BAUDRATE_MODE:
			if(Value.Data16Last!=Value.Baudrate){
				write_eeprom(EEP_BAUDRATE, Value.Baudrate);
			}
			break;
		case EDIT_PARITY_MODE:
			if(Value.Data16Last!=Value.Parity){
				write_eeprom(EEP_PARITY, Value.Parity);
			}
			break;
		case EDIT_TARGET:
			if(Value.Data16Last!=Value.Target){
				write_ram_RTC(RAM_TARGET_,(u8 *)& Value.Target,4);
				write_eeprom(EEP_TARGET, Value.Target);
			}
			break;
		case EDIT_ACTUAL1:
			if(Value.Data16Last!=Value.Actual1){
				write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
				write_eeprom(EEP_ACTUAL1, Value.Actual1);
				if(!Value.Actual1){
					Value.Actual3 = 0;
					write_ram_RTC(RAM_ACTUAL3_,(u8 *)& Value.Actual3,4);
					}
			}
			break;
		case EDIT_ACTUAL3:
			if(Value.Data16Last!=Value.Actual2){
				write_ram_RTC(RAM_ACTUAL2_,(u8 *)& Value.Actual2,4);
				write_eeprom(EEP_ACTUAL2, Value.Actual2);
			}
			break;
		case EDIT_ACTUAL4:
			if(Value.Data16Last!=Value.Actual3){
				write_ram_RTC(RAM_ACTUAL3_,(u8 *)& Value.Actual3,4);
				write_eeprom(EEP_ACTUAL3, Value.Actual3);
			}
			break;
		case EDIT_MUL_MODE:
			switch(Value.Channel){
				case 0:	if(Value.Data16Last!=Value.Multiplier1)	write_eeprom(EEP_MUL1, Value.Multiplier1);	break;
				case 1:	if(Value.Data16Last!=Value.Multiplier2)	write_eeprom(EEP_MUL2, Value.Multiplier2);	break;
				case 2:	if(Value.Data16Last!=Value.Multiplier3)	write_eeprom(EEP_MUL3, Value.Multiplier3);	break;
				case 3:	if(Value.Data16Last!=Value.Multiplier4)	write_eeprom(EEP_MUL4, Value.Multiplier4);	break;
			}
			break;
		case EDIT_DIV_MODE:
			switch(Value.Channel){
				case 0:	if(Value.Data16Last!=Value.Divisor1)	write_eeprom(EEP_DIV1, Value.Divisor1);	break;
				case 1:	if(Value.Data16Last!=Value.Divisor2)	write_eeprom(EEP_DIV2, Value.Divisor2);	break;
				case 2:	if(Value.Data16Last!=Value.Divisor3)	write_eeprom(EEP_DIV3, Value.Divisor3);	break;
				case 3:	if(Value.Data16Last!=Value.Divisor4)	write_eeprom(EEP_DIV4, Value.Divisor4);	break;
			}
			break;
		case EDIT_INPUT_DELAY:
			if(Value.Data16Last!=Value.InputDelay){
				write_eeprom(EEP_INPUTDELAY, Value.InputDelay);
			}
			break;
		case EDIT_ALS_MODE:
			if(Value.Channel == 0){
				if(Value.Data16Last!=Value.SetPoint1){
					write_ram_RTC(RAM_ACTUAL3_R,(u8 *)& Value.SetPoint1,4);
					write_eeprom(EEP_SETPOINT1_L,Value.SetPoint1);
					write_eeprom(EEP_SETPOINT1_M,Value.SetPointMode1);
					}
				}
			else if(Value.Channel == 1){
				if(Value.Data16Last!=Value.SetPoint2){
					write_eeprom(EEP_SETPOINT2_L,Value.SetPoint2);
					write_eeprom(EEP_SETPOINT2_M,Value.SetPointMode2);
					}
				}
			break;
		case EDIT_CYCLETIME:
			if(Value.Channel == 0){
				if(Value.Data16Last!=Value.CycleTimeTotal){
					write_ram_RTC(RAM_CYCLEPLAN_,(u8 *)& Value.CycleTimeTotal,2);
					write_eeprom(EEP_CYCLEPLAN,Value.CycleTimeTotal);
					}
				}
			else if(Value.Channel == 1){
				if(Value.Data16Last!=Value.CycleTimeTarget){
					write_ram_RTC(RAM_CYCLETARGET_,(u8 *)& Value.CycleTimeTarget,2);
					write_eeprom(EEP_CYCLETARGET,Value.CycleTimeTarget);
					}
				}
			break;
		case EDIT_SETTACTTIME:
			if(Value.Data16Last!=Value.SetTactTime){
				write_eeprom(EEP_SETTACTTIME, Value.SetTactTime);
//				write_eeprom(EEP_CYCLEPLAN,Value.CycleTimeTotal);
			}
			break;
			
		
	}
}

void Time_Reset_Display(void){

	if(++X_Time_RESET>=25){
		X_Time_RESET=0;
		ResetTime.Word = Value.TimeReset;
		if(RTC.Hours == ResetTime.H && RTC.Minutes== ResetTime.L && RTC.Seconds== 0){
			switch(Value.ResetMode){
				case 1:
					Value.Actual1 = 0 ;
					write_ram_RTC(RAM_TARGET_,(u8 *)&Value.Actual1,4);
					break;
				case 2:
					Value.Actual1= 0 ;
					write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
					break;
				case 3:
					Value.TactTime= 0 ;
					write_ram_RTC(RAM_ACTUAL3_,(u8 *)&Value.TactTime,4);
					break;
				case 4:
					Value.Actual1 = 0 ;
					write_ram_RTC(RAM_TARGET_,(u8 *)&Value.Actual1,4);
					Value.Actual1= 0 ;
					write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
					break;
				case 5:
					Value.Actual1 = 0 ;
					write_ram_RTC(RAM_TARGET_,(u8 *)&Value.Actual1,4);
					Value.TactTime= 0 ;
					write_ram_RTC(RAM_ACTUAL3_,(u8 *)&Value.TactTime,4);
					break;
				case 6:
					Value.Actual1= 0 ;
					write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
					Value.TactTime= 0 ;
					write_ram_RTC(RAM_ACTUAL3_,(u8 *)&Value.TactTime,4);
					break;
				case 7:
					Value.Actual1 = 0 ;
					write_ram_RTC(RAM_TARGET_,(u8 *)&Value.Actual1,4);
					Value.Actual1= 0 ;
					write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
					Value.TactTime= 0 ;
					write_ram_RTC(RAM_ACTUAL3_,(u8 *)&Value.TactTime,4);
					break;
				}
			}	
		}
}

void Time_ON_OFF(void){
	u8 i;
	
	if(Value.Break_EN==1){
		
		if(++X_Time_ON_OFF>=25){
			X_Time_ON_OFF = 0;
			for(i=0;i<10;i++){
				BreakOn.Word = Value.Break_ON[i];
				BreakOff.Word = Value.Break_OFF[i];
				if(RTC.Hours == BreakOn.H && RTC.Minutes== BreakOn.L && RTC.Seconds== 0){
					operate_mode();
					Value.StatusTime = 1;
					}
				if(RTC.Hours == BreakOff.H && RTC.Minutes== BreakOff.L && RTC.Seconds== 0){
					operate_mode();
					Value.StatusTime = 0;
					}
				}
			}
		}
}
void Alarm_4_Function(s32 val, s32 mode, s32 high, s32 low, s32 conn, u8 Pin){
	switch(mode){
		case 0:
		if(Pin == 0){	OUT1  = 0;	}
		if(Pin == 1){ 	OUT2  = 0;	}
		if(Pin == 2){ 	OUT3  = 0;	}
			break;
		case 1:
		if(Pin == 0){
			if(OUT1 ==0 )	{ if(	(val >= high)		|| (val <= low) )			{ OUT1  = 1; } }
			else			{ if( (val < (high - conn))	&& (val > (low + conn)) )	{ OUT1  = 0; } }
			}
		if(Pin == 1){
			if(OUT2 ==0 )	{ if(	(val >= high)		|| (val <= low) )			{ OUT2  = 1; } }
			else			{ if( (val < (high - conn))	&& (val > (low + conn)) )	{ OUT2  = 0; } }
			}
		if(Pin == 2){
			if(OUT3 ==0 )	{ if(	(val >= high)		|| (val <= low) )			{ OUT3  = 1; } }
			else			{ if( (val < (high - conn))	&& (val > (low + conn)) )	{ OUT3  = 0; } }
			}
			break;
		case 2:
		if(Pin == 0){
			if(OUT1 ==0 )	{ if(	(val >= high))		{ OUT1  = 1; } }
			else			{ if(	(val < (high - conn)) ){ OUT1  = 0; } }
			}
		if(Pin == 1){
			if(OUT2 ==0 )	{ if(	(val >= high))		{ OUT2  = 1; } }
			else			{ if(	(val < (high - conn)) ){ OUT2  = 0; } }
			}
		if(Pin == 2){
			if(OUT3 ==0 )	{ if(	(val >= high))		{ OUT3  = 1; } }
			else			{ if(	(val < (high - conn)) ){ OUT3  = 0; } }
			}
			break;
		case 3:
		if(Pin == 0){
			if(OUT1 ==0 )	{ if( (val <= low)	)		{ OUT1  = 1; } }
			else			{ if( (val > (low + conn)) )	{ OUT1  = 0; } }
			}
		if(Pin == 1){
			if(OUT2 ==0 )	{ if( (val <= low)	)		{ OUT2  = 1; } }
			else			{ if( (val > (low + conn)) )	{ OUT2  = 0; } }
			}
		if(Pin == 2){
			if(OUT3 ==0 )	{ if( (val <= low)	)		{ OUT3  = 1; } }
			else			{ if( (val > (low + conn)) )	{ OUT3  = 0; } }
			}
			break;
		case 4:
		if(Pin == 0){
			if(OUT1 ==0 )	{ if( (val <= high)		 && (val >= low) )			{ OUT1  = 1; } }
			else			{ if( (val > (high + conn))	 || (val < (low - conn)) )	{ OUT1  = 0; } }
			}
		if(Pin == 1){
			if(OUT2 ==0 )	{ if( (val <= high)		 && (val >= low) )			{ OUT2  = 1; } }
			else			{ if( (val > (high + conn))	 || (val < (low - conn)) )	{ OUT2  = 0; } }
			}
		if(Pin == 2){
			if(OUT3 ==0 )	{ if( (val <= high)		 && (val >= low) )			{ OUT3  = 1; } }
			else			{ if( (val > (high + conn))	 || (val < (low - conn)) )	{ OUT3  = 0; } }
			}
			break;
		}
}

void AlarmOutput(void){
	Alarm_4_Function(Value.Actual1, 2, Value.SetPoint1, 0, 0, 0);
	Alarm_4_Function(Value.Actual1, 2, Value.SetPoint2, 0, 0, 1);
//	Alarm_4_Function(Value.Actual1, 2, Value.SetPoint1, 0, 0, 2);
	if(!Value.CycleTimeTarget){
		}
	else{
		if(++WorkingProgram>=Value.CycleTimeTarget){
			WorkingProgram =0;
			if(Value.Target<999999){
				Value.Target +=1;
				write_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
				}
			}
		}
}
void trig_0(void){
	switch(Trig0.Status){
		case TRIG:
			if(!_RB0){
				Trig0.HoldTime=CLR;
				Trig0.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB0){
				if(++Trig0.HoldTime >= 10){
					//trig
					Trig0.HoldTime=CLR;
					if(Value.Actual1>0){
						Value.Actual1 = 0;
						Flag.Timer_En = 0;
						write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
						Value.Actual3 = 0;
						write_ram_RTC(RAM_ACTUAL3_,(u8 *)& Value.Actual3,4);
//						write_eeprom(EEP_TARGET, Value.Actual1);
						}
					Trig0.Status=RELEASE;
				}
			}
			else{
					//no trig
				Trig0.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB0){
			if(!Flag.Timer_En){
				Flag.Timer_En=1;
			}
				Trig0.Status=TRIG;
			}
			break;
	}
}
void trig_1(void){
#if 1
	switch(Trig1.Status){
		case TRIG:
			if(!_RB1){
				Trig1.HoldTime=CLR;
				Trig1.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB1){
				if(++Trig1.HoldTime>= Value.InputDelay*10){
					/*trig*/
					if(++Value.Div1>=Value.Divisor1){
						Value.Div1 = 0;
						if(Value.Actual1+Value.Multiplier1<=SEG_LIMITMAX){
							Value.Actual1 += Value.Multiplier1;
							Flag.Timer_En = 1;
							write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//							write_eeprom(EEP_ACTUAL1, Value.Actual1);
							}
						}
					Trig1.HoldTime=CLR;
					Trig1.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig1.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB1){
				Trig1.Status=TRIG;
			}
			break;
	}
	#endif
}
void trig_2(void){
	switch(Trig2.Status){
		case TRIG:
			if(!_RB2){
				Trig2.HoldTime=CLR;
				Trig2.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB2){
				if(++Trig2.HoldTime>= 10){
					/*trig*/
					Trig2.HoldTime=CLR;
					Trig2.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig2.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB2){
				Trig2.Status=TRIG;
			}
			break;
	}
}
void trig_3(void){
	switch(Trig3.Status){
		case TRIG:
			if(!_RB3){
				Trig3.HoldTime=CLR;
				Trig3.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB3){
				if(++Trig3.HoldTime>= 10){
					/*trig*/
					Trig3.HoldTime=CLR;
					Trig3.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig3.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB3){
				Trig3.Status=TRIG;
			}
			break;
	}
}
void trig_4(void){
	switch(Trig4.Status){
		case TRIG:
			if(!_RB4){
				Trig4.HoldTime=CLR;
				Trig4.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB4){
				if(++Trig4.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig4.HoldTime=CLR;
					Trig4.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig4.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB4){
				Trig4.Status=TRIG;
			}
			break;
	}
}
void trig_5(void){
	switch(Trig5.Status){
		case TRIG:
			if(!_RB5){
				Trig5.HoldTime=CLR;
				Trig5.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB5){
				if(++Trig5.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig5.HoldTime=CLR;
					Trig5.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig5.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB5){
				Trig5.Status=TRIG;
			}
			break;
	}
}
void trig_6(void){
	switch(Trig6.Status){
		case TRIG:
			if(!_RC13){
				Trig6.HoldTime=CLR;
				Trig6.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC13){
				if(++Trig6.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig6.HoldTime=CLR;
					Trig6.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig6.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC13){
				Trig6.Status=TRIG;
			}
			break;
	}
}
void trig_7(void){
	switch(Trig7.Status){
		case TRIG:
			if(!_RC14){
				Trig7.HoldTime=CLR;
				Trig7.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC14){
				if(++Trig7.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig7.HoldTime=CLR;
					Trig7.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig7.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC14){
				Trig7.Status=TRIG;
			}
			break;
	}
}

