#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"
#include "Matrix.h"
void shift_data(u8 *dptr){
	u8 i;
	for(i=0x80;i>0;i=i/2){
		SER=(i&*dptr) ? 1 : 0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=1;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	}
}

void TPIC6B595_LATCH(u8 *dptr){
	u8 i;
	_TRISE0=0;
	_TRISE1=0;
	_TRISE2=0;
	
	ST_CLK=0;
	SH_CLK=0;
	for(i=0;i<SEGMENT_LENGTH;i++,dptr++){
//	for(i=0;i<MATRIX_COLUMN*MATRIX_LENGTH;i++,dptr++){
		shift_data(dptr);
	}
	ST_CLK=1;
	ST_CLK=0;
}
void TPIC6B595_scan(void){
	u8 i, data[SEGMENT_LENGTH];
	
	for(i=0; i<SEGMENT_LENGTH; i++){
		data[i]=0x00;
		data[i]=SegmentData[i];
		}
	TPIC6B595_LATCH(data);
}
#if 1
void shift_data2(u8 *dptr){
	u8 i;
	for(i=0x80;i>0;i=i/2){
		DAT=(i&*dptr) ? 0 : 1;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		CLK=1;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		CLK=0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	}
}
void TPIC6B595_LATCH2(u8 *dptr){
	u8 i;
	_TRISD0=0;
	_TRISE4=0;
	_TRISF0=0;
	
	STR=0;
	CLK=0;
	for(i=0;i<MATRIX_COLUMN * MATRIX_LENGTH;i++,dptr++){
	// for(i=0;i<10;i++,dptr++){
		shift_data2(dptr);
	}
	STR=1;
	STR=0;
}
void HC595_SCAN(void){
	u8 i,j, data2[MATRIX_LENGTH * MATRIX_COLUMN];
	s8 data[8];
    for(i=0;i<MATRIX_LENGTH;i++){
		data[i] = MatrixData[i] - 32;
        for(j=0;j<MATRIX_COLUMN;j++){
		data2[j + (i * 5)] = MAP_FONT[data[i]][MATRIX_COLUMN-1-j];
		// data2[j + (i * 5)] = MatrixData[i];
		// data2[j+(i*5)]=SegmentData[i];
        }
	}
	//data[0] = data2[0];
	TPIC6B595_LATCH2(data2);

	// data[0] = S5FONT_1;
	// data[1] = S4FONT_1;
	// data[2] = S3FONT_1;
	// data[3] = S2FONT_1;
	// data[4] = S1FONT_1;
	// data[5] = S1FONT_BLANK;
	// data[6] = S1FONT_BLANK;
	// data[7] = S1FONT_BLANK;
	// data[8] = S1FONT_BLANK;
	// data[9] = S1FONT_BLANK;
	// TPIC6B595_LATCH2(data);
}
#endif
void TPIC6B595_init(void){  // Loop Segmant 0 - N
	u8 i;
	for(i=0;i<SEGMENT_LENGTH;i++){
		SegmentData[i]=FONT_BLANK;
	}
	for(i=0;i<MATRIX_LENGTH;i++){
		MatrixData[i] = ' ';
	}
}

