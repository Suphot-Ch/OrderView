#ifndef GLOBAL_H
#include "typedef.h"

extern void TPIC6B595_LATCH2(u8 val);
extern void TPIC6B595_LATCH(u8 *dptr);
extern void TPIC6B595_scan(void);

extern void TPIC6B595_init(void);
extern void display_1(void);
extern void display_2(void);
extern void read_data(void);
extern void sum(u8 rw, u8 *dptr);
extern u8 get_addr(u8 addr0, u8 addr1);
extern u8 get_dp(void);
extern u8 get_sign(void);
extern s8 incorrect_data(u8 *dptr);
extern void ir_decode(void);
extern void read_current_time(void);
//extern void write_current_time(unsigned char *dptr);
extern void rtc_init(void);
extern void tcd(void);

extern void trig_0(void);
extern void trig_1(void);
extern void trig_2(void);
extern void trig_3(void);
extern void trig_4(void);
extern void trig_5(void);
extern void trig_6(void);
extern void trig_7(void);
extern void (*update_segment_page[])(void);
extern void operate_mode(void);
extern void idle_mode(void);
extern void edit_scale_hi_mode(void);
extern void edit_scale_lo_mode(void);
extern void edit_decimalpoint_mode(void);
extern void edit_slave_address_mode(void);
extern void edit_baudrate_mode(void);
extern void edit_parity_mode(void);
extern void edit_delay_polls_mode(void);
extern void edit_response_timeout_mode(void);
extern void choose_mode(void);
extern void alarm_low_mode(void);
extern void alarm_high_mode(void);
extern void alarm_control_mode(void);
extern void Clear_Buffer(void);

extern void edit_value_time(void);
extern void edit_value_date(void);
extern void edit_value_year(void);

extern void tx_en(void);
extern void rx_en(void);
extern void edit_event(void);
extern void get_hour(u8 *dptr);
extern void get_minutes(u8 *dptr);
extern void get_event(u8 *dptr);
extern void get_num(s16 *dptr);
extern void set_run(void);
extern void set_break(void);
extern void show_current_time(void);
extern void read_program(void);
extern void program_sort(void);
extern void reset_target_actual(void);
extern void write_ram_RTC(u8 addr, u8 *dptr, u8 n);
extern void read_ram_RTC(u8 addr, u8 *dptr, u8 n);
extern void eeprom_erase_word(unsigned long addr);
extern void write_eeprom(unsigned long addr, u16 value);
extern u16 read_eeprom(unsigned long addr);
extern void clear_program(u8 *hours, u8 *minutes);
extern void clear_event(u8 *event);
extern void save(void);
extern void set_char(s8 a,s8 b,s8 c,s8 d,s8 e,u8 * segment);
extern void set_char1(s8 a, u8 *segment);
extern void set_char4(s8 a, s8 b, s8 c, s8 d, u8 *segment);
extern void set_num_lo_r1(s16 value, u8 *segment);
extern void clk(void);
extern void load_edit_buffer(s32 val);
extern s32 reload_edit_buffer(void);
//extern void load_edit_buffer_tcd(s32 val);
extern void shift_edit_buffer(void);
extern void check_cal_analog(void);
extern void hys_mode(void);
extern void alarm_control_mode(void);
extern void pus_mode(void);
extern void alarm_low_mode(void);
extern void ch2(void);
extern void ch3(void);
extern void edit_timer(void);

extern void config_uart2(void);
extern void shift_edit_buffer_Length(void);
extern u8 convert_write_Fix(u8 val, u8 add);
extern u8 convert_read_Fix(u8 val , u8 add);
extern void write_current_time_Fix(unsigned char dptr , u8 add);
extern void load_buffer_Time(void);
extern void load_buffer_Date(void);
extern void load_buffer_Year(void);
extern void reload_buffer_Time(void);
extern void reload_buffer_Date(void);
extern void reload_buffer_Year(void);

extern u8 TimeUpdateRTC;
extern u8 TimeBlink;
extern u8 SegmentDigit;
extern u8 SegmentData[SEGMENT_LENGTH];
extern u8 EditBuffer[EDIT_LENGTH];
extern u16 Dp;
extern u8 EditNum;
extern u8 ProgramIndex;
extern u8 TimeResetIndex;
extern u8 WorkingProgram;
extern u8 DSPMode;
extern u8 CurrentProgram;

extern u8 *MB_Dptr;

extern Status_sType Status;
extern IR_sType IrData;
extern RTC_sType RTC;
extern Value_sType Value;
extern MB_sType Modbus;
extern Trig_sType Trig0;
extern Trig_sType Trig1;
extern Trig_sType Trig2;
extern Trig_sType Trig3;
extern Trig_sType Trig4;
extern Trig_sType Trig5;
extern Trig_sType Trig6;
extern Trig_sType Trig7;
extern Program_sType TimeReset[2];
extern Program_sType TimeResetBuff[2];
extern Program_sType Program[20];
extern Program_sType ProgramBuff[20];
extern Flag_uType Flag;
extern ADC_sType ADC;
#endif

