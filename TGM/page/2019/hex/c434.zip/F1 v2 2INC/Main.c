#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"

_FOSC(CSW_FSCM_OFF & XT_PLL8);
_FWDT(WDT_OFF);
_FBORPOR(PBOR_ON & BORV_27 & PWRT_OFF & MCLR_DIS);

/*
Fcy=Fosc/4=(Xtal*PLL)/(POST*4)
Fcy=(7.3728MHz*8)/(4)
Fcy=14.7456MHz
Tcy=6.7816840277777777777777777777778e-8
*/
void io_init(void){
	ADPCFG=0xFFFF;
	TRISB=0xF03F;
	TRISC=0xFFFF;
	TRISD=0xFFF0;
	TRISE=0xFF00;
	TRISF=0xFFD2;
}
void int0_init(void){
	_INT0EP=FALLING;
	_INT0IE=EN;
	_INT0IP=PRIORITY_7;
}
void timer1_init(void){
	TMR1=CLR;
	PR1=TMR1_PERIOD;
	_T1IP=PRIORITY_3;
	T1CON=0x0030;
	_T1IE=EN;
	_T1ON=EN;
}
void timer2_init(void){
	TMR2=CLR;
	PR2=TMR2_PERIOD;
	T2CON=0x0030;
	_T2IP=PRIORITY_2;
	_T2IE=EN;
	//_T2ON=SET;
}
void timer3_init(void){
	TMR3=CLR;
	PR3=TMR3_PERIOD;
	T3CON=0x0030;
	_T3IP=PRIORITY_6;
	_T3IE=EN;
	_T3ON=SET;
}
void timer4_init(void){
	TMR4=CLR;
	PR4=TMR4_PERIOD;
	T4CON=0x0030;
	_T4IP=PRIORITY_5;
	_T4IE=EN;
	_T4ON=EN;
}
void config_uart2(void){
	switch(Value.Baudrate){
//		case BR2400:
//			U2BRG=384;
//			break;
		case BR4800:
			U2BRG=191;
			break;
		case BR19200:
			U2BRG=47;
			break;
		case BR38400:
			U2BRG=23;
			break;
		case BR57600:
			U2BRG=15;
			break;
		case BR115200:
			U2BRG=7;
			break;
		default:
			U2BRG=95;
			break;
	}
	switch(Value.Parity){
		case b8o1:
			cbi(U2MODE, BIT1);
			sbi(U2MODE, BIT2);
			break;
		case b8e1:
			sbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
		default:
			cbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
	}
}
void uart2_init(void){
	U2MODE=0x8000;
	U2STA=0x8400;
	config_uart2();
	_U2RXIP=PRIORITY_6;
	_U2TXIP=PRIORITY_4;
	_U2RXIE=EN;
	_U2TXIE=EN;
//USE	rx_en();
}
void ram_init(void){
	u8 ctrl;
	u16 i;
	s16 val[2];
	s16 segment[5];
	ADC_CS=1;
	for(i=0;i<10000;i++) delayxNop();
	read_ram_RTC(CONTROL_REG, &ctrl, 1);

	/************************************************************************************************************************/
	/**************************************************   Read RAM   ********************************************************/
	/************************************************************************************************************************/
	read_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
	if(Value.Target>SEG_LIMITMAX||Value.Target<SEG_LIMITMIN){
		Value.Target=0;
		write_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
		write_eeprom(EEP_TARGET, Value.Target);
	}

	read_ram_RTC(RAM_ACTUAL1_, (u8 *)&Value.Actual1, 4);
	if(Value.Actual1>SEG_LIMITMAX||Value.Actual1<SEG_LIMITMIN){
		Value.Actual1=0;
		write_ram_RTC(RAM_ACTUAL1_, (u8 *)&Value.Actual1, 4);
		write_eeprom(EEP_ACTUAL1, Value.Actual1);
	}

	/************************************************************************************************************************/
	/**************************************************   Timer Function   **************************************************/
	/************************************************************************************************************************/
	Value.Time_EN = read_eeprom(EEP_TIME_EN);
	if(Value.Time_EN > 1){
		write_eeprom(EEP_TIME_EN, Value.Time_EN = 0);
	}delayxNop();
	
	for(i=0; i<TIMER_CHANNEL; i++){
		// read_eeprom_timer(EEP_TIMEON_00, i, &Value.Time_ON[TIMER_CHANNEL_MAX-i].Word);
		Value.Time_ON[TIMER_CHANNEL_MAX-i].Word = read_eeprom(EEP_TIMEON_00 + (i * 2));
		if(Value.Time_ON[TIMER_CHANNEL_MAX-i].Word > 0x1800){
			Value.Time_ON[TIMER_CHANNEL_MAX-i].Word = 0x1800;
			write_eeprom(EEP_TIMEON_00 + (i * 2), Value.Time_ON[TIMER_CHANNEL_MAX-i].Word);
			// write_eeprom_timer(EEP_TIMEON_00, i, &Value.Time_ON[TIMER_CHANNEL_MAX-i].Word);
		}delayxNop();
		// read_eeprom_timer(EEP_TIMEOFF_00, i, &Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word);
		Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word = read_eeprom(EEP_TIMEOFF_00 + (i * 2));
		if(Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word > 0x1800){
			Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word = 0x1800;
			write_eeprom(EEP_TIMEOFF_00 + (i * 2), Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word);
			// write_eeprom_timer(EEP_TIMEOFF_00, i, &Value.Time_OFF[TIMER_CHANNEL_MAX-i].Word);
		}delayxNop();
		// read_eeprom_timer(EEP_TIMERESET_00, i, &Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word);
		Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word = read_eeprom(EEP_TIMERESET_00 + (i * 2));
		if(Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word > 0x1800){
			Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word = 0x1800;
			write_eeprom(EEP_TIMERESET_00 + (i * 2), Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word);
			// write_eeprom_timer(EEP_TIMERESET_00, i, &Value.Time_Reset[TIMER_CHANNEL_MAX-i].Word);
		}delayxNop();
	}

	/*****************************************************************************************************************************/
	/**************************************************   Chart for TGA - 002   **************************************************/
	/*****************************************************************************************************************************/
	for(i=0;i<8;i++){
		Value.Chart[i] = read_eeprom(EEP_CHART_ASCII + (i*2));
		if(Value.Chart[i] < 0x20 || Value.Chart[i] > 0x7F){
			Value.Chart[i] = 0x30+i;
			write_eeprom(EEP_CHART_ASCII + (i*2), Value.Chart[i]);
		}
	}
	/*****************************************************************************************************************************/
	/**************************************************   Summary Time   *********************************************************/
	/*****************************************************************************************************************************/
	read_eeprom_32(EEP_SETPOINT1_H, &Value.SetPoint1);
	if(Value.SetPoint1>99999 || Value.SetPoint1<0){
		Value.SetPoint1 = 800;
		write_eeprom_32(EEP_SETPOINT1_H, &Value.SetPoint1);
	}
	read_eeprom_32(EEP_SETPOINT2_H, &Value.SetPoint2);
	if(Value.SetPoint2>99999 || Value.SetPoint2<0){
		Value.SetPoint2 = 1000;
		write_eeprom_32(EEP_SETPOINT2_H, &Value.SetPoint2);
	}

	/*****************************************************************************************************************************/
	/**************************************************   Summary Time   *********************************************************/
	/*****************************************************************************************************************************/
	Value.SummaryTimeSecond	= read_eeprom(EEP_SUMMARYTIME_SECOND);
	if(Value.SummaryTimeSecond>59 || Value.SummaryTimeSecond<0){
		write_eeprom(EEP_SUMMARYTIME_SECOND, Value.SummaryTimeSecond = 0);
	}
	Value.SummaryTimeMinute	= read_eeprom(EEP_SUMMARYTIME_MINUTE);
	if(Value.SummaryTimeMinute>59 || Value.SummaryTimeMinute<0){
		write_eeprom(EEP_SUMMARYTIME_MINUTE, Value.SummaryTimeMinute = 0);
	}
	Value.SummaryTimeHour	= read_eeprom(EEP_SUMMARYTIME_HOUR);
	if(Value.SummaryTimeHour>23 || Value.SummaryTimeHour<0){
		write_eeprom(EEP_SUMMARYTIME_HOUR, Value.SummaryTimeHour = 0);
	}
	Value.SummaryTimeDay	= read_eeprom(EEP_SUMMARYTIME_DAY);
	if(Value.SummaryTimeDay>999 || Value.SummaryTimeDay<0){
		write_eeprom(EEP_SUMMARYTIME_DAY, Value.SummaryTimeDay = 0);
	}

	/**************************************************************************************************************************/
	/**************************************************   Down Time   *********************************************************/
	/**************************************************************************************************************************/
	Value.DownTimeSecond	= read_eeprom(EEP_DOWNTIME_SECOND);
	if(Value.DownTimeSecond>59 || Value.DownTimeSecond<0){
		write_eeprom(EEP_DOWNTIME_SECOND, Value.DownTimeSecond = 0);
	}
	Value.DownTimeMinute	= read_eeprom(EEP_DOWNTIME_MINUTE);
	if(Value.DownTimeMinute>59 || Value.DownTimeMinute<0){
		write_eeprom(EEP_DOWNTIME_MINUTE, Value.DownTimeMinute = 0);
	}
	Value.DownTimeHour		= read_eeprom(EEP_DOWNTIME_HOUR);
	if(Value.DownTimeHour>23 || Value.DownTimeHour<0){
		write_eeprom(EEP_DOWNTIME_HOUR, Value.DownTimeHour = 0);
	}
	Value.DownTimeDay		= read_eeprom(EEP_DOWNTIME_DAY);
	if(Value.DownTimeDay>999 || Value.DownTimeDay<0){
		write_eeprom(EEP_DOWNTIME_DAY, Value.DownTimeDay = 0);
	}

	/**************************************************************************************************************************/
	/**************************************************   Function    *********************************************************/
	/**************************************************************************************************************************/
	Value.Multiplier1	=	read_eeprom(EEP_MUL1);
	if(Value.Multiplier1 > 999 || Value.Multiplier1 < 1){
		write_eeprom(EEP_MUL1,Value.Multiplier1 = 1);	
	}
	Value.Divisor1		=	read_eeprom(EEP_DIV1);
	if(Value.Divisor1 > 999 || Value.Divisor1 < 1){
		write_eeprom(EEP_DIV1,Value.Divisor1 = 1);
	}
	Value.DecimalPoint	=	read_eeprom(EEP_DP);
	if(Value.DecimalPoint > 4 || Value.DecimalPoint < 0){
		write_eeprom(EEP_DP,Value.DecimalPoint = 0);
	}
	/**************************************************************************************************************************/
	/**************************************************  Input Mode   *********************************************************/
	/**************************************************************************************************************************/
	Value.InputType		=	read_eeprom(EEP_INPUT_TYPE);
	if(Value.InputType > 1 || Value.InputType < 0){
		write_eeprom(EEP_INPUT_TYPE,Value.InputType = 0);
	}
	Value.InputDelay	=	read_eeprom(EEP_INPUTDELAY);
	if(Value.InputDelay > 999 || Value.InputDelay < 1){
		write_eeprom(EEP_INPUTDELAY,Value.InputDelay = 1);
	}
	Value.CycleTimeTarget	=	read_eeprom(EEP_CYCLETARGET);
	if(Value.CycleTimeTarget > 999 || Value.CycleTimeTarget < 0){
		write_eeprom(EEP_CYCLETARGET,Value.CycleTimeTarget = 0);
	}

	/***************************************************************************************************************************/
	/**************************************************  Series Modbus *********************************************************/
	/***************************************************************************************************************************/
	Value.SlaveAddress = read_eeprom(EEP_SLAVE_ADDRESS);
	if(Value.SlaveAddress > 255 || Value.SlaveAddress < 0){
		Value.SlaveAddress = 1;
		write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
	}
	Value.Baudrate = read_eeprom(EEP_BAUDRATE);
	if(Value.Baudrate > BR57600 || Value.Baudrate < BR4800){
		Value.Baudrate = BR9600;
		write_eeprom(EEP_BAUDRATE, Value.Baudrate);
	}
	Value.Parity = read_eeprom(EEP_PARITY);
	if(Value.Parity > b8e1 || Value.Parity < b8n1){
		Value.Parity = b8n1;
		write_eeprom(EEP_PARITY, Value.Parity);
	}

	Flag.Word=CLR;
	Status.Main=INIT_MODE;
	Modbus.Status=RSP_PV;
	Value.Protocol=RTUs;
	Value.WarningStatus = WN_NONE;
	
	Value.SwMinorYear = 0;		// 	07	7		0
	Value.SwMajorYear = 2;		// 	06	6		1
	Value.SwReleaseYear = 2019;		// 	05	5		2015
	Value.HwMinorVersion = 0;		// 	04	4		5
	Value.HwMajorVersion = 2;	// 	03	3		1
	Value.HwReleaseYear = 2019;	// 	02	2		2015
	Value.Function = 1;			//	01	1		1-6
	Value.Model.Word = 2;		// 	00	0		0-3
}
s16 main(void){
	io_init();
	timer1_init();
	timer2_init();
	timer3_init();
	timer4_init();
	rtc_init_ISL();
	ram_init();
	uart2_init();
	int0_init();
	TPIC6B595_init();
	while(1){
		
		}
	return 0;
}

