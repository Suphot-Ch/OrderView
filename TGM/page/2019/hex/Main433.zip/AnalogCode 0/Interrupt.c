#include <p30f4011.h>
#include <stdio.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"
	
void INT0_handle(void){
	if(Status.Main){
		IrData.TimeOut=0;
		switch(IrData.Status){
			case 0:
				_T2ON=DIS;	
				Flag.IrDecode=SET;
				IrData.Status=SET;
				break;
			case 1:
				IrData.ByteCount=CLR;
				_T2ON=EN;	
				IrData.Status=2;	
				break;
			case 2:
				IrData.Buffer[IrData.ByteCount++]=TMR2;	
				break;
		}
		TMR2=CLR;	
	}
}
void U2RX_handle(u8 rxbuffer){
	if(!Flag.Frx){ 
		Flag.Frx=1;
		Modbus.ByteReq=0;
	}
	Modbus.RxTimeOut=CLR;
	Modbus.ReqBuf[Modbus.ByteReq++]=rxbuffer;
	if(Modbus.ByteReq>128) Modbus.ByteReq=CLR;
}
void U2TX_handle(void){
	//if(bic(U2STA, BIT9)){
		if(Modbus.ByteRsp){
			Modbus.ByteRsp--;
			U2TXREG=*MB_Dptr++;	
		}
		else{
			Modbus.TxTimeOut=0;
			Flag.Frx=0;
			//Modbus.ByteRsp=0;
			rx_en();
		}
	//}
}
void TMR3_handle(void){
	switch(Status.Main){
		case INIT:
			break;
		default:
			get_analog(ADC.channel);
			break;
	}
}
void TMR4_handle(void){
	switch(Status.Main){
		case INIT:
			break;
		case OPERATE:
			break;
		default:
			break;
	}
}
void TMR1_handle(void){
	switch(Status.Main){
		case INIT:
			Flag.Edit = 0;
			Flag.BlinkEn = 0;
			if(++Value.Time1Sec>=TIME1SEC){
				Value.Time1Sec=0;
				if(Flag.Logo >= 3)operate_mode();
				Flag.Logo++;
			}
			break;
		default:
			ir_decode();	
			check_cal_analog();
			AlarmOutput();
			if(SumtimeOver<2160000)SumtimeOver++;
//			modbus();
//			backGround();
//			mb_req();
//			get_analog();
//			get_analog(0);
//			tcd();
//			read_rtc();
			break;
	}
	update_segment_page[Status.Main]();
	TPIC6B595_scan();
}
void _ISR _INT0Interrupt(void){
		_INT0IF^=_INT0IF;
		INT0_handle();
}
void _ISR _U2RXInterrupt(void){
	/*Add your code here*/
		_U2RXIF^=_U2RXIF;
		U2RX_handle(U2RXREG);
}
void _ISR _T4Interrupt(void){
	/*Add your code here*/
		_T4IF^=_T4IF;
		TMR4_handle();
		
		//TPIC6B595_LATCH(SegmentData);
}
void _ISR _T1Interrupt(void){
	/*Add your code here*/
		_T1IF^=_T1IF;
		TMR1_handle();
		//	TimeUpdate=CLR;
		//	if(++TestCount>=10000) TestCount=CLR;
		//}
}
void _ISR _T2Interrupt(void){
	/*Add your code here*/
		_T2IF^=_T2IF;
		//if(++TimeUpdate>=10) TimeUpdate=0;
		//display_1();
}
void _ISR _U2TXInterrupt(void){
	/*Add your code here*/
	_U2TXIF^=_U2TXIF;	
	U2TX_handle();
}
void _ISR _T3Interrupt(void){
	/*Add your code here*/
		_T3IF^=_T3IF;
		TMR3_handle();
		//if(++TimeUpdate>=10) TimeUpdate=0;
		//display_1();
}


