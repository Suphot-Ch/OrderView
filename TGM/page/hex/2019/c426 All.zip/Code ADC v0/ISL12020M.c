#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

#if 1
#ifndef _ISL12020M
#define	ISL12020M_R		0xDF
#define	ISL12020M_W		0xDE
enum{
	SC_REG,
	MIN_REG,
	HR_REG,
	DT_REG,
	MO_REG,
	YR_REG,
	DW_REG,
	SR_REG,
	INT_REG
};
#endif

void delayxNop(void){
	Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	//Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
}
u8 convert_read_Fix(u8 val , u8 add){
	switch(add){
		case SECONDS_REG:
		case MINUTES_REG:
		case DATE_REG:
		case MONTH_REG:
		case YEAR_REG:
//		case HOURS_REG:
			val=(val/0x10)*10+(val%0x10);
			break;
		case HOURS_REG:
			val%=0x80;
			val=(val/0x10)*10+(val%0x10);
			break;
		}
	return val;
}

u8 convert_write_Fix(u8 val, u8 add){
	u8 dat;
	switch(add){
		case SECONDS_REG:
		case MINUTES_REG:
		case DATE_REG:
		case MONTH_REG:
		case YEAR_REG:
//		case HOURS_REG:
			dat = ((val/10)*0x10)+(val%10);
			return ((val/10)*0x10)+(val%10);
			break;
		case HOURS_REG:
			dat = (((val/10)*0x10)+(val%10))|0x80;
			return (((val/10)*0x10)+(val%10))|0x80;
			break;
		}
	
}
void convert_read(void){
	RTC.Seconds=(RTC.Seconds/0x10)*10+(RTC.Seconds%0x10);
	RTC.Minutes=(RTC.Minutes/0x10)*10+(RTC.Minutes%0x10);
	RTC.Hours=RTC.Hours&0x3F;
	RTC.Hours=(RTC.Hours/0x10)*10+(RTC.Hours%0x10);
	RTC.Date=(RTC.Date/0x10)*10+(RTC.Date%0x10);
	RTC.Month=(RTC.Month/0x10)*10+(RTC.Month%0x10);
	RTC.Year=(RTC.Year/0x10)*10+(RTC.Year%0x10);
}
void convert_write(void){
	RTC.Seconds=(RTC.Seconds/10)*0x10+(RTC.Seconds%10);
	RTC.Minutes=(RTC.Minutes/10)*0x10+(RTC.Minutes%10);
	RTC.Hours=(RTC.Hours/10)*0x10+(RTC.Hours%10);
	RTC.Hours|=0x80;
	RTC.Date=(RTC.Date/10)*0x10+(RTC.Date%10);
	RTC.Month=(RTC.Month/10)*0x10+(RTC.Month%10);
	RTC.Year=(RTC.Year/10)*0x10+(RTC.Year%10);
}
void start_bit(void){
	SDAIO=0;
	SDA=1;
	SCL=1;
	delayxNop();
	delayxNop();
	SDA=0;
	delayxNop();
	SCL=0;
}
void stop_bit(void){
	SDAIO=0;
	SDA=0;
	SCL=1;
	delayxNop();
	delayxNop();
	SDA=1;
	delayxNop();
	SCL=0;
}
char ack(void){
	SDAIO=0;
	SDA=1;
	SDAIO=1;
	delayxNop();
	SCL=1;
	delayxNop();
	//while(SDA) continue;
	if(SDA){
		return 0;
	}
	else{
		SCL=0;
		delayxNop();
		return 1;
	}
}
void m_ack(void){
	SDAIO=0;
	SDA=0;
	delayxNop();
	SCL=1;
	delayxNop();
	SCL=0;
	delayxNop();
}
void send_byte(unsigned char value){
	unsigned char i;
	SDAIO=0;
	for(i=0x80;i>0;i/=2){
		SCL=0;
		delayxNop();
		SDA=value&i ? 1 : 0;
		delayxNop();
		SCL=1;
	}
	delayxNop();
	SCL=0;
	//SDA=0;
}
unsigned char receive_byte(void){
	unsigned char i, value;
	value=0;
	SDAIO=1;
	SCL=0;
	for(i=0;i<8;i++){
		delayxNop();
		SCL=1;
		value<<=1;
		value+=SDA ? 1 : 0;
		delayxNop();
		SCL=0;
	}
	SCL=0;
	return value;
}
void write_current_time_Fix(unsigned char dptr , u8 add){	
	start_bit();
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(add);
	if(!ack()){return;}
	send_byte(convert_write_Fix(dptr,add));
	if(!ack()){return;}
	stop_bit();
}
void write_current_time(unsigned char *dptr){
	convert_write();	
	start_bit();
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(SC_REG);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	send_byte(*dptr++);
	if(!ack()){return;}
	stop_bit();
}
void bit_WRTC_is_clr(void){

	start_bit();
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(INT_REG);
	if(!ack()){return;}
	start_bit();		
	send_byte(ISL12020M_R);
	if(!ack()){return;}
	RTC.Interrupt=receive_byte();
	stop_bit();	
}
void rtc_init(void){	
#if 1	
	bit_WRTC_is_clr();delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	bit_WRTC_is_clr();delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	bit_WRTC_is_clr();
	if(!(RTC.Interrupt&0x40)){
		RTC.Seconds=0;
		RTC.Minutes=0;
		RTC.Hours=8;
		RTC.Date=1;
		RTC.Month=January;
		RTC.Year=15;
		RTC.Day=Tuesday;
		start_bit();
		send_byte(ISL12020M_W);
		if(!ack()){return;}
		send_byte(INT_REG);
		if(!ack()){return;}
		send_byte(0x41);
		if(!ack()){return;}
		stop_bit();
		write_current_time(&RTC.Seconds);
	}	
#else
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();

	start_bit();
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(INT_REG);
	if(!ack()){return;}
	send_byte(0x41);
	if(!ack()){return;}
	stop_bit();
	delayxNop();delayxNop();delayxNop();delayxNop();delayxNop();
	start_bit();
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(INT_REG);
	if(!ack()){return;}
	send_byte(0x41);
	if(!ack()){return;}
	stop_bit();
#endif
}
void read_day(void){
	unsigned char *dptr;
	
	dptr=&RTC.Day;	
	start_bit();		
	send_byte(ISL12020M_W);
	if(!ack()){return;}
	send_byte(DW_REG);
	if(!ack()){return;}
	start_bit();		
	send_byte(ISL12020M_R);
	if(!ack()){return;}
	*dptr=receive_byte();
	//m_ack();
	stop_bit();
//}
}
void read_rtc(void){
	unsigned char i, *dptr;
	
		if(++TimeUpdateRTC>=25){
			TimeUpdateRTC=0;
			dptr=&RTC.Seconds;
			start_bit();		
			send_byte(ISL12020M_W);
			if(!ack()){return;}
			send_byte(SC_REG);
			if(!ack()){return;}
			start_bit();		
			send_byte(ISL12020M_R);
			if(!ack()){return;}
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			m_ack();	
			*dptr++=receive_byte();
			stop_bit();
			convert_read();
		}

}
#endif

