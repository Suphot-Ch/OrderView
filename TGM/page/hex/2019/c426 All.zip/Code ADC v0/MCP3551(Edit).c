#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

enum{Lo, Hi};

void clk(void){
	delayxNop();
	SCL=Hi;
	delayxNop();
	SCL=Lo;
}

void mux(void){

	if(Value.Channel==0){
		CD4051_A=0;
		CD4051_B=0;
		}
	if(Value.Channel==1){
		CD4051_A=0;
		CD4051_B=1;
		}
	if(Value.Channel==2){
		CD4051_A=1;
		CD4051_B=0;
		}
	if(Value.Channel==3){
		CD4051_A=1;
		CD4051_B=1;
		}

//	CD4051_A=(ADC.channel&0x01) ? 1 : 0;
//	CD4051_B=(ADC.channel&0x02) ? 1 : 0;
}

#if 0
void t_sample(void){
	SDAIO=OUTPUT;
	SDA=Hi;
	SCL=Hi;
	delayxNop();
	SCL=Lo;
	clk();
	clk();
}
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;
	
	ADC_CS=Lo;
	delayxNop();
	t_sample();
	SDAIO=INPUT;
	clk();
	delayxNop();
	value=CLR;
	for(i=0;i<22;i++){
		value<<=1;
		SCL=Lo;
		delayxNop();
		if(SDA) value|=1;
		SCL=Hi;	
		delayxNop();
	}
	delayxNop();
	ADC_CS=Hi;
	return value;
}
#endif
unsigned long MCP3551_read(u8 channel){
	unsigned long i, value;

	value=0;
	for(i=0;i<24;i++){
		value<<=1;
		SCL=Hi;
		delayxNop();
		if(SDA) value|=1;
		delayxNop();
		SCL=Lo;	
		delayxNop();
		delayxNop();
	}
	delayxNop();
	
	ADC_CS=Hi;
	return value;
}
void get_analog(channel){
	float scale[3], span[3], zero[3], output[3];
	u8 i, j;
	u32 temp[3];
	u32 buffer[3]; 
	//ADC.channel=1;  
	mux();

	if(++ADC.TimeOunt>=5){
		ADC.TimeOunt=CLR;

		SDAIO=INPUT;
		ADC_CS=Lo;
		delayxNop();
		SCL=Lo;
		delayxNop();
		delayxNop();
		
		if(SDA==0){ 
			ADC.Data[ADC.channel][ADC.Sample++]=MCP3551_read(ADC.channel);
			if(ADC.Data[ADC.channel][ADC.Sample]&0x400000){
			}
			else if(ADC.Data[ADC.channel][ADC.Sample]&0x800000){
			}
			else{
				if(ADC.Sample>=4){
					ADC.Sample=0; 
#if 0				
					for(i=0;i<3;i++){
						for(j=i+1;j<4;j++){
							if(ADC.Data[ADC.channel][i]>ADC.Data[ADC.channel][j]){
								temp[ADC.channel]=ADC.Data[ADC.channel][j];
								ADC.Data[ADC.channel][j]=ADC.Data[ADC.channel][i];
								ADC.Data[ADC.channel][i]=temp[ADC.channel]; 
							}
						}
					}
					buffer[ADC.channel]=0;
					buffer[ADC.channel]=ADC.Data[ADC.channel][1]+ADC.Data[ADC.channel][2]; 
					
					for(i=0;i<3;i++) ADC.Buffer[ADC.channel][i]=ADC.Buffer[ADC.channel][i+1];
					ADC.Buffer[ADC.channel][3]=buffer[ADC.channel]/2;
					buffer[ADC.channel]=0;
					for(i=0;i<4;i++) buffer[ADC.channel]+=ADC.Buffer[ADC.channel][i];
					ADC.Filter[ADC.channel]=buffer[ADC.channel]/4;
					ADC.Filter[ADC.channel]>>=4;					

					
					output[ADC.channel]=ADC.Filter[ADC.channel];
		                     
					span[Value.Channel]=Value.SystemFullScale[Value.Channel].LWord;
					zero[Value.Channel]=Value.SystemZeroScale[Value.Channel].LWord;

					output[Value.Channel]-=zero[Value.Channel];
					output[ADC.channel]=output[Value.Channel]/(span[Value.Channel]-zero[Value.Channel]);

					Flag.PVLoLimit=0;
					Flag.PVHiLimit=0;
					
					/*if(output[Value.Channel]<-0.01) Flag.PVLoLimit=1;
					else if(output[Value.Channel]>1.01) Flag.PVHiLimit=1;
					else{
						output[ADC.channel]=output[Value.Channel]*(Value.ScaleHiLimit[Value.Channel].LWord-Value.ScaleLoLimit[Value.Channel].LWord)+Value.ScaleLoLimit[Value.Channel].LWord;
						}*/
							Value.Channel=1;
							output[ADC.channel]=output[ADC.channel]*(Value.ScaleHiLimit[ADC.channel].LWord-Value.ScaleLoLimit[ADC.channel].LWord)+Value.ScaleLoLimit[ADC.channel].LWord;
							Value.PV[ADC.channel].LWord=(u32)output[ADC.channel];	

						//if(Value.PV.LWord>99999){ Flag.PVHiLimit=1;}
						//else if(Value.PV.LWord<-19999){ Flag.PVLoLimit=1;}
						//else{ Flag.PVHiLimit=0; Flag.PVLoLimit=0;}
						if(++ADC.channel>2) ADC.channel=0; 
						
				}
			}
		}
#endif
		}
}

