#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"

extern u8 XCTTotal;
extern f32 Xpct;
const unsigned long Devide2[]={10,		1,		0,		0,		0,		0,		0};
const unsigned long Devide3[]={100,		10,		1,		0,		0,		0,		0};
const unsigned long Devide4[]={1000,	100,		10,		1,		0,		0,		0};
const unsigned long Devide5[]={10000,	1000,	100,		10,		1,		0,		0};
const unsigned long Devide6[]={100000,	10000,	1000,	100,		10,		1,		0};
const u8 NUM_MAP[]={
	/*b a f g e d c dp*/
	FONT_0,
	FONT_1,
	FONT_2,
	FONT_3,
	FONT_4,
	FONT_5,
	FONT_6,
	FONT_7,
	FONT_8,
	FONT_9,
	FONT_A,
	FONT_B,
	FONT_C,
	FONT_D,
	FONT_E,
	FONT_F,
	FONT_MINUS
};
const u8 NUM_MAP_[]={
	/*b a f g e d c dp*/
	FONT_0_,
	FONT_1_,
	FONT_2_,
	FONT_3_,
	FONT_4_,
	FONT_5_,
	FONT_6_,
	FONT_7_,
	FONT_8_,
	FONT_9_,
	FONT_A_,
	FONT_B_,
	FONT_C_,
	FONT_D_,
	FONT_E_,
	FONT_F_,
	FONT_MINUS_
};
const u8 ASCII_CHR[]={
	'0',
	'1',
	'2',
	'3',
	'4',
	'5',
	'6',
	'7',
	'8',
	'9',
	'A',
	'B',
	'C',
	'D',
	'E',
	'F'		
};

void display_page0(void);
void display_page1(void);
void display_page2(void);
void display_page3(void);
void display_page4(void);
void display_page5(void);
void display_page6(void);
void display_page7(void);
void display_page8(void);
void display_page9(void);
void display_page10(void);
void display_page11(void);
void display_page12(void);
void display_page13(void);
void display_page14(void);
void display_page15(void);
void display_page16(void);
void display_page17(void);
void display_page18(void);
void display_page19(void);
void display_page20(void);
void display_page21(void);
void display_page22(void);
void display_page23(void);
void display_page24(void);
void display_page25(void);
void display_page26(void);
void display_page27(void);
void display_page28(void);
void display_page29(void);

void (*update_segment_page[])(void)={
	display_page0,     								// = 0
	display_page1,     								// = 1
	display_page2,     								// = 2
	display_page3,     								// = 3
	display_page4,     								// = 4
	display_page5,     								// = 5
	display_page6,     								// = 6
	display_page7,     								// = 7
	display_page8,     								// = 8
	display_page9,     								// = 9
	display_page10,     								// = 10
	display_page11,     								// = 11
	display_page12,     								// = 12
	display_page13,     								// = 13
	display_page14,     								// = 14
	display_page15,     								// = 15
	display_page16,     								// = 16
	display_page17,     								// = 17
	display_page18,     								// = 18
	display_page19,     								// = 19
	display_page20,     								// = 20
	display_page21,     								// = 21
	display_page22,     								// = 22
	display_page23,     								// = 23
	display_page24,     								// = 24
	display_page25,     								// = 25
	display_page26,     								// = 26
	display_page27,     								// = 27
	display_page28,     								// = 28
	display_page29,     								// = 29
	
};

void blink(void){
	if(Flag.BlinkEn){
		if(++TimeBlink>=TBLINK){
			TimeBlink=CLR;
			Flag.Blink=Flag.Blink ? 0 : 1;
		}
	}
}
void set_char_S3(u8 a, u8 b, u8 d, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment=d;
	
}
void set_char_S4(u8 a, u8 b, u8 c, u8 d, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment=d;
	
}
void set_char_S5(u8 a, u8 b, u8 c, u8 d, u8 e, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;
	*segment=e;	
}
void set_char_S6(u8 a, u8 b, u8 c, u8 d, u8 e, u8 f, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;\
	*segment++=e;
	*segment=f;
	
}
void set_num_S_r2(s16 dec , u8 dp, u8 *segment){
	u8 Data[5],sign;
	s16 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
			
	Data[0]=Dat/Devide2[0]%10;
	Data[1]=Dat/Devide2[1]%10;
	
	if(!sign)		*segment++=(dp==1) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	else			*segment++=(dp==1) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_DP|FONT_MINUS) : ((dp>1) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_MINUS: NUM_MAP[Data[0]]|FONT_MINUS));
				*segment=NUM_MAP[Data[1]];
}
void set_num_S_r3(s16 dec , u8 dp, u8 *segment){
	u8 Data[5],sign;
	s16 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
			
	Data[0]=Dat/Devide3[0]%10;
	Data[1]=Dat/Devide3[1]%10;
	Data[2]=Dat/Devide3[2]%10;
	
	if(!sign)	*segment++=(dp==2) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	else		*segment++=(dp==2) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_DP|FONT_MINUS) : ((dp>2) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_MINUS: NUM_MAP[Data[0]]|FONT_MINUS));
				*segment++=(dp==1) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1]? FONT_BLANK : NUM_MAP[Data[1]]));
				*segment=NUM_MAP[Data[2]];
}
void set_num_S_r4(s16 dec , u8 dp, u8 *segment){
	u8 Data[5],sign;
	s16 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
			
	Data[0]=Dat/Devide4[0]%10;
	Data[1]=Dat/Devide4[1]%10;
	Data[2]=Dat/Devide4[2]%10;
	Data[3]=Dat/Devide4[3]%10;
	
	if(!sign){
		*segment++=(dp==3) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==3) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_DP|FONT_MINUS) : ((dp>3) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_MINUS: NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==2) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK: NUM_MAP[Data[1]]));
	*segment++=(dp==1) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment=NUM_MAP[Data[3]];

}

void set_num_S_r5(s32 dec , u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
			
	Data[0]=Dat/Devide5[0]%10;
	Data[1]=Dat/Devide5[1]%10;
	Data[2]=Dat/Devide5[2]%10;
	Data[3]=Dat/Devide5[3]%10;
	Data[4]=Dat/Devide5[4]%10;
	
	if(!sign){
		*segment++=(dp==4) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==4) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==3) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment++=(dp==2) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment++=(dp==1) ? (!Data[3] ? FONT_0|FONT_DP : NUM_MAP[Data[3]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[3]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3] ? FONT_BLANK : NUM_MAP[Data[3]]));
	*segment=NUM_MAP[Data[4]];

}	

void set_num_S_r6(s32 dec , u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
			
	Data[0]=Dat/Devide6[0]%10;
	Data[1]=Dat/Devide6[1]%10;
	Data[2]=Dat/Devide6[2]%10;
	Data[3]=Dat/Devide6[3]%10;
	Data[4]=Dat/Devide6[4]%10;
	Data[5]=Dat/Devide6[5]%10;
	
	if(!sign){
		*segment++=(dp==5) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>5) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==5) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>5) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==4) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>4) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment++=(dp==3) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment++=(dp==2) ? (!Data[3] ? FONT_0|FONT_DP : NUM_MAP[Data[3]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[3]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3] ? FONT_BLANK : NUM_MAP[Data[3]]));
	*segment++=(dp==1) ? (!Data[4] ? FONT_0|FONT_DP : NUM_MAP[Data[4]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[4]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3]&&!Data[4] ? FONT_BLANK : NUM_MAP[Data[4]]));
	*segment=NUM_MAP[Data[5]] ;

}
void display_edit3(u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=Flag.Sign;
	Data[0]=EditBuffer[0];
	Data[1]=EditBuffer[1];
	Data[2]=EditBuffer[2];
	
	if(!sign){
		*segment++=(dp==2) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==2) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>2) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==1) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment=NUM_MAP[Data[2]] ;
}
void display_edit4(u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=Flag.Sign;
	Data[0]=EditBuffer[0];
	Data[1]=EditBuffer[1];
	Data[2]=EditBuffer[2];
	Data[3]=EditBuffer[3];
	
	if(!sign){
		*segment++=(dp==3) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==3) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>3) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==2) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment++=(dp==1) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment=NUM_MAP[Data[3]] ;
}
void display_edit5(u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=Flag.Sign;
	Data[0]=EditBuffer[0];
	Data[1]=EditBuffer[1];
	Data[2]=EditBuffer[2];
	Data[3]=EditBuffer[3];
	Data[4]=EditBuffer[4];
	
	if(!sign){
		*segment++=(dp==4) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==4) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==3) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment++=(dp==2) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment++=(dp==1) ? (!Data[3] ? FONT_0|FONT_DP : NUM_MAP[Data[3]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[3]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3] ? FONT_BLANK : NUM_MAP[Data[3]]));
	*segment=NUM_MAP[Data[4]] ;

}
void display_edit6(u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=Flag.Sign;
	Data[0]=EditBuffer[0];
	Data[1]=EditBuffer[1];
	Data[2]=EditBuffer[2];
	Data[3]=EditBuffer[3];
	Data[4]=EditBuffer[4];
	Data[5]=EditBuffer[5];
	
	if(!sign){
		*segment++=(dp==5) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>5) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	}
	else{
		*segment++=(dp==5) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>5) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
	}
	*segment++=(dp==4) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>4) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
	*segment++=(dp==3) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
	*segment++=(dp==2) ? (!Data[3] ? FONT_0|FONT_DP : NUM_MAP[Data[3]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[3]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3] ? FONT_BLANK : NUM_MAP[Data[3]]));
	*segment++=(dp==1) ? (!Data[4] ? FONT_0|FONT_DP : NUM_MAP[Data[4]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[4]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3]&&!Data[4] ? FONT_BLANK : NUM_MAP[Data[4]]));
	*segment=NUM_MAP[Data[5]] ;

}
void display_page0(void){
	blink();
	switch(Flag.Logo){
	case 0:
		set_char_S3(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_SPEED]);
		set_char_S6(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_TARGET]);
		set_char_S6(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_ACTUAL1]);
		break;
	case 1:
		set_char_S3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_C, FONT_4, FONT_2, FONT_7, &SegmentData[SEG_TARGET]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		break;
	case 2:
		set_char_S3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_V, FONT_0, &SegmentData[SEG_TARGET]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		break;
	case 3:
		set_char_S3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		break;
	}
}

void display_page1(void){	// OPERATE_MODE
#if 1
	if(!Flag.Edit){
		set_char_S3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		if(Flag.BlinkEn){
			if(++TimeBlink >= TBLINK){
				TimeBlink = CLR;
				Flag.Edit = 1;
				}
			}
		}
	else {
		if(Value.Speed>= 1000)set_char_S3(FONT_MINUS, FONT_MINUS, FONT_MINUS, &SegmentData[SEG_SPEED]);
		else set_num_S_r3(Value.Speed,	Value.xDecimalPoint,	&SegmentData[SEG_SPEED]);
		
		set_num_S_r6(Value.Target,	Value.DecimalPoint,	&SegmentData[SEG_TARGET]);
		set_num_S_r6(Value.Actual1,	Value.DecimalPoint,	&SegmentData[SEG_ACTUAL1]);
		}
	SegmentData[SEG_TARGET+5] = !_RB2? SegmentData[SEG_TARGET+5]|FONT_DP:SegmentData[SEG_TARGET+5];
	SegmentData[SEG_ACTUAL1+5] = !_RB1? SegmentData[SEG_ACTUAL1+5]|FONT_DP:SegmentData[SEG_ACTUAL1+5];
#endif
}
void display_page2(void){	// EDIT_CIRCUMFERENCE
/*
	set_char_S5(FONT_T, FONT_I, FONT_M, FONT_E, FONT_R, &SegmentData[SEG_SPEED]);
	if(!Flag.Edit) {
		if(Value.Actual3/60<999){
			set_num_S_r3(Value.Actual3/60,	0,	&SegmentData[SEG_TARGET]);
			SegmentData[SEG_TARGET+2] = SegmentData[SEG_TARGET+2]|FONT_DP;
			SegmentData[SEG_TARGET+3] = NUM_MAP[Value.Actual3%60/10];
			SegmentData[SEG_TARGET+4] = NUM_MAP[Value.Actual3%60%10];
			}
		else{
			set_num_S_r5(Value.Actual3/60,	0,	&SegmentData[SEG_TARGET]);
			}
		}
	else		
		set_char_S5(FONT_BLANK, FONT_R, FONT_S, FONT_T, FONT_BLANK, &SegmentData[SEG_TARGET]);
		*/
}
void display_page3(void){	// EDIT_MUL_MODE

	blink();
//	if(!Flag.Edit)	
		set_char_S3(FONT_M, FONT_U, FONT_L, &SegmentData[SEG_SPEED]);
//	else
		display_edit6(0,&SegmentData[SEG_TARGET]);
	if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);

	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page4(void){	// EDIT_DIV_MODE

	blink();
//    if(!Flag.Edit)	
		set_char_S3(FONT_D, FONT_I, FONT_V, &SegmentData[SEG_SPEED]);
//	else
		display_edit6(0,&SegmentData[SEG_TARGET]);
	if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);

	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page5(void){	// EDIT_DP_MODE
}
void display_page6(void){	// EDIT_INPUT_DELAY

	blink();
//	if(!Flag.Edit)	
		set_char_S3(FONT_I, FONT_N, FONT_D, &SegmentData[SEG_SPEED]);
//	else
		display_edit6(2,&SegmentData[SEG_TARGET]);
	if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);

	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page7(void){	// EDIT_ADDRESS_MODE
/*
	blink();
	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_A, FONT_D, FONT_D, FONT_BLANK, &SegmentData[SEG_SPEED]);
	display_edit6(2,&SegmentData[SEG_TARGET]);
	if(Flag.Edit&&Flag.Blink)set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
*/
}
void display_page8(void){	// EDIT_BAUDRATE_MODE
/*
	blink();
	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_B, FONT_P, FONT_S, FONT_BLANK, &SegmentData[SEG_SPEED]);
	switch(EditBuffer[EDIT_LENGTH-1]){
		case BR4800:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_4|FONT_DP, FONT_8, 	&SegmentData[SEG_TARGET]);	break;
		case BR9600:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_9|FONT_DP, FONT_6, 	&SegmentData[SEG_TARGET]);	break;
		case BR19200:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_1, FONT_9|FONT_DP, FONT_2, 	&SegmentData[SEG_TARGET]);	break;
		case BR38400:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_3, FONT_8|FONT_DP, FONT_4, 	&SegmentData[SEG_TARGET]);	break;
		case BR57600:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_5, FONT_7|FONT_DP, FONT_6, 	&SegmentData[SEG_TARGET]);	break;
		}
	if(Flag.Edit&&Flag.Blink)set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
*/
}
void display_page9(void){	// EDIT_PARITY_MODE
/*
	blink();
	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_C, FONT_O, FONT_M, FONT_M, &SegmentData[SEG_SPEED]);
	switch(EditBuffer[EDIT_LENGTH -1]){
		case b8n1:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_B, FONT_8, FONT_N, FONT_1, &SegmentData[SEG_TARGET]);		break;
		case b8o1:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_B, FONT_8, FONT_O, FONT_1, &SegmentData[SEG_TARGET]);		break;
		case b8e1:	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_B, FONT_8, FONT_E, FONT_1, &SegmentData[SEG_TARGET]);		break;
		}
	if(Flag.Edit&&Flag.Blink)set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
*/
}
void display_page10(void){	// EDIT_DELAY_POLLS_MODE
}
void display_page11(void){	// EDIT_RESPONSE_TIMEOUT_MODE
}
void display_page12(void){	// CAL_ANALOG_MODE 
}
void display_page13(void){	// IDLE_MODE
	set_char_S3(FONT_MINUS, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
	set_char_S6(FONT_MINUS, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S6(FONT_MINUS, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page14(void){   // EDIT_TARGET

	blink();
	display_edit6(Value.DecimalPoint,&SegmentData[SEG_TARGET]);
	if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);

}
void display_page15(void){	// EDIT_ACTUAL1

	blink();
	display_edit6(Value.DecimalPoint,&SegmentData[SEG_ACTUAL1]);
	if(Flag.Edit&&Flag.Blink)set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page16(void){	// EDIT_INPUT_TYPE
		blink();
	//	if(!Flag.Edit)	
			set_char_S3(FONT_BLANK, FONT_T, FONT_G, &SegmentData[SEG_SPEED]);
	//	else{
		switch(EditBuffer[EDIT_LENGTH -1]){
			case 0:	set_char_S6(FONT_I, FONT_N, FONT_BLANK, FONT_BLANK, FONT_A, FONT_B, &SegmentData[SEG_TARGET]);		break;
			case 1:	set_char_S6(FONT_I, FONT_N, FONT_BLANK, FONT_E, FONT_N, FONT_C, &SegmentData[SEG_TARGET]);		break;
			}
	//	}
		if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page17(void){	// EDIT_CIRCUMFERENCE
	
		blink();
	//	if(!Flag.Edit)	
			set_char_S3(FONT_BLANK, FONT_C, FONT_F, &SegmentData[SEG_SPEED]);
	//	else
			display_edit6(0,&SegmentData[SEG_TARGET]);
		if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	
		set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page18(void){	// EDIT_CYCLETIME

	blink();
	set_char_S3(FONT_BLANK,  FONT_C, FONT_T, &SegmentData[SEG_SPEED]);	
	display_edit6(2,&SegmentData[SEG_TARGET]);
	if(Flag.Edit&&Flag.Blink)set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
void display_page19(void){	// EDIT_TIMERESET 
}
void display_page20(void){	// EDIT_SETTIME
/*
	blink();
	set_char_S4(FONT_T, FONT_I, FONT_M, FONT_E, &SegmentData[SEG_SPEED]);
	SegmentData[SEG_TARGET+0] = NUM_MAP[EditBuffer[0]];
	SegmentData[SEG_TARGET+1] = NUM_MAP[EditBuffer[1]]|FONT_DP;
	SegmentData[SEG_TARGET+2] = NUM_MAP[EditBuffer[2]];;
	SegmentData[SEG_TARGET+3] = NUM_MAP[EditBuffer[3]];	
	
	if(Flag.Edit&&Flag.Blink){
		switch(EditNum){
			case 1:	SegmentData[SEG_TARGET+0] = 0x00;break;
			case 2:	SegmentData[SEG_TARGET+1] = 0x00|FONT_DP;;break;
			case 3:	SegmentData[SEG_TARGET+2] = 0x00;break;
			case 4:	SegmentData[SEG_TARGET+3] = 0x00;break;
			}
		}
	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
*/
}

void display_page21(void){	// EDIT_BREAK_OFF
/*
	blink();

	set_char_S4(FONT_BLANK, FONT_B, FONT_R, FONT_K, &SegmentData[SEG_TOTAL]);
	set_char_S4(FONT_BLANK, FONT_O, FONT_F, FONT_F, &SegmentData[SEG_SPEED]);
	
	SegmentData[8] = FONT_BLANK;
	SegmentData[9] = FONT_BLANK;
	SegmentData[10] = !Flag.Edit&&Flag.Blink? FONT_BLANK: NUM_MAP[Value.Break_Channel/10%10];
	SegmentData[11] = !Flag.Edit&&Flag.Blink? FONT_BLANK: NUM_MAP[Value.Break_Channel%10];

	SegmentData[12] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  EDIT_LENGTH - n]];
	SegmentData[13] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  1]]|FONT_DP;
	SegmentData[14] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  2]];
	SegmentData[15] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  3]];

	if(Flag.Edit&&Flag.Blink){
		switch(EditNum){
			case 1:	SegmentData[12] = 0x00;break;
			case 2:	SegmentData[13] = FONT_DP;break;
			case 3:	SegmentData[14] = 0x00;break;
			case 4:	SegmentData[15] = 0x00;break;
			}
		}
*/
}
void display_page22(void){	// EDIT_BREAK_ON
/*
	blink();

	set_char_S4(FONT_BLANK, FONT_B, FONT_R, FONT_K, &SegmentData[SEG_TOTAL]);
	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_O, FONT_N, &SegmentData[SEG_SPEED]);
	
	SegmentData[8] = FONT_BLANK;
	SegmentData[9] = FONT_BLANK;
	SegmentData[10] = !Flag.Edit&&Flag.Blink? FONT_BLANK: NUM_MAP[Value.Break_Channel/10%10];
	SegmentData[11] = !Flag.Edit&&Flag.Blink? FONT_BLANK: NUM_MAP[Value.Break_Channel%10];

	SegmentData[12] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  EDIT_LENGTH - n]];
	SegmentData[13] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  1]]|FONT_DP;
	SegmentData[14] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  2]];
	SegmentData[15] = NUM_MAP[EditBuffer[EDIT_LENGTH - n -  3]];

	if(Flag.Edit&&Flag.Blink){
		switch(EditNum){
			case 1:	SegmentData[12] = 0x00;break;
			case 2:	SegmentData[13] = FONT_DP;break;
			case 3:	SegmentData[14] = 0x00;break;
			case 4:	SegmentData[15] = 0x00;break;
			}
		}
*/
}
void display_page23(void){	// EDIT_BREAK_EN
/*
	blink();

	set_char_S4(FONT_BLANK, FONT_B, FONT_R, FONT_K, &SegmentData[SEG_TOTAL]);
	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	
	if(Value.Break_EN)	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_E, FONT_N, &SegmentData[SEG_SPEED]);
	else 				set_char_S4(FONT_BLANK, FONT_D, FONT_I, FONT_S, &SegmentData[SEG_SPEED]);

	if(Flag.Edit&&Flag.Blink)set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_SPEED]);
*/	
}
void display_page24(void){	// EDIT_SETTACTTIME
/*
	blink();
	set_char_S4(FONT_BLANK, FONT_C, FONT_T, FONT_BLANK, &SegmentData[SEG_TOTAL]);
	set_char_S4(FONT_T, FONT_A, FONT_C, FONT_T, &SegmentData[SEG_SPEED]);
	set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	
	display_edit4(2,&SegmentData[SEG_TARGET]);
	if(Flag.Blink&&Flag.Edit)set_char_S4(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
*/
}
void display_page25(void){	//
}
void display_page26(void){	//
}
void display_page27(void){	//
}
void display_page28(void){	//
}
void display_page29(void){	// EDIT_ALS_MODE

	int i;
	blink();	
	if(Value.Channel == 0)			i = Value.SetPointMode1;
	else if(Value.Channel == 1)	i = Value.SetPointMode2;
//	switch(i){
//		case 0:	set_char_S4(FONT_BLANK, FONT_A, FONT_C, FONT_BLANK, &SegmentData[SEG_TARGET]);	break;
//		case 1:	set_char_S4(FONT_BLANK, FONT_T, FONT_G, FONT_BLANK, &SegmentData[SEG_TARGET]);	break;
//		case 2:	set_char_S4(FONT_BLANK, FONT_P, FONT_L, FONT_BLANK, &SegmentData[SEG_TARGET]);	break;
//		}
	
//	if(!Flag.Edit)	
		set_char_S3(FONT_BLANK, FONT_S, FONT_P, &SegmentData[SEG_SPEED]);
//	else
		display_edit6( Value.DecimalPoint,&SegmentData[SEG_TARGET]);
	if(Flag.Blink)	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

}
