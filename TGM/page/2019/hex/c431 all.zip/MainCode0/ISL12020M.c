#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"

#if 1
#ifndef _ISL12020M
#define	ISL12020M_R		0xDF
#define	ISL12020M_W		0xDE
#endif

void delayxRtc(void){
	Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	//Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
}
void convert_read(void){
	RTC.Seconds=(RTC.Seconds/0x10)*10+(RTC.Seconds%0x10);
	RTC.Minutes=(RTC.Minutes/0x10)*10+(RTC.Minutes%0x10);
	RTC.Hours%=0x80;
	RTC.Hours=(RTC.Hours/0x10)*10+(RTC.Hours%0x10);
	RTC.Date=(RTC.Date/0x10)*10+(RTC.Date%0x10);
	RTC.Month=(RTC.Month/0x10)*10+(RTC.Month%0x10);
	RTC.Year=(RTC.Year/0x10)*10+(RTC.Year%0x10);
}
void convert_write(void){
	RTC.Seconds=(RTC.Seconds/10)*0x10+(RTC.Seconds%10);
	RTC.Minutes=(RTC.Minutes/10)*0x10+(RTC.Minutes%10);
	RTC.Hours=(RTC.Hours/10)*0x10+(RTC.Hours%10);
	RTC.Hours|=0x80;
	RTC.Date=(RTC.Date/10)*0x10+(RTC.Date%10);
	RTC.Month=(RTC.Month/10)*0x10+(RTC.Month%10);
	RTC.Year=(RTC.Year/10)*0x10+(RTC.Year%10);
}
void start_bit_rtc(void){
	SDAIO=0;
	SDA=1;
	SCL=1;
	delayxRtc();
	delayxRtc();
	SDA=0;
	delayxRtc();
	SCL=0;
}
void stop_bit_rtc(void){
	SDAIO=0;
	SDA=0;
	SCL=1;
	delayxRtc();
	delayxRtc();
	SDA=1;
	delayxRtc();
	SCL=0;
}
char ack_rtc(void){
	SDAIO=0;
	SDA=1;
	SDAIO=1;
	delayxRtc();
	SCL=1;
	delayxRtc();
	//while(SDA) continue;
	if(SDA){
		return 0;
	}
	else{
		SCL=0;
		delayxRtc();
		return 1;
	}
}
void m_ack_rtc(void){
	SDAIO=0;
	SDA=0;
	delayxRtc();
	SCL=1;
	delayxRtc();
	SCL=0;
	delayxRtc();
}
void send_byte_rtc(unsigned char value){
	unsigned char i;
	SDAIO=0;
	for(i=0x80;i>0;i/=2){
		SCL=0;
		delayxRtc();
		SDA=value&i ? 1 : 0;
		delayxRtc();
		SCL=1;
	}
	delayxRtc();
	SCL=0;
	//SDA=0;
}
unsigned char receive_byte_rtc(void){
	unsigned char i, value;
	value=0;
	SDAIO=1;
	SCL=0;
	for(i=0;i<8;i++){
		delayxRtc();
		SCL=1;
		value<<=1;
		value+=SDA ? 1 : 0;
		delayxRtc();
		SCL=0;
	}
	SCL=0;
	return value;
}
void write_time_rtc(unsigned char add, unsigned char dptr){
//	convert_write();	
	start_bit_rtc();
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(add);
	if(!ack_rtc()){return;}
	send_byte_rtc(dptr);
	if(!ack_rtc()){return;}
	stop_bit_rtc();
}

void write_current_time_rtc(unsigned char *dptr){
	convert_write();	
	start_bit_rtc();
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(SC_REG);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	send_byte_rtc(*dptr++);
	if(!ack_rtc()){return;}
	stop_bit_rtc();
}
void bit_WRTC_is_clr(void){

	start_bit_rtc();
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(INT_REG);
	if(!ack_rtc()){return;}
	start_bit_rtc();		
	send_byte_rtc(ISL12020M_R);
	if(!ack_rtc()){return;}
	RTC.Interrupt=receive_byte_rtc();
	stop_bit_rtc();	
}
void rtc_init_ISL(void){	
#if 1	
	bit_WRTC_is_clr();delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	bit_WRTC_is_clr();delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	bit_WRTC_is_clr();
	if(!(RTC.Interrupt&0x40)){
		RTC.Seconds=0;
		RTC.Minutes=0;
		RTC.Hours=8;
		RTC.Date=1;
		RTC.Month=January;
		RTC.Year=17;
		RTC.Day=Tuesday;
		start_bit_rtc();
		send_byte_rtc(ISL12020M_W);
		if(!ack_rtc()){return;}
		send_byte_rtc(INT_REG);
		if(!ack_rtc()){return;}
		send_byte_rtc(0x41);
		if(!ack_rtc()){return;}
		stop_bit_rtc();
		write_current_time_rtc(&RTC.Seconds);
	}	
#else
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();

	start_bit_rtc();
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(INT_REG);
	if(!ack_rtc()){return;}
	send_byte_rtc(0x41);
	if(!ack_rtc()){return;}
	stop_bit_rtc();
	delayxRtc();delayxRtc();delayxRtc();delayxRtc();delayxRtc();
	start_bit_rtc();
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(INT_REG);
	if(!ack_rtc()){return;}
	send_byte_rtc(0x41);
	if(!ack_rtc()){return;}
	stop_bit_rtc();
#endif
}
void read_day(void){
	unsigned char *dptr;
	
	dptr=&RTC.Day;	
	start_bit_rtc();		
	send_byte_rtc(ISL12020M_W);
	if(!ack_rtc()){return;}
	send_byte_rtc(DW_REG);
	if(!ack_rtc()){return;}
	start_bit_rtc();		
	send_byte_rtc(ISL12020M_R);
	if(!ack_rtc()){return;}
	*dptr=receive_byte_rtc();
	//m_ack_rtc();
	stop_bit_rtc();
//}
}
void read_rtc_ISL(void){
	unsigned char i, *dptr;
	
		if(++TimeUpdateRTC>=25){
			TimeUpdateRTC=0;
			dptr=&RTC.Seconds;
			start_bit_rtc();		
			send_byte_rtc(ISL12020M_W);
			if(!ack_rtc()){return;}
			send_byte_rtc(SC_REG);
			if(!ack_rtc()){return;}
			start_bit_rtc();		
			send_byte_rtc(ISL12020M_R);
			if(!ack_rtc()){return;}
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			m_ack_rtc();	
			*dptr++=receive_byte_rtc();
			stop_bit_rtc();
			convert_read();
		}

}
#endif

