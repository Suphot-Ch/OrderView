#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"
#if 0
enum{Lo, Hi};

void clk(void){
	delayxNop();
	SCL=Hi;
	delayxNop();
	SCL=Lo;
}
#if 0
void t_sample(void){
	SDAIO=OUTPUT;
	SDA=Hi;
	SCL=Hi;
	delayxNop();
	SCL=Lo;
	clk();
	clk();
}
unsigned long MCP3551_read2(u8 channel){
	unsigned long i, value;
	
	ADC_CS=Lo;
	delayxNop();
	t_sample();
	SDAIO=INPUT;
	clk();
	delayxNop();
	value=CLR;
	for(i=0;i<22;i++){
		value<<=1;
		SCL=Lo;
		delayxNop();
		if(SDA) value|=1;
		SCL=Hi;	
		delayxNop();
	}
	delayxNop();
	ADC_CS=Hi;
	return value;
}
#endif
unsigned long MCP3551_read1(u8 channel){
	unsigned long i,j, value[4];
	
	value[0]=0;
	value[1]=0;
	value[2]=0;
	ADC_CS=0;
	SDAIO=0;
	delayxNop();
	SDA=0;
	delayxNop();
	SDAIO=1;
	delayxNop();
	SCL=1;
	for(i=0;i<24;i++){
		clk();
		if(SDA) value[j]|=1;
	}
	SCL=1;
	delayxNop();
	delayxNop();
	ADC_CS=1;
	value[3]|=value[2];
	value[3]=value[0];
	value[3]<<=8;
	value[3]|=value[1];
	value[3]<<=8;
	value[3]=value[3]&0x0000ffff;
	return value[3];
}
unsigned long MCP3551_read(s8 channel){
	unsigned long i, value;
	ADC.ch[0]=channel%0b00000010;
	ADC.ch[1]=channel/0b00000010;
	CD4051_A=ADC.ch[0];
	CD4051_B=ADC.ch[1];
	for(i=0;i<24;i++){
		value<<=1;
		SCL=Hi;
		delayxNop();
		if(SDA) value|=1;
		delayxNop();
		SCL=Lo;	
		delayxNop();
		delayxNop();
	}
	SCL=Hi;
	delayxNop();
	ADC_CS=Hi;
	return value;
}
void get_analog(u8 channel){
	float scale, span, zero, output;
	u8 i, j;
	u32 temp;
	u32 buffer;
	
	if(++ADC.TimeOunt>=5){
		ADC.TimeOunt=CLR;
#if 1
		SDAIO=INPUT;
		ADC_CS=Lo;
		delayxNop();
		SCL=Lo;
		delayxNop();
		delayxNop();
		if(SDA==0){ 
			ADC.Data[ADC.Sample++]=MCP3551_read(channel);
			if(ADC.Data[ADC.Sample++]&0x400000){
			}
			else if(ADC.Data[ADC.Sample++]&0x800000){
			}
			else{
				if(ADC.Sample>=4){
					ADC.Sample=0;
#if 1				
					for(i=0;i<3;i++){
						for(j=i+1;j<4;j++){
							if(ADC.Data[i]>ADC.Data[j]){
								temp=ADC.Data[j];
								ADC.Data[j]=ADC.Data[i];
								ADC.Data[i]=temp;
							}
						}
					}
					buffer=0;
					buffer=ADC.Data[1]+ADC.Data[2];
					
					for(i=0;i<3;i++) ADC.Buffer[i]=ADC.Buffer[i+1];
					ADC.Buffer[3]=buffer/2;
					buffer=0;
					for(i=0;i<4;i++) buffer+=ADC.Buffer[i];
					ADC.Filter=buffer/4;
					ADC.Filter>>=4;
#else					
					buffer=0;
					for(i=0;i<4;i++) buffer+=ADC.Data[i];
					for(i=0;i<2;i++) ADC.Buffer[i]=ADC.Buffer[i+1];
					ADC.Buffer[2]=buffer/4;
					buffer=0;
					for(i=0;i<3;i++) buffer+=ADC.Buffer[i];
					ADC.Filter=buffer/3;
					ADC.Filter>>=4;
#endif				
					output=ADC.Filter;
					span=Value.SystemFullScale.LWord;
					zero=Value.SystemZeroScale.LWord;

					output-=zero;
					output=output/(span-zero);


					Value.ScaleHiLimit.LWord=100;
					Value.ScaleLoLimit.LWord=0;

					
					output=output*(Value.ScaleHiLimit.LWord-Value.ScaleLoLimit.LWord)+Value.ScaleLoLimit.LWord;

					Value.PV.LWord=(s32)output;

					if(Value.PV.LWord>99999){ Flag.PVHiLimit=1;}
					else if(Value.PV.LWord<-19999){ Flag.PVLoLimit=1;}
					else{ Flag.PVHiLimit=0; Flag.PVLoLimit=0;}
				}
			}
		}
#endif
	}
}
#endif
