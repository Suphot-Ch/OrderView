#ifndef TYPEDEF

typedef float f32;	
typedef unsigned long u32;	
typedef long s32;
typedef unsigned int u16;	
typedef int s16; 
typedef unsigned char u8;  
typedef char s8; 

#define ChannelADC	2

typedef struct{
	u8 Main;
	u8 CalAn;
	u8 Display;
}Status_sType;
typedef union{
	s16 Word;
	struct{
		s8 L;
		s8 H;		
	};
}Word_uType;
typedef union{
	long LWord;
	struct{
		s16 WordLo;
		s16 WordHi;		
	};
}LWord_uType;
typedef struct{
	u16 Buffer[16];
	u16 DecodeLast;
	u16 Decode;
	u8 Status;
	u8 TimeOut;
	u8 ByteCount;
}IR_sType;
typedef struct{
	u8 Seconds;
	u8 Minutes;
	u8 Hours;
	u8 Day;
	u8 Date;
	u8 Month;
	u8 Year;
}StructData_3;
typedef struct{

	s16	HYS[ChannelADC];
	LWord_uType ALC[ChannelADC];
	LWord_uType ALL[ChannelADC];
	LWord_uType ALH[ChannelADC];
	s16	Mode[ChannelADC];
	LWord_uType PVS[ChannelADC];
	s32 PV[ChannelADC];
	
	s16	Channel;
	
	s16	Manu_Button;;
	//s16 regPV0;
	//s16 regPV1;
	
	s16 PV_OUT[4];
	s32 PVMax;
	s32 PVMin;
	
	s8 PVMode;
	//s32	CurrentTemp[4];
	//s32  	Diff;
	//s32	CurrentTempInc;
	//s32	CurrentTempDec;
	//s32	PeakTemp;
	//s32	LastPeakTemp;
	//s16	ShowTemp;

	//u32	Time;
	//u32	TimeFreeze;
	//u8	Temp;

	s16  ResponseTimeOut;
	s16  DelayBetweenPolls;
	s16  Parity;
	s16  Baudrate;
	s16  SlaveAddress;

	u16 DecimalPoint[4];

	//s16	DelayPage;


	LWord_uType DatamLast;
	LWord_uType SystemFullScale[4];
	LWord_uType SystemZeroScale[4];  
	
	//long ActualCount;

	u8	CalAnTimeOut;
	s16  CycleTime;
	s16  CycleTimeEdit;
	s16  Time1Sec;
	u8  Time10mSec;
	s16 Data16Last;

	s16  Div;
	s16  Mul;
	s16  Diff;

	s16  FSec;
	
	s16  Sec;
	s16  Min;
	s16  Hour;
	s16  Date;
	s16  Month;
	s16  Year;
	
	s16  Flag;
	u16  SetPoint;
	
	s16	Data[5];
	s16	High;
	s16	Low;
	
	s16  IntEdit;
	s16  MulEdit;
	s16  ActualLast;
	s16  TargetLast;

	s8 EditLimit;

	s8	analogcal;

	LWord_uType ScaleLoLimit[4];
	LWord_uType ScaleHiLimit[4];
	
}Value_sType;
typedef struct{
	s16 AL_C[2];
	LWord_uType AL_L[2];
	LWord_uType AL_H[2];
	s16 AL_F[2];
	LWord_uType PV_L[2];
	LWord_uType PV_H[2];
	s16 PV_C[2];
	s16 DP[2];
	LWord_uType PV[2];
}RS485;
typedef struct{
	u32 Data[16];
	u32 Filter[4];
	u16 Sample;  
	u32 Buffer[16];
	u8 TimeOunt;
	u8 channel;
}ADC_sType;
typedef struct {
	u8 Status;
	u16 NotResponse; 
	u16 Poll; 
	u16 Response; 
	u16 ByteReq; 
	u16 ByteRsp; 
	u16 DelayBetweenPolls; 
	u16 ResponseTimeOut; 
	u8 RxTimeOut; 
	u8 TxTimeOut; 
	u8 CrcHi; 
	u8 CrcLo;
	u8 ReqBuf[128];
	u8 RspBuf[128];
}MB_sType;
typedef struct{
	u8 Status;
	u8 HoldTime;
}Trig_sType;
typedef struct{
	u8 Minutes;
	u8 Hours;
	u8 Event;
}Program_sType;
typedef struct{
	u8 Seconds;
	u8 Minutes;
	u8 Hours;
	u8 Date;
	u8 Month;
	u8 Year;
	u8 Day;
	u8 Status;
	u8 Interrupt;
}RTC_sType;
typedef union{
	volatile u32 Word;
	struct{
		volatile u8 IrStart : 1;
		volatile u8 IrDecode : 1;
		volatile u8 TimeSetting : 1;
		volatile u8 Frx : 1;
		
		volatile u8 NoDevice : 1;
		volatile u8 Sign : 1;
		volatile u8 Blink : 1;
		volatile u8 Power : 1;
		
		volatile u8 BlinkEn : 1;
		volatile u8 BreakTime : 1;
		volatile u8 Edit : 1;

		
		volatile u8 PVLoLimit_ch1 : 1;
		volatile u8 PVHiLimit_ch1 : 1;

		volatile u8 PVLoLimit_ch2 : 1;
		volatile u8 PVHiLimit_ch2 : 1;

		volatile u8 PVLoLimit_ch3 : 1;
		volatile u8 PVHiLimit_ch3 : 1;

		volatile u8 PVLoLimit_ch4 : 1;
		volatile u8 PVHiLimit_ch4 : 1;

		volatile u8 CalAnalog : 1;
		volatile u8 CalPoint : 1;
		volatile u8 MB_BUSY : 1;
		
		volatile u8 DATA_NOT_SUPPORT : 1;
		
		volatile u8 Checker : 3;
		//volatile u8 Temp : 2;
		volatile u8 Stage : 1;

	};
}Flag_uType;
#endif

