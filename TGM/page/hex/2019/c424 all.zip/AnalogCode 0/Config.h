/* -------------------- */
//              C272               //
/* -------------------- */
/* Descrpiton :
	- Analog Input 2  Ch.
	- 4"	5 Segment (Ch+Data)
	- Output Alarm 2 Alarm
	- RS-485
	- 28.9.15
	Patarapon Vonglertvit
*/		

#ifndef CONFIG

#define ADCEN

#if 0
#define	SIZE_SS
#endif
#if 1
#define	SIZE_S
#endif
#if 0
#define	SIZE_M
#endif
#if 0
#define	SIZE_L
#endif
#if 0
#define	SIZE_XL
#endif

#ifdef SIZE_S
#define SIZE_2_3_INCH
#elif defined SIZE_SS
#define SIZE_1_2_INCH
#elif defined SIZE_M
#define SIZE_4_INCH
#elif defined SIZE_L
#define SIZE_8_INCH
#else
#define SIZE_12_INCH
#endif

#define	_T1ON	T1CONbits.TON
#define	_T2ON	T2CONbits.TON
#define	_T3ON	T3CONbits.TON
#define	_T4ON	T4CONbits.TON

#define	DS1307_R		0b11010001
#define	DS1307_W		0b11010000

#define	IrDataLogic_0	0x0050

#define	EEPROM_OFFSET	0x7FFC00

#define	TMR1_PERIOD	0x0240
#define	TMR2_PERIOD	0xFFFF
#define	TMR3_PERIOD	0x00F0
#define	TMR4_PERIOD	0x00E8 //000A //0x00E8/2

#define	TIME10SEC	1000
#define	TIME4SEC	400
#define	TIME2SEC	200
#define	TIME1SEC	100
#define	TIME500mSEC	50
#define	TIME250mSEC	25

#define	TIME200mSEC	20
#define	TIME150mSEC	15
#define	TIME100mSEC	10
#define	TIME50mSEC	5
#define	TIME40mSEC	4
#define	TIME30mSEC	3
#define	TIME20mSEC	2
#define	TIME10mSEC	1

#define	TIME20mSEC	2
#define	TBLINK	50

#define	RX_START	0x3A
#define	RX_STOP		0x0D
#define	DOT			0x2E
#define	MINUS		0x2D
#define	PLUS		0x2B

#define EN_ADC_CHANNEL_0	1
#define EN_ADC_CHANNEL_1	0
#define EN_ADC_CHANNEL_2	0
#define EN_ADC_CHANNEL_3	0

#define EN_ALARM_CHANNEL_0	1
#define EN_ALARM_CHANNEL_1	0
#define EN_ALARM_CHANNEL_2	0
#define EN_ALARM_CHANNEL_3	0

#define ADC_CHANNEL		1
#define ALARM_CHANNEL	3
#define	EDIT_LENGTH		4
#define	SEGMENT_LENGTH	4
#define	SEGMENT_COLUMN	4
#define	TIME_RESET_LENGTH	2
#define	PROGRAM_LENGTH	20
#define	SLAVE_ADDR		10

#define	CD4051_A	_RB6
#define	CD4051_B	_RB7

#define	ADC_CS	_RB8

#define OUT1	_RD1
#define OUT2	_RD3
#define OUT3	_RD2

#define	ST_CLK	_RE0
#define	SER		_RE1
#define	SH_CLK	_RE2
//#define	RD_485	_RE3
#define	RD_485	LATEbits.LATE3

#define	ST_CLK_2	_RD0
#define	SER_2		_RE4
#define	SH_CLK_2	_RF0

#define 	SDAIO	_TRISF1
#define	SDA		_RF1
#define	SCL		_RE5

#define EEP_PROGRAM_HOURS	0x0000

#define EEP_DEFINE_START	0x0002
#define EEP_PROGRAM_EVENT	0x0050
#define EEP_CYCLE			0x0052

/*                 Edit ADDr For 32 bit 		*/
#define EEP_AN_ZERO_HW0	0x0060
#define EEP_AN_ZERO_LW0	0x0062
#define EEP_AN_ZERO_HW1	0x0064
#define EEP_AN_ZERO_LW1	0x0066
#define EEP_AN_ZERO_HW2	0x0068
#define EEP_AN_ZERO_LW2	0x006A
#define EEP_AN_ZERO_HW3	0x006C
#define EEP_AN_ZERO_LW3	0x006E

#define EEP_AN_FULL_HW0	0x0070
#define EEP_AN_FULL_LW0	0x0072
#define EEP_AN_FULL_HW1	0x0074
#define EEP_AN_FULL_LW1	0x0076
#define EEP_AN_FULL_HW2	0x0078
#define EEP_AN_FULL_LW2	0x007A
#define EEP_AN_FULL_HW3	0x007C
#define EEP_AN_FULL_LW3	0x007E

/*                 Edit ADDr For 16 bit 		*/
#define EEP_MODE1	0x0090
#define EEP_MODE2	0x0092
#define EEP_MODE3	0x0094
#define EEP_MODE4	0x0096

/*                 Edit ADDr For 32 bit 		*/
#define EEP_ALH0H		0x00A0
#define EEP_ALH1H		0x00A2
#define EEP_ALH2H		0x00A4
#define EEP_ALH3H		0x00A6
#define EEP_ALH0L		0x00A8
#define EEP_ALH1L		0x00AA
#define EEP_ALH2L		0x00AC
#define EEP_ALH3L		0x00AE

#define EEP_ALL0H		0x00B0
#define EEP_ALL1H		0x00B2
#define EEP_ALL2H		0x00B4
#define EEP_ALL3H		0x00B6
#define EEP_ALL0L		0x00B8
#define EEP_ALL1L		0x00BA
#define EEP_ALL2L		0x00BC
#define EEP_ALL3L		0x00BE

#define EEP_ALC0H		0x00C0
#define EEP_ALC1H		0x00C2
#define EEP_ALC2H		0x00C4
#define EEP_ALC3H		0x00C6
#define EEP_ALC0L		0x00C8
#define EEP_ALC1L		0x00CA
#define EEP_ALC2L		0x00CC
#define EEP_ALC3L		0x00CE

#define EEP_HYS0H		0x0070
#define EEP_HYS1H		0x0072
#define EEP_HYS2H		0x0074
#define EEP_HYS3H		0x0076
#define EEP_HYS0L		0x0078
#define EEP_HYS1L		0x007A
#define EEP_HYS2L		0x007C
#define EEP_HYS3L		0x007E

//#define EEP_MODE			0x012A

#define EEP_SCALE_HI_HW0		0x0100
#define EEP_SCALE_HI_LW0		0x0102
#define EEP_SCALE_HI_HW1		0x0104
#define EEP_SCALE_HI_LW1		0x0106
#define EEP_SCALE_HI_HW2		0x0108
#define EEP_SCALE_HI_LW2		0x010A
#define EEP_SCALE_HI_HW3		0x010C
#define EEP_SCALE_HI_LW3		0x010E

#define EEP_SCALE_LO_HW0		0x0110
#define EEP_SCALE_LO_LW0		0x0112
#define EEP_SCALE_LO_HW1		0x0114
#define EEP_SCALE_LO_LW1		0x0116
#define EEP_SCALE_LO_HW2		0x0118
#define EEP_SCALE_LO_LW2		0x011A
#define EEP_SCALE_LO_HW3		0x011C
#define EEP_SCALE_LO_LW3		0x011E

#define EEP_PUS0H	0x0120
#define EEP_PUS1H	0x0122
#define EEP_PUS2H	0x0124
#define EEP_PUS3H	0x0126
#define EEP_PUS0l	0x0128
#define EEP_PUS1l	0x012A
#define EEP_PUS2l	0x012C
#define EEP_PUS3l	0x012E

#define EEP_DP1		0x0130
#define EEP_DP2		0x0132
#define EEP_DP3		0x0134
#define EEP_DP4		0x0136

#define EEP_SLAVE_ADDRESS	0x01A0
#define EEP_BAUDRATE		0x01A2
#define EEP_PARITY			0x01A4
#define EEP_DELAY_POLLS		0x01A6
#define EEP_RESP_TIME_OUT	0x01A8

#define EEP_TIME_SEC		0x01C0
#define EEP_TIME_MIN		0x01C4
#define EEP_TIME_HOUR		0x01C6
#define EEP_TIME_DATE		0x01C8
#define EEP_TIME_MONTH		0x01CA
#define EEP_TIME_YEAR		0x01CC

#define RAM_TARGET			0x000A
#define RAM_ACTUAL			0x000E

#define BUTTON_A1	0x0290
#define BUTTON_A2	0x05D0
#define BUTTON_A3	0x0A90
#define BUTTON_A4	0x0FD0
#define BUTTON_A5	0x0A50
#define BUTTON_A6	0x01D0
#define BUTTON_A7	0x0B90
#define BUTTON_A8	0x0150
#define BUTTON_A9	0x0490
#define BUTTON_A10	0x0090
#define BUTTON_A11	0x0E90
#define BUTTON_A12	0x0C90
#define BUTTON_A13	0x0890
#define BUTTON_A14	0x03D0
#define BUTTON_A15	0x02F0
#define BUTTON_A16	0x03F0
#define BUTTON_A17	0x06D0
#define BUTTON_A18	0x0AF0
#define BUTTON_A19	0x0270
#define BUTTON_0		0x0910
#define BUTTON_1		0x0010
#define BUTTON_2		0x0810
#define BUTTON_3		0x0410
#define BUTTON_4		0x0C10
#define BUTTON_5		0x0210
#define BUTTON_6		0x0A10
#define BUTTON_7		0x0610
#define BUTTON_8		0x0E10
#define BUTTON_9		0x0110

#define BIT0		0x0001
#define BIT1		0x0002
#define BIT2		0x0004
#define BIT3		0x0008
#define BIT4		0x0010
#define BIT5		0x0020
#define BIT6		0x0040
#define BIT7		0x0080
#define BIT8		0x0100
#define BIT9		0x0200
#define BIT10		0x0400
#define BIT11		0x0800
#define BIT12		0x1000
#define BIT13		0x2000
#define BIT14		0x4000
#define BIT15		0x8000

#ifndef _MACRO
#define togglebi(b,x) (b^=x)
#define sbi(b,x) (b|=x)
#define cbi(b,x) (b&=~x)
#define bis(b,x) (b&x)
#define bic(b,x) (!(b&x))
#endif

enum BAUDRATE{BR4800, BR9600, BR19200, BR38400, BR57600, BR115200,BR1200, BR2400};
enum PARITY{b8n1, b8o1, b8e1};
enum {REQ_PV, RSP_PV, REQ_DP, RSP_DP};

enum {_W,_R};
enum {_BREAK, _RUN};
enum LINK{RX, TX};
enum {DIS, EN};
enum {CLR, SET};
enum {RISING, FALLING};
enum DEFINES{OUTPUT, INPUT};
enum STATUS{_FALSE, _TRUE};
enum TRIG_INPUT{TRIG, DEBOUNCE, RELEASE};
enum ILLEGAL{ILLEGAL_FUNCTION=1, ILLEGAL_DATA_ADDRESS, ILLEGAL_DATA_VALUE};
enum PRIORITY{PRIORITY_1=1, PRIORITY_2, PRIORITY_3, PRIORITY_4, PRIORITY_5, PRIORITY_6, PRIORITY_7};
enum Day{
	Monday, 
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saterday,
	Sunday
};
enum Months{
	January,
	February, 
	March, 
	April, 
	May, 
	June, 
	July, 
	August, 
	September, 
	October, 
	November, 
	December
};
enum Real_Time_Clock{
	SECONDS_REG, 
	MINUTES_REG, 
	HOURS_REG, 
	DATE_REG, 
	MONTH_REG, 
	YEAR_REG,
	DAY_REG, 
	CONTROL_REG, 
	RAM_REG
}; 
enum	Main{
	INIT, 
		OPERATE, 					// 01
		EDIT_SCALE_HI, 				// 02
		EDIT_SCALE_LO, 				// 03
		EDIT_DP, 					// 04
	EDIT_ADDRESS, 					// 05
	EDIT_BAUDRATE, 					// 06
	EDIT_PARITY, 					// 07
	EDIT_DELAY_POLLS, 				// 08
	EDIT_RESPONSE_TIMEOUT,  		// 09
		CAL_ANALOG,					// 10
		IDLE, 						// 11
		HYS_MODE, 					// 12
	SETPOINT_2_MODE,				// 13
		CHANGE_DSP, 				// 14
		EDIT_TIMER,					// 15
		PUS_MODE, 					// 16
			ALL_MODE, 					// 17
			ALH_MODE, 					// 18
			ALC_MODE, 					// 19
			CHOOSE_MODE, 				// 20
	MODE_INP,						// 21
		EDIT_VALUE_TIME,			// 22
		EDIT_VALUE_DATE,			// 23
		EDIT_VALUE_YEAR,			// 24
};
enum REG_Modbus{
	PV0_H_VALUE,	// 00
	PV0_L_VALUE,	// 01
	PV1_H_VALUE,	// 02
	PV1_L_VALUE,	// 03
	
	DP0_RGE,		// 04
	DP1_RGE,		// 05
	PV0_CL_RGE,	// 06
	PV1_CL_RGE,	// 07
	
	PV0_HH_RGE,	// 08
	PV0_HL_RGE,	// 09
	PV1_HH_RGE,	// 0A
	PV1_HL_RGE,	// 0B
	
	PV0_LH_RGE,	// 0C
	PV0_LL_RGE,		// 0D
	PV1_LH_RGE,	// 0E
	PV1_LL_RGE,		// 0F
	
	AL0_F_RGE,		// 10
	AL1_F_RGE,		// 11
	
	AL0_HH_RGE,	// 12
	AL0_HL_RGE,	// 13
	AL1_HH_RGE,	// 14
	AL1_HL_RGE,	// 15
	
	AL0_LH_RGE,	// 16
	AL0_LL_RGE,		// 17
	AL1_LH_RGE,	// 18
	AL1_LL_RGE,		// 19
	
	AL0_CL_RGE,	// 1A
	AL1_CL_RGE,	// 1B
};
enum Reg_Modbus{
	PV1_REG,
	PV2_REG,
	CHANNEL_REG,
	CHOOSE_MODE_REG,
	SETPOINT_1_MODE_REG,
	SETPOINT_1_L_MODE_REG,
	SETPOINT_1_C_MODE_REG,
	SETPOINT_2_MODE_REG,	
	SETPOINT_2_L_MODE_REG,
	SETPOINT_2_C_MODE_REG
};
#endif
