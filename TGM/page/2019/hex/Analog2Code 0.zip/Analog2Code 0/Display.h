
#ifndef DISPLAY

#include "config.h"
#include "typedef.h"

#endif

