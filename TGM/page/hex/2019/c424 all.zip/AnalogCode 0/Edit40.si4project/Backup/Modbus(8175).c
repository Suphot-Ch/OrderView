#include <p30f4011.h>
#include <stdio.h>
#include <uart.h>
#include "config.h"
#include "global.h"

const u8 CRCTableHigh[] = {
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,	0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,	0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
const u8 CRCTableLow[] = {
	0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
	0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
	0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
	0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
	0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
	0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
	0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
	0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2,	0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
	0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
	0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
	0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
	0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
	0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
};


//MB_sType Modbus;

void tx_en(void){
	RD_485=TX;
}
void rx_en(void){
	RD_485=RX;
}
void crc16(u8 *dptr,u8 n){
	u8 i, j;
	
	Modbus.CrcHi=Modbus.CrcLo=0xFF;
	for(i=0;i<n;i++,dptr++){
		j=Modbus.CrcHi^*dptr;
		Modbus.CrcHi=Modbus.CrcLo^CRCTableHigh[j];
		Modbus.CrcLo=CRCTableLow[j];
	}
}
s8 crc16_check(u8 *dptr,u8 n){
	crc16(dptr, n);

	return ((dptr[n]==Modbus.CrcHi)&&(dptr[n+1]==Modbus.CrcLo)) ? 1 : 0;
}
void mb_func_read_input_regs(u8 addr, u8 regs_addr_h, u8 regs_addr_l, u8 regs_val_h, u8 regs_val_l, u8 *dptr){
	u8 *dptrcrc;

	dptrcrc=dptr;
	
	*dptr++=addr;
	*dptr++=0x04;
	*dptr++=regs_addr_h;
	*dptr++=regs_addr_l;
	*dptr++=regs_val_h;
	*dptr++=regs_val_l;
	crc16(dptrcrc, 6);
	*dptr++=Modbus.CrcHi;
	*dptr=Modbus.CrcLo;
	Modbus.ByteReq=8;
}
void mb_req(void){
	int buff;
#if 1
	if(Status.Main!=OPERATE) return;
	switch(Modbus.Status){
		case REQ_PV:
			if(!Flag.MB_BUSY){
				if(++Modbus.DelayBetweenPolls>=Value.DelayBetweenPolls){
					Modbus.DelayBetweenPolls=0;
#if 0					
					Modbus.ReqBuf[0]=Value.SlaveAddress;	/*Slave Address*/
					Modbus.ReqBuf[1]=0x04;	/*Function Read Input Regs*/
					Modbus.ReqBuf[2]=0x00;	/*PV Regs*/
					Modbus.ReqBuf[3]=0x00;	/*PV Regs*/
					Modbus.ReqBuf[4]=0x00;
					Modbus.ReqBuf[5]=0x01; /*N Regs=1*/
					crc16(Modbus.ReqBuf, 6);
					Modbus.ReqBuf[6]=Modbus.CrcHi;
					Modbus.ReqBuf[7]=Modbus.CrcLo;
					Modbus.ByteReq=8;
#else					
					mb_func_read_input_regs((u8)Value.SlaveAddress, 0x00, 0x00, 0x00, 0x01, Modbus.ReqBuf);
#endif					
					tx_en();
					Flag.MB_BUSY=1;
					MB_Dptr=Modbus.ReqBuf;
					Modbus.ResponseTimeOut=0;
			
					U2TXREG=*MB_Dptr++;		

					Modbus.Poll++;
					
					Modbus.Status=RSP_PV;
				}
			}
			break;
		case RSP_PV:
			if(!Flag.Frx){
				if(++Modbus.ResponseTimeOut>=Value.ResponseTimeOut){
					Modbus.ResponseTimeOut=0;
					if(!Flag.NoDevice){
						if(++Modbus.NotResponse>=5){
							Modbus.NotResponse=0;
							Flag.NoDevice=1;
						}
					}
					Flag.MB_BUSY=0;
					//tx_en();
					
					Modbus.Status=REQ_PV;
				}
			}
			else{
				if(++Modbus.RxTimeOut>=TIME20mSEC){
					Modbus.RxTimeOut=0;
					if(crc16_check(Modbus.RspBuf, Modbus.ByteRsp-2)){
						buff=Modbus.RspBuf[3];
						buff<<=8;
						buff|=Modbus.RspBuf[4];
						Value.PV[3]=buff;
						Modbus.ByteRsp=0;
						Flag.Frx=0;
						Flag.MB_BUSY=0;	
						Flag.NoDevice=0;			
						Modbus.Status=REQ_DP;
						Modbus.Response++;
					}
				}
			}
			break;
		case REQ_DP:
			if(!Flag.MB_BUSY){
				if(++Modbus.DelayBetweenPolls>=Value.DelayBetweenPolls){
					Modbus.DelayBetweenPolls=0;
#if 0					
					Modbus.ReqBuf[0]=Value.SlaveAddress;	/*Slave Address*/
					Modbus.ReqBuf[1]=0x04;	/*Function Read Input Regs*/
					Modbus.ReqBuf[2]=0x00;	/*PV Regs*/
					Modbus.ReqBuf[3]=0x22;	/*PV Regs*/
					Modbus.ReqBuf[4]=0x00;
					Modbus.ReqBuf[5]=0x01; /*N Regs=1*/
					crc16(Modbus.ReqBuf, 6);
					Modbus.ReqBuf[6]=Modbus.CrcHi;
					Modbus.ReqBuf[7]=Modbus.CrcLo;
					Modbus.ByteReq=8;
#else					
					mb_func_read_input_regs(Value.SlaveAddress, 0x00, 0x09, 0x00, 0x01, Modbus.ReqBuf);
#endif					
					tx_en();
					Flag.MB_BUSY=1;
					MB_Dptr=Modbus.ReqBuf;
					Modbus.ResponseTimeOut=0;
			
					U2TXREG=*MB_Dptr++;		
					
					Modbus.Poll++;
					
					Modbus.Status=RSP_DP;
				}
			}
			break;
		case RSP_DP:
			if(!Flag.Frx){
				if(++Modbus.ResponseTimeOut>=Value.ResponseTimeOut){
					Modbus.ResponseTimeOut=0;
					Modbus.NotResponse++;
					Flag.MB_BUSY=0;
					//tx_en();
					
					Modbus.Status=REQ_PV;
				}
			}
			else{
				if(++Modbus.RxTimeOut>=TIME20mSEC){
					Modbus.RxTimeOut=0;
					if(crc16_check(Modbus.RspBuf, Modbus.ByteRsp-2)){
						Value.DecimalPoint[3]=Modbus.RspBuf[3];
						Value.DecimalPoint[3]<<=8;
						Value.DecimalPoint[3]|=Modbus.RspBuf[4];
						Modbus.ByteRsp=0;
						Flag.MB_BUSY=0;		
						Flag.NoDevice=0;			
						Modbus.Status=REQ_PV;
						Modbus.Response++;
					}
				}
			}
			break;
	}
	#endif
}
#if 1
u8 register_address_support(u16 reg_addr){ 
	return 1;
}
LWord_uType Reg_val;
u8 register_value_in_range_32(u16 reg_addr, s16 *reg_val){
#if 1
	switch(reg_addr){

		case DP0_RGE:
		case DP1_RGE:
			if((*reg_val<=4)&&(*reg_val>=0)) return 1;
			else return 0;
			break;
		case AL0_F_RGE:
		case AL1_F_RGE:
			if((*reg_val<=4)&&(*reg_val>=0)) return 1;
			else return 0;
			break;
		case PV0_CL_RGE:
		case PV1_CL_RGE:
		case AL0_CL_RGE:
		case AL1_CL_RGE:
			if((*reg_val<=9999)&&(*reg_val>=-999)) return 1;
			else return 0;
			break;

		case PV0_HH_RGE:
		case PV1_HH_RGE:
		case PV0_LH_RGE:
		case PV1_LH_RGE:
		case AL0_HH_RGE:
		case AL1_HH_RGE:
		case AL0_LH_RGE:
		case AL1_LH_RGE:
			if((*reg_val==-1)||(*reg_val==1)||(*reg_val==0)) {
				Reg_val.WordHi = *reg_val ; 
				return 1;
				}
			else return 0;
			break;
		case PV0_HL_RGE:
		case PV1_HL_RGE:
		case PV0_LL_RGE:
		case PV1_LL_RGE:
		case AL0_HL_RGE:
		case AL1_HL_RGE:
		case AL0_LL_RGE:
		case AL1_LL_RGE:
			Reg_val.WordLo= *reg_val;
			if((Reg_val.LWord>=-9999)&&(Reg_val.LWord<=99999)) return 1;
			else return 0;
			break;
		default:
			return 0;
			break;
		}
#endif	
}
u8 register_value_in_range(u16 reg_addr, s16 *reg_val){
#if 1
	switch(reg_addr){
		case DP0_RGE:
		case DP1_RGE:
			if((*reg_val<=4)&&(*reg_val>=0)) return 1;
			else return 0;
			break;
		case AL0_F_RGE:
		case AL1_F_RGE:
			if((*reg_val<=4)&&(*reg_val>=0)) return 1;
			else return 0;
			break;
		case PV0_CL_RGE:
		case PV1_CL_RGE:
		case AL0_CL_RGE:
		case AL1_CL_RGE:
			if((*reg_val<=9999)&&(*reg_val>=-999)) return 1;
			else return 0;
			break;
/*
		case PV0_HH_RGE:
		case PV1_HH_RGE:
		case PV0_LH_RGE:
		case PV1_LH_RGE:
		case AL0_HH_RGE:
		case AL1_HH_RGE:
		case AL0_LH_RGE:
		case AL1_LH_RGE:
			if((*reg_val==0xFFFF)||(*reg_val==1)||(*reg_val==0)) return 1;
			else return 0;
			break;
		case PV0_HL_RGE:
		case PV1_HL_RGE:
		case PV0_LL_RGE:
		case PV1_LL_RGE:
		case AL0_HL_RGE:
		case AL1_HL_RGE:
		case AL0_LL_RGE:
		case AL1_LL_RGE:
			if((*reg_val>=-9999)&&(*reg_val<=99999)) return 1;
			else return 0;
			break;
*/
		default:
			return 0;
			break;
		}
#endif	
}
void exeption_response(u8 ExeptionCode){
#if 1
	if(Modbus.ReqBuf[0]==Value.SlaveAddress){
		Modbus.RspBuf[0]=Modbus.ReqBuf[0];	
		Modbus.RspBuf[1]=0x80|Modbus.ReqBuf[1];	
		Modbus.RspBuf[2]=ExeptionCode;	
		crc16(Modbus.RspBuf, 3);
		Modbus.RspBuf[3]=Modbus.CrcHi;	
		Modbus.RspBuf[4]=Modbus.CrcLo;
		//Modbusdptr=Modbus.RspBuf;	
		MB_Dptr=(u16 *)Modbus.RspBuf;
		Modbus.ByteRsp=5;	
		tx_en();
		U2TXREG=*MB_Dptr++;	
		//SBUF=*Modbusdptr++;
	}
#endif
}
void mb_save_param(s16 reg_addr, u16 *reg_val){
#if 1
	switch(reg_addr){
		case DP0_RGE:
			Value.DecimalPoint[0]=*reg_val;
			write_eeprom(EEP_DP1,Value.DecimalPoint[0]);
			break;
		case DP1_RGE:
			Value.DecimalPoint[1]=*reg_val;
			write_eeprom(EEP_DP2,Value.DecimalPoint[1]);
			break;
		case PV0_CL_RGE:
			Value.PVS[0].WordLo=*reg_val;
			if(Value.PVS[0].WordLo<0)Value.PVS[0].WordHi=0xFFFF;
			write_eeprom(EEP_PUS1,Value.PVS[0].WordHi);
			write_eeprom(EEP_PUS11,Value.PVS[0].WordLo);
			break;
		case PV1_CL_RGE:
			Value.PVS[1].WordLo=*reg_val;
			if(Value.PVS[1].WordLo<0)Value.PVS[1].WordHi=0xFFFF;
			write_eeprom(EEP_PUS2,Value.PVS[1].WordHi);
			write_eeprom(EEP_PUS22,Value.PVS[1].WordLo);
			break;
		case PV0_HH_RGE:
			Value.ScaleHiLimit[0].WordHi=*reg_val;
			break;
		case PV0_HL_RGE:
			Value.ScaleHiLimit[0].WordLo=*reg_val;
			write_eeprom(EEP_SCALE_HI_HW0,Value.ScaleHiLimit[0].WordHi);
			write_eeprom(EEP_SCALE_HI_LW0,Value.ScaleHiLimit[0].WordLo);
			break;
		case PV1_HH_RGE:
			Value.ScaleHiLimit[1].WordHi=*reg_val;
			break;
		case PV1_HL_RGE:
			Value.ScaleHiLimit[1].WordLo=*reg_val;
			write_eeprom(EEP_SCALE_HI_HW1,Value.ScaleHiLimit[1].WordHi);
			write_eeprom(EEP_SCALE_HI_LW1,Value.ScaleHiLimit[1].WordLo);
			break;
		case PV0_LH_RGE:
			Value.ScaleLoLimit[0].WordHi=*reg_val;
			break;
		case PV0_LL_RGE:
			Value.ScaleLoLimit[0].WordLo=*reg_val;
			write_eeprom(EEP_SCALE_LO_HW0,Value.ScaleLoLimit[0].WordHi);
			write_eeprom(EEP_SCALE_LO_LW0,Value.ScaleLoLimit[0].WordLo);
			break;
		case PV1_LH_RGE:
			Value.ScaleLoLimit[1].WordHi=*reg_val;
			break;
		case PV1_LL_RGE:
			Value.ScaleLoLimit[1].WordLo=*reg_val;
			write_eeprom(EEP_SCALE_LO_HW1,Value.ScaleLoLimit[1].WordHi);
			write_eeprom(EEP_SCALE_LO_LW1,Value.ScaleLoLimit[1].WordLo);
			break;
		case AL0_F_RGE:
			Value.Mode[0]=*reg_val;
			write_eeprom(EEP_MODE1,Value.Mode[1]);
			break;
		case AL1_F_RGE:
			Value.Mode[0]=*reg_val;
			write_eeprom(EEP_MODE1,Value.Mode[1]);
			break;
		case AL0_HH_RGE:
			Value.ALH[0].WordHi=*reg_val;
			break;
		case AL0_HL_RGE:
			Value.ALH[0].WordLo=*reg_val;
			write_eeprom(EEP_ALH0H,Value.ALH[0].WordHi);
			write_eeprom(EEP_ALH0L,Value.ALH[0].WordLo);
			break;
		case AL1_HH_RGE:
			Value.ALH[1].WordHi=*reg_val;
			break;
		case AL1_HL_RGE:
			Value.ALH[1].WordLo=*reg_val;
			write_eeprom(EEP_ALH1H,Value.ALH[1].WordHi);
			write_eeprom(EEP_ALH1H2,Value.ALH[1].WordLo);
			break;
		case AL0_LH_RGE:
			Value.ALL[0].WordHi=*reg_val;
			break;
		case AL0_LL_RGE:
			Value.ALL[0].WordLo=*reg_val;
			write_eeprom(EEP_ALL1,Value.ALL[0].WordHi);
			write_eeprom(EEP_ALL11,Value.ALL[0].WordLo);
			break;
		case AL1_LH_RGE:
			Value.ALL[1].WordHi=*reg_val;
			break;
		case AL1_LL_RGE:
			Value.ALL[1].WordLo=*reg_val;
			write_eeprom(EEP_ALL2,Value.ALL[1].WordHi);
			write_eeprom(EEP_ALL22,Value.ALL[1].WordLo);
			break;
		case AL0_CL_RGE:
			Value.ALC[0].WordLo=*reg_val;
			if(Value.ALC[0].WordLo<0)Value.ALC[0].WordHi=0xFFFF;
			write_eeprom(EEP_ALC1,Value.ALC[0].WordHi);
			write_eeprom(EEP_ALC11,Value.ALC[0].WordLo);
			break;
		case AL1_CL_RGE:
			Value.ALC[1].WordLo=*reg_val;
			if(Value.ALC[1].WordLo<0)Value.ALC[1].WordHi=0xFFFF;
			write_eeprom(EEP_ALC2,Value.ALC[1].WordHi);
			write_eeprom(EEP_ALC22,Value.ALC[1].WordLo);
			break;
		default:
			break;
		}
#endif
}
RS485 Output;
void mb_param(void){
	if(Flag.PVHiLimit_ch1||Flag.PVLoLimit_ch1)Output.PV[1].LWord=0;
	else Output.PV[1].LWord= Value.PV[0];
	
	if(Flag.PVHiLimit_ch2||Flag.PVLoLimit_ch2)Output.PV[0].LWord=0;
	else Output.PV[0].LWord = Value.PV[1];
	
	Output.DP[1] = Value.DecimalPoint[0];
	Output.DP[0] = Value.DecimalPoint[1];

	Output.PV_C[1]	= Value.PVS[0].WordLo;
	Output.PV_C[0]	= Value.PVS[1].WordLo;

	Output.PV_H[1].LWord	= Value.ScaleHiLimit[0].LWord;
	Output.PV_H[0].LWord	= Value.ScaleHiLimit[1].LWord;
	
	Output.PV_L[1].LWord	= Value.ScaleLoLimit[0].LWord;
	Output.PV_L[0].LWord	= Value.ScaleLoLimit[1].LWord;
	
	Output.AL_F[1] = Value.Mode[0];
	Output.AL_F[0] = Value.Mode[1];

	Output.AL_H[1].LWord	= Value.ALH[0].LWord;
	Output.AL_H[0].LWord	= Value.ALH[1].LWord;
	
	Output.AL_L[1].LWord	= Value.ALL[0].LWord;
	Output.AL_L[0].LWord	= Value.ALL[1].LWord;
	
	Output.AL_C[1]	= Value.ALC[0].WordLo;
	Output.AL_C[0]	= Value.ALC[1].WordLo;
	
}
void preset_a_single_register(void){
	#if 1
	u16 DATA_BUFFER, REGISTER_VALUE, REGISTER_ADDR;
	u8 *dptr, i;
	
	if(Modbus.ReqBuf[0]==0||Modbus.ReqBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7]) return;	
		REGISTER_ADDR=Modbus.ReqBuf[2];
		REGISTER_ADDR=REGISTER_ADDR<<8|Modbus.ReqBuf[3];
		if(register_address_support(REGISTER_ADDR)){	
			REGISTER_VALUE=Modbus.ReqBuf[4];
			REGISTER_VALUE=REGISTER_VALUE<<8|Modbus.ReqBuf[5];
			if(register_value_in_range(REGISTER_ADDR, (u16*)&REGISTER_VALUE)){
				dptr=(u8 *)&Output.PV[1].WordHi;
				dptr+=3;
				REGISTER_ADDR-=0;
				dptr-=REGISTER_ADDR<<1;
				DATA_BUFFER=0;
				for(i=4;i<6;i++, dptr--){
					DATA_BUFFER<<=8;
					*dptr=Modbus.ReqBuf[i];
					DATA_BUFFER|=*dptr;
				}
				//save_to_eeprom(REGISTER_ADDR, (s16 *)&DATA_BUFFER);
				mb_save_param(REGISTER_ADDR, (u16 *)&REGISTER_VALUE);
				if(Modbus.ReqBuf[0]){
					Modbus.ByteRsp=0;
					for(i=0;i<6;i++){
						Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[i];	
					}
					crc16(Modbus.RspBuf, Modbus.ByteRsp);
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
					Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
					MB_Dptr=(u16 *)Modbus.RspBuf;
					tx_en();
					U2TXREG=*MB_Dptr++;	
					//REDE75176=1;
					//SBUF=*Modbusdptr++;
				}
			}
			else{
				if(Modbus.ReqBuf[0]){
					exeption_response(ILLEGAL_DATA_VALUE);
				}
			}
		}
		else{
			if(Modbus.ReqBuf[0]){
				exeption_response(ILLEGAL_DATA_ADDRESS);
			}
		}
	}
	#endif
}
void func_16_rtu_mode(void){	
	Word_uType QUANTITY, REGISTER_ADDR, REGISTER_VAL;
	u8 *dptr, i, BYTE_COUNT;
/*		A	B	C	D	E	*/
/*		|	|	|	|	|	*/
/*A1*/	if((Modbus.ReqBuf[0]==Value.SlaveAddress)||(Modbus.ReqBuf[0]==0)){
			if(Modbus.ByteReq<11) return;	
			crc16(Modbus.ReqBuf, Modbus.ByteReq-2);
			if(Modbus.CrcHi!=Modbus.ReqBuf[Modbus.ByteReq-2]||Modbus.CrcLo!=Modbus.ReqBuf[Modbus.ByteReq-1])return;	
			REGISTER_ADDR.H=Modbus.ReqBuf[2];
			REGISTER_ADDR.L=Modbus.ReqBuf[3];	
			QUANTITY.H=Modbus.ReqBuf[4];
			QUANTITY.L=Modbus.ReqBuf[5];
			BYTE_COUNT=Modbus.ReqBuf[6];
/*B1*/		if(((QUANTITY.Word>=1)&&(QUANTITY.Word<=AL1_CL_RGE+1))&&((QUANTITY.Word<<1)==BYTE_COUNT)){
/*C1*/			if((REGISTER_ADDR.Word>=DP0_RGE)&&((REGISTER_ADDR.Word+QUANTITY.Word)<=AL1_CL_RGE+1)){
					Flag.DATA_NOT_SUPPORT=0;
/*D1*/				for(i=0;i<QUANTITY.Word;i++){
						REGISTER_VAL.H=Modbus.ReqBuf[(i*2)+7];
						REGISTER_VAL.L=Modbus.ReqBuf[(i*2)+8];
/*E1*/					if(!register_value_in_range_32(REGISTER_ADDR.Word+i, &REGISTER_VAL.Word)){
							Flag.DATA_NOT_SUPPORT=1;
							break;
/*E1*/					}
						mb_save_param(REGISTER_ADDR.Word+i, (u16 *)&REGISTER_VAL.Word);
/*D1*/				}
/*D2*/				if(Flag.DATA_NOT_SUPPORT==0){
						dptr=(u8 *)&Output.PV[1].WordHi;
						dptr-=REGISTER_ADDR.Word<<1;
						
/*E2*/					for(i=7;i<BYTE_COUNT+7;i++, dptr--){
							*dptr=Modbus.ReqBuf[i];
/*E2*/					}
/*E3*/					if(Modbus.ReqBuf[0]==Value.SlaveAddress){
							Modbus.ByteRsp=0;
							Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[2];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[3];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[4];	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[5];
							crc16(Modbus.ReqBuf, Modbus.ByteRsp);	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;	
							Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
							MB_Dptr=Modbus.RspBuf;
							tx_en();
							U2TXREG=*MB_Dptr++;
/*E3*/					}
/*D3*/				}
/*D4*/				else{
						exeption_response(ILLEGAL_DATA_VALUE);						
/*D4*/				}
/*C1*/			}
/*C2*/			else{
					exeption_response(ILLEGAL_DATA_ADDRESS);	
/*C2*/			}
/*B1*/		}
/*B2*/		else{	
				exeption_response(ILLEGAL_DATA_VALUE);		
/*B2*/		}	
/*A1*/	}
}
void read_multi_registers(void){
	#if 1
	u16 i, N, REGISTER_ADDR;
	u8 *dptr;
	
	if(Modbus.ReqBuf[0]==Value.SlaveAddress){
		if(Modbus.ByteReq!=8) return;	
		crc16(Modbus.ReqBuf, 6);
		if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7])return;		
		N=Modbus.ReqBuf[4];
		N=N<<8|Modbus.ReqBuf[5];
		if(N>=0x0001&&N<=AL1_CL_RGE+1){	
			REGISTER_ADDR=Modbus.ReqBuf[2];
			REGISTER_ADDR=REGISTER_ADDR<<8|Modbus.ReqBuf[3];
			if((REGISTER_ADDR>=PV0_H_VALUE&&REGISTER_ADDR<=PV0_H_VALUE+1)&&(REGISTER_ADDR+N>=PV0_H_VALUE+N&&REGISTER_ADDR+N<=AL1_CL_RGE+N)){
				mb_param();
				dptr=(u8 *)&Output.PV[1].WordHi;
				dptr+=1;
				//REGISTER_ADDR-=0x0100;
				dptr-=REGISTER_ADDR<<1;
				Modbus.ByteRsp=0;
				Modbus.RspBuf[Modbus.ByteRsp++]=Value.SlaveAddress;
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.ReqBuf[1];
				N<<=1;
				Modbus.RspBuf[Modbus.ByteRsp++]=N;
				for(i=0;i<N;i++,dptr--){
					Modbus.RspBuf[Modbus.ByteRsp++]=*dptr;
				}
				crc16(Modbus.RspBuf, Modbus.ByteRsp);
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcHi;
				Modbus.RspBuf[Modbus.ByteRsp++]=Modbus.CrcLo;
				MB_Dptr=(u16 *)Modbus.RspBuf;
				tx_en();
				U2TXREG=*MB_Dptr++;
				//REDE75176=1;
				//SBUF=*Modbusdptr++;
			}
			else{
				exeption_response(ILLEGAL_DATA_ADDRESS);
			}
		}
		else{	
			exeption_response(ILLEGAL_DATA_VALUE);
		}	
	}
	#endif
}
void loop_back_diagnostic(void){
	#if 0
	u8 i;
	if(Modbus.ReqBuf[0]!=Value.SlaveAddress) return;
	if(Modbus.ByteReq!=8) return;
	crc16(Modbus.ReqBuf, 6);
	if(Modbus.CrcHi!=Modbus.ReqBuf[6]||Modbus.CrcLo!=Modbus.ReqBuf[7]) return;
	for(i=0;i<Modbus.ByteReq;i++){
		Modbus.RspBuf[i]=Modbus.ReqBuf[i];
	}
	MB_Dptr=(u16 *)Modbus.RspBuf;
	Modbus.ByteRsp=8;
	tx_en();
	U2TXREG=*MB_Dptr++;	
	//REDE75176=1;
	//SBUF=*Modbusdptr++;
	#endif
}
void modbus(void){
//	u16 i;
	if(Flag.Frx){
		if(++Modbus.RxTimeOut>=2){
			Modbus.RxTimeOut=0;
			Flag.Frx=0;
			switch(Modbus.ReqBuf[1]){
				case 0x03:
				case 0x04:
					read_multi_registers();
					break;
				case 0x08:
					loop_back_diagnostic();
					break;
				case 0x06:
					preset_a_single_register();
					break;
				case 0x10:
					func_16_rtu_mode();
					break;
				default:
					exeption_response(ILLEGAL_FUNCTION);
					break;
			}
//			for(i=0;i<256;i++)
//				Modbus.ReqBuf[i]=0x00;
			Modbus.ByteReq=0;
		}
	}
}
#endif


