
#ifndef IR

#include "config.h"
#include "typedef.h"

//extern IR_sType IrData;

#endif

