#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h" 
#include "segment.h"

u32 DIVReg[]={1,10,100,1000,10000,100000,1000000};
void shift_edit_buffer(void){
	s8 i;
	for(i=0;i<EDIT_LENGTH;i++){
		EditBuffer[i]=EditBuffer[i+1];
	}
}
void load_edit_buffer(s32 val){
	u8 i,j;
	Flag.Sign=0;
	if(val<0){
		val=-val;
		Flag.Sign=1;
		}
	j=EDIT_LENGTH-1;
	for(i=0;i<EDIT_LENGTH;i++,j--){
		EditBuffer[i]=val/DIVReg[j]%10;
		}
}
s32 reload_edit_buffer(void){
	//Flag.Sign=(val<0) ? 1 : 0;
	u8 i,j;
	s32 val[EDIT_LENGTH];
	
	j=EDIT_LENGTH-1;
	val[0]=0;
	for(i=0;i<EDIT_LENGTH;i++){
		val[i]=EditBuffer[i]*DIVReg[j--];
		if(i!=0){
			val[0]+=val[i];
		}	
	}
	if(Flag.Sign) val[0]=-val[0];
	//if(Flag.Sign) val=-val;
	return val[0];
}
void operate_mode(void){
	Status.Main=OPERATE_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	load_edit_buffer(0);
	Flag.CalAnalog=0;
}
void edit_Warning_Mode(u8 warn){
	Status.Main=EDIT_WARNING_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.WarningStatus = warn;
}
void edit_slave_address_mode(void){
	Status.Main=EDIT_ADDRESS_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord = Value.SlaveAddress;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_baudrate_mode(void){
	Status.Main=EDIT_BAUDRATE_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Baudrate;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_parity_mode(void){
	Status.Main=EDIT_PARITY_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Parity;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_delay_polls_mode(void){
	Status.Main=EDIT_DELAY_POLLS_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.DelayBetweenPolls;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_response_timeout_mode(void){
	Status.Main=EDIT_RESPONSE_TIMEOUT_MODE;
	EditNum=0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.ResponseTimeOut;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_Ide_mode(void){
	Status.Main=IDLE_MODE;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
//	Flag.Timer_En=0;
}
void edit_Input_mode(void){
	Status.Main = EDIT_INPUT_DELAY;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.InputDelay;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_InputType_mode(void){
	Status.Main = EDIT_INPUT_TYPE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord = Value.InputType;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_Mul_mode(void){
	Status.Main=EDIT_MUL_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Multiplier1;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_Div_mode(void){
	Status.Main=EDIT_DIV_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Divisor1;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_Decimal_mode(void){
	Status.Main=EDIT_DP_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.DecimalPoint;
	load_edit_buffer(Value.DatamLast.LWord);
}
// Functoin Actual1 14
void edit_Target(void){
	Status.Main=EDIT_TARGET;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Target;
	load_edit_buffer(Value.DatamLast.LWord);
}
// Functoin Actual1 15
void edit_Actual1(void){
	Status.Main=EDIT_ACTUAL1;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.DatamLast.LWord=Value.Actual1;
	load_edit_buffer(Value.DatamLast.LWord);
}
// Functoin MasterPlanSet 16
void edit_MasterPlan(void){
	Status.Main=EDIT_CHARTMENU_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
//	Flag.Timer_En=0;
	Value.DatamLast.LWord=Value.MasterPlan;
	load_edit_buffer(Value.DatamLast.LWord);
}
// Functoin CycleTimeMasterPlan 18
void edit_CycleTimeMasterPlan(void){
	Status.Main=EDIT_CYCLETIME;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = 0;
	Value.DatamLast.LWord=Value.CycleTimeMasterPlan;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_CycleTimeTarget(void){
	Status.Main=EDIT_CYCLETIME;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = 1;
	Value.DatamLast.LWord=Value.CycleTimeTarget;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_SummaryTime_mode(void){
	Status.Main=EDIT_SUMTIME_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	load_edit_buffer(0);
}
void edit_DownTime_mode(void){
	Status.Main=EDIT_DOWNTIME_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	load_edit_buffer(0);
}
void edit_SetPoint1(void){
	Status.Main=EDIT_ALS_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = 0;
	Value.DatamLast.LWord=Value.SetPoint1;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_SetPoint2(void){
	Status.Main=EDIT_ALS_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = 1;
	Value.DatamLast.LWord=Value.SetPoint2;
	load_edit_buffer(Value.DatamLast.LWord);
}
void edit_SetTime(void){
	Status.Main = EDIT_SETTIME;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	EditTimeBuffer[0] = RTC.Hours/10;
	EditTimeBuffer[1] = RTC.Hours%10;
	EditTimeBuffer[2] = RTC.Minutes/10;
	EditTimeBuffer[3] = RTC.Minutes%10;
	EditTimeBuffer[4] = RTC.Seconds/10;
	EditTimeBuffer[5] = RTC.Seconds%10;
}
void edit_SetDate(void){
	Status.Main=EDIT_SETDATE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	EditTimeBuffer[0] = RTC.Date/10;
	EditTimeBuffer[1] = RTC.Date%10;
	EditTimeBuffer[2] = RTC.Month/10;
	EditTimeBuffer[3] = RTC.Month%10;
	EditTimeBuffer[4] = RTC.Year/10;
	EditTimeBuffer[5] = RTC.Year%10;
}
void edit_GetTime(void){
	u8 sec,min,hour;
	hour 	= EditTimeBuffer[0]*0x10 + EditTimeBuffer[1];
	hour   |= 0x80;
	min 	= EditTimeBuffer[2]*0x10 + EditTimeBuffer[3];
	sec 	= EditTimeBuffer[4]*0x10 + EditTimeBuffer[5];
	write_time_rtc(SC_REG, sec);
	write_time_rtc(MN_REG, min);
	write_time_rtc(HR_REG, hour);
}
void edit_GetDate(void){
	u8 date,month,year;
	date	= EditTimeBuffer[0]*0x10 + EditTimeBuffer[1];
	month	= EditTimeBuffer[2]*0x10 + EditTimeBuffer[3];
	year	= EditTimeBuffer[4]*0x10 + EditTimeBuffer[5];

	write_time_rtc(DT_REG, date);
	write_time_rtc(MO_REG, month);
	write_time_rtc(YR_REG, year);
}
void edit_Chart_MENU_mode(u8 channel){
	Status.Main = EDIT_CHARTMENU_MODE;
	EditNum = 1;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	load_edit_buffer(channel+1);
}
void edit_Chart_Value_mode(u8 channel){
	u8 i;
	Status.Main = EDIT_CHARTVALUE_MODE;
	EditNum = channel;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	
	for(i=0;i<8;i++)
		// EditcharBuffer[i] = Value.Chart[i];
		EditcharBuffer[i] = Value.Chartxy[Value.Channel][i];
	
	if(EditcharBuffer[EditNum-1] >= 0x00 && EditcharBuffer[EditNum-1] <= 0x1F)
		EditSet = 0x00;
	else if(EditcharBuffer[EditNum-1] >= 0x20 && EditcharBuffer[EditNum-1] <= 0x3F)
		EditSet = 0x20;
	else if(EditcharBuffer[EditNum-1] >= 0x40 && EditcharBuffer[EditNum-1] <= 0x5F)
		EditSet = 0x40;
	else if(EditcharBuffer[EditNum-1] >= 0x60 && EditcharBuffer[EditNum-1] <= 0x7E)
		EditSet = 0x60;
}
void edit_Time_MENU_mode(u8 channel){
	Status.Main = EDIT_TIMEMENU_MODE;
	EditNum = 0;
	Flag.Edit = 1;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	load_edit_buffer(channel);
}
void edit_Time_En_mode(void){
	Status.Main = EDIT_TIMEEN_MODE;
	EditNum=1;
	Flag.Edit=1;
	Flag.Blink=0;
	Flag.BlinkEn=1;
	load_edit_buffer(Value.Time_EN);
}
void edit_Time_ON_mode(u8 channel){
	Status.Main = EDIT_TIMEON_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = channel;
	EditTimeBuffer[0] = Value.Time_ON[TIMER_CHANNEL_MAX-channel].H /10 %10;
	EditTimeBuffer[1] = Value.Time_ON[TIMER_CHANNEL_MAX-channel].H %10;
	EditTimeBuffer[2] = Value.Time_ON[TIMER_CHANNEL_MAX-channel].L /10 %10;
	EditTimeBuffer[3] = Value.Time_ON[TIMER_CHANNEL_MAX-channel].L %10;
}
void edit_Time_OFF_mode(u8 channel){
	Status.Main = EDIT_TIMEOFF_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = channel;
	EditTimeBuffer[0] = Value.Time_OFF[TIMER_CHANNEL_MAX-channel].H	/10 %10;
	EditTimeBuffer[1] = Value.Time_OFF[TIMER_CHANNEL_MAX-channel].H	%10;
	EditTimeBuffer[2] = Value.Time_OFF[TIMER_CHANNEL_MAX-channel].L	/10 %10;
	EditTimeBuffer[3] = Value.Time_OFF[TIMER_CHANNEL_MAX-channel].L	%10;
}
void edit_Time_RESET_mode(u8 channel){
	Status.Main = EDIT_TIMERESET_MODE;
	EditNum = 0;
	Flag.Edit = 0;
	Flag.Blink = 0;
	Flag.BlinkEn = 1;
	Value.Channel = channel;
	EditTimeBuffer[0] = Value.Time_Reset[TIMER_CHANNEL_MAX-channel].H /10 %10;
	EditTimeBuffer[1] = Value.Time_Reset[TIMER_CHANNEL_MAX-channel].H %10;
	EditTimeBuffer[2] = Value.Time_Reset[TIMER_CHANNEL_MAX-channel].L /10 %10;
	EditTimeBuffer[3] = Value.Time_Reset[TIMER_CHANNEL_MAX-channel].L %10;
}
void reload_Time_mode(u16 *val){
	// Word16_uType time;
	*val = 			((EditTimeBuffer[0]*10) + EditTimeBuffer[1]);
	*val = *val<<8|	((EditTimeBuffer[2]*10) + EditTimeBuffer[3]);
	// *val = time.Word;
}
void cal_analog_mode(void){
	Status.Main=CAL_ANALOG_MODE;
	Flag.CalAnalog=1;
	Flag.Edit=0;
	Flag.CalPoint=0;
}
void check_cal_analog(void){
	if(Status.Main!=OPERATE_MODE) return;
	if(!Flag.CalAnalog){
		if((EditNum>=1)&&(++Value.CalAnTimeOut>50)){
			if((EditBuffer[0]=1)&&(EditBuffer[1]==6)&&(EditBuffer[2]==3)&&(EditBuffer[3]==4)){
				cal_analog_mode();
			}
		}
	}
}
void save(void){
	u8 i;
	switch(Status.Main){
		case EDIT_ADDRESS_MODE:
			if(Value.DatamLast.LWord!=Value.SlaveAddress){
				write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
			}
			break;
		case EDIT_BAUDRATE_MODE:
			if(Value.DatamLast.LWord!=Value.Baudrate){
				write_eeprom(EEP_BAUDRATE, Value.Baudrate);
			}
			break;
		case EDIT_PARITY_MODE:
			if(Value.DatamLast.LWord!=Value.Parity){
				write_eeprom(EEP_PARITY, Value.Parity);
			}
			break;
		case EDIT_TARGET:
			if(Value.DatamLast.LWord!=Value.Target){
				write_ram_RTC(RAM_TARGET_,(u8 *)& Value.Target,4);
				write_eeprom(EEP_TARGET, Value.Target);
			}
			break;
		case EDIT_ACTUAL1:
			if(Value.DatamLast.LWord!=Value.Actual1){
				write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
				write_eeprom(EEP_ACTUAL1, Value.Actual1);
			}
			break;
		case EDIT_MUL_MODE:
				if(Value.DatamLast.LWord!=Value.Multiplier1)
					write_eeprom(EEP_MUL1, Value.Multiplier1);
			break;
		case EDIT_DIV_MODE:
				if(Value.DatamLast.LWord!=Value.Divisor1)
					write_eeprom(EEP_DIV1, Value.Divisor1);
			break;
		case EDIT_INPUT_DELAY:
			if(Value.DatamLast.LWord!=Value.InputDelay){
				write_eeprom(EEP_INPUTDELAY, Value.InputDelay);
			}
			break;
		case EDIT_TIMEEN_MODE:
			if(Value.DatamLast.LWord!=Value.Time_EN){
				write_eeprom(EEP_TIME_EN, Value.Time_EN);
			}
			break;
		case EDIT_TIMEON_MODE:
			if(Value.DatamLast.LWord!=Value.Time_ON[TIMER_CHANNEL_MAX-Value.Channel].Word){
				// write_eeprom_timer(EEP_TIMEON_00, Value.Channel, &Value.Time_ON[TIMER_CHANNEL_MAX-Value.Channel].Word);
				write_eeprom(EEP_TIMEON_00 + (Value.Channel * 2), Value.Time_ON[TIMER_CHANNEL_MAX-Value.Channel].Word);
			}
			break;
		case EDIT_TIMEOFF_MODE:
			if(Value.DatamLast.LWord!=Value.Time_OFF[TIMER_CHANNEL_MAX-Value.Channel].Word){
				// write_eeprom_timer(EEP_TIMEOFF_00, Value.Channel, &Value.Time_OFF[TIMER_CHANNEL_MAX-Value.Channel].Word);
				write_eeprom(EEP_TIMEOFF_00 + (Value.Channel * 2), Value.Time_OFF[TIMER_CHANNEL_MAX-Value.Channel].Word);
			}
			break;
		case EDIT_TIMERESET_MODE:
			if(Value.DatamLast.LWord!=Value.Time_Reset[TIMER_CHANNEL_MAX-Value.Channel].Word){
				// write_eeprom_timer(EEP_TIMERESET_00, Value.Channel, &Value.Time_Reset[TIMER_CHANNEL_MAX-Value.Channel].Word);
				write_eeprom(EEP_TIMERESET_00 + (Value.Channel * 2), Value.Time_Reset[TIMER_CHANNEL_MAX-Value.Channel].Word);
			}
			break;
		case EDIT_SUMTIME_MODE:
				write_eeprom(EEP_SUMMARYTIME_DAY,		Value.SummaryTimeDay);
				write_eeprom(EEP_SUMMARYTIME_HOUR,		Value.SummaryTimeHour);
				write_eeprom(EEP_SUMMARYTIME_MINUTE,	Value.SummaryTimeMinute);
				write_eeprom(EEP_SUMMARYTIME_SECOND,	Value.SummaryTimeSecond);
			break;
		case EDIT_DOWNTIME_MODE:
				write_eeprom(EEP_DOWNTIME_DAY,		Value.DownTimeDay);
				write_eeprom(EEP_DOWNTIME_HOUR,		Value.DownTimeHour);
				write_eeprom(EEP_DOWNTIME_MINUTE,	Value.DownTimeMinute);
				write_eeprom(EEP_DOWNTIME_SECOND,	Value.DownTimeSecond);
			break;
		case EDIT_ALS_MODE:
			if(Value.Channel == 0){
				if(Value.DatamLast.LWord!=Value.SetPoint1){
					write_eeprom_32(EEP_SETPOINT1_H,&Value.SetPoint1);
					}
				}
			else if(Value.Channel == 1){
				if(Value.DatamLast.LWord!=Value.SetPoint2){
					write_eeprom_32(EEP_SETPOINT2_H,&Value.SetPoint2);
					}
				}
			break;
		case EDIT_CYCLETIME:
			if(Value.Channel == 0){
				if(Value.DatamLast.LWord!=Value.CycleTimeMasterPlan){
					write_ram_RTC(RAM_CYCLEPLAN_,(u8 *)& Value.CycleTimeMasterPlan,2);
					write_eeprom(EEP_CYCLEPLAN,Value.CycleTimeMasterPlan);
					}
				}
			else if(Value.Channel == 1){
				if(Value.DatamLast.LWord!=Value.CycleTimeTarget){
					write_ram_RTC(RAM_CYCLETARGET_,(u8 *)& Value.CycleTimeTarget,2);
					write_eeprom(EEP_CYCLETARGET,Value.CycleTimeTarget);
					}
				}
			break;
		case EDIT_INPUT_TYPE:
			if(Value.DatamLast.LWord != Value.InputType){
				write_eeprom(EEP_INPUT_TYPE, Value.InputType);
			}
			break;
		case EDIT_CHARTMENU_MODE:
				Value.ChartN = reload_edit_buffer()-1;
				write_eeprom(EEP_CHART_CHANN, Value.ChartN);
			break;
		case EDIT_CHARTVALUE_MODE:
			for(i=0;i<8;i++){
				Value.Chartxy[Value.Channel][i] = EditcharBuffer[i];
				write_eeprom(EEP_CHART_ASCII + ((i*2) + (Value.Channel*128)), Value.Chartxy[Value.Channel][i]);
				// write_eeprom(EEP_CHART_ASCII + (i*2), Value.Chart[i]);
			} 
			break;
		case EDIT_DP_MODE:
			write_eeprom(EEP_DP, Value.DecimalPoint);
			break;
	}
}
void Alarm_4_Function(s32 val, s32 mode, s32 high, s32 low, s32 conn, u8 *Pin){
	switch(mode){
		case 0:
			*Pin  = 0;
			break;
		case 1:
			if(*Pin ==0 )	{ if( (val >= high)	|| (val <= low) )			       { *Pin  = 1; } }
			else			{ if( (val < (high - conn))	&& (val > (low + conn)) )  { *Pin  = 0; } }
			break;
		case 2:
			if(*Pin ==0 )	{ if( (val >= high) )		   { *Pin  = 1; } }
			else			{ if( (val < (high - conn)) )  { *Pin  = 0; } }
			break;
		case 3:
			if(*Pin ==0 )	{ if( (val <= low) )		 { *Pin  = 1; } }
			else			{ if( (val > (low + conn)) ) { *Pin  = 0; } }
			break;
		case 4:
			if(*Pin ==0 )	{ if( (val <= high)	&& (val >= low) )				    { *Pin  = 1; } }
			else			{ if( (val > (high + conn))	 || (val < (low - conn)) )	{ *Pin  = 0; } }
			break;
		}
}
void AlarmOutput(void){
	Alarm_4_Function(Value.Actual1, 2, Value.Target, 0, 0, &StatusAlarm[0]);
	Alarm_4_Function(Value.Actual1, 2, Value.Target, 0, 0, &StatusAlarm[1]);
	Alarm_4_Function(Value.Actual1, 2, Value.Target, 0, 0, &StatusAlarm[2]);
	if(OUT1 != StatusAlarm[0]){
		OUT1 = StatusAlarm[0];
		if(!OUT1)edit_Warning_Mode(WN_ALARM);
	}
	if(OUT2 != StatusAlarm[1]){
		OUT2 = StatusAlarm[1];
		if(!OUT2)edit_Warning_Mode(WN_ALARM);
	}
	if(OUT3 != StatusAlarm[2]){
		OUT3 = StatusAlarm[2];
		if(!OUT3)edit_Warning_Mode(WN_ALARM);
	}
	if(!Value.CycleTimeTarget || Value.BreakStatus){
		}
	else{
		if(++WorkingProgram>=Value.CycleTimeTarget*100){
			WorkingProgram = 0;
			if(Value.Target < 99999){
				Value.Target ++;
				write_ram_RTC(RAM_TARGET_, (u8 *)&Value.Target, 4);
				}
			}
		}
}
void TimeOnOffReset(void){
	u8 i;
	if(Value.Time_EN==1){
		if(++X_Time_ON_OFF>=25){
			X_Time_ON_OFF = 0;
			for(i=0;i<10;i++){
				BreakOn.Word = Value.Time_OFF[i].Word;
				BreakOff.Word = Value.Time_ON[i].Word;
				ResetTime.Word = Value.Time_Reset[i].Word;
				if(RTC.Hours == BreakOn.H && RTC.Minutes== BreakOn.L && RTC.Seconds== 0){
					//operate_mode();
					Value.BreakStatus = SET;
					edit_Warning_Mode(WN_TIMEOFF);
					}
				if(RTC.Hours == BreakOff.H && RTC.Minutes== BreakOff.L && RTC.Seconds== 0){
					// operate_mode();
					Value.BreakStatus = DIS;
					edit_Warning_Mode(WN_TIMEON);
					}
				if(RTC.Hours == ResetTime.H && RTC.Minutes== ResetTime.L && RTC.Seconds== 0){
					if(Value.Actual1>0){
						Value.Actual1 = 0;
						write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
						edit_Warning_Mode(WN_TIMERESET);
						}
					}
				}
			}
		}
}
void TimerCounter(void){
	Value.DayOfWeek = RTC.Day;
	Value.Date 		= RTC.Date;
	Value.Month 	= RTC.Month;
	Value.Year 		= RTC.Year;
	Value.Hour 		= RTC.Hours;
	Value.Minute 	= RTC.Minutes;
	Value.Second 	= RTC.Seconds;

	Value.DownTimeStatus = !_RB1? 1 : 0;
	Value.Deff = Value.Actual1 - Value.Target;

	if(Value.DownTimeMiliSecond >= 1000){
		Value.DownTimeMiliSecond = 0;
		Value.DownTimeSecond ++;
		write_eeprom(EEP_DOWNTIME_SECOND, Value.DownTimeSecond);
	}
	if(Value.DownTimeSecond >= 60){
		Value.DownTimeSecond = 0;
		Value.DownTimeMinute ++;
		write_eeprom(EEP_DOWNTIME_MINUTE, Value.DownTimeMinute);
	}
	if(Value.DownTimeMinute >= 60){
		Value.DownTimeMinute = 0;
		Value.DownTimeHour ++;
		write_eeprom(EEP_DOWNTIME_HOUR, Value.DownTimeHour);
	}
	if(Value.DownTimeHour >= 24){
		Value.DownTimeHour = 0;
		Value.DownTimeDay ++;
		write_eeprom(EEP_DOWNTIME_DAY, Value.DownTimeDay);
	}
	if(Value.DownTimeDay >= 1000){
		Value.DownTimeDay = 0;
	}

	if(Value.SummaryTimeMiliSecond >= 1000){
		Value.SummaryTimeMiliSecond = 0;
		Value.SummaryTimeSecond ++;
		write_eeprom(EEP_SUMMARYTIME_SECOND, Value.SummaryTimeSecond);
	}
	if(Value.SummaryTimeSecond >= 60){
		Value.SummaryTimeSecond = 0;
		Value.SummaryTimeMinute ++;
		write_eeprom(EEP_SUMMARYTIME_MINUTE, Value.SummaryTimeMinute);
	}
	if(Value.SummaryTimeMinute >= 60){
		Value.SummaryTimeMinute = 0;
		Value.SummaryTimeHour ++;
		write_eeprom(EEP_SUMMARYTIME_HOUR, Value.SummaryTimeHour);
	}
	if(Value.SummaryTimeHour >= 24){
		Value.SummaryTimeHour = 0;
		Value.SummaryTimeDay ++;
		write_eeprom(EEP_SUMMARYTIME_DAY, Value.SummaryTimeDay);
	}
	if(Value.SummaryTimeDay >= 1000){
		Value.SummaryTimeDay = 0;
	}


}
void trig_0(void){	// Reset
	switch(Trig0.Status){
		case TRIG:
			if(!_RB0){
				Trig0.HoldTime=CLR;
				Trig0.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB0){
				if(++Trig0.HoldTime >= 10){
					//trig
					if(Value.Actual1>0){
						Value.Actual1 = 0;
						write_ram_RTC(RAM_ACTUAL1_,(u8 *)&Value.Actual1,4);
						}
					Trig0.HoldTime=CLR;
					Trig0.Status=RELEASE;
				}
			}
			else{
					//no trig
				Trig0.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB0){
			if(!Flag.Timer_En){
				Flag.Timer_En=1;
			}
				Trig0.Status=TRIG;
			}
			break;
	}
}
void trig_1(void){	// Down Time
#if 1
	switch(Trig1.Status){
		case TRIG:
			if(!_RB1){
				Trig1.HoldTime=CLR;
				Trig1.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB1){
				if(++Trig1.HoldTime>= 10){
					/*trig*/
					Trig1.HoldTime=CLR;
					Trig1.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig1.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB1){
				Trig1.Status=TRIG;
			}
			else{
				Value.DownTimeMiliSecond += 10;
			}
			break;
	}
	#endif
}
u16 flagInput(u8 type){
	return !type? Value.InputDelay : 200 ;
}
void trig_2(void){	// Input A1
	switch(Trig2.Status){
		case TRIG:
			if(!_RB2){
				Trig2.HoldTime=CLR;
				Trig2.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB2){
				if(++Trig2.HoldTime>= flagInput(Value.InputType)){
					/*trig*/
					if(++Value.DivA1>=Value.Divisor1){
						Value.DivA1 = 0;
						if(Value.Actual1+Value.Multiplier1<=SEG_LIMITMAX){
							Value.Actual1 += Value.Multiplier1;
							// Flag.Timer_En = 1;
							write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//							write_eeprom(EEP_ACTUAL1, Value.Actual1);
							}
						}
					Trig2.HoldTime=CLR;
					Trig2.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig2.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB2){
				Trig2.Status=TRIG;
			}
			break;
	}
}
void trig_3(void){	// Input A2
	switch(Trig3.Status){
		case TRIG:
			if(!_RB3){
				Trig3.HoldTime=CLR;
				Trig3.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB3){
				if(++Trig3.HoldTime>= flagInput(Value.InputType)){
					/*trig*/
					if(++Value.DivA2>=Value.Divisor1){
						Value.DivA2 = 0;
						if(Value.Actual1+Value.Multiplier1<=SEG_LIMITMAX){
							Value.Actual1 += Value.Multiplier1;
							// Flag.Timer_En = 1;
							write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//							write_eeprom(EEP_ACTUAL1, Value.Actual1);
							}
						}
					Trig3.HoldTime=CLR;
					Trig3.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig3.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB3){
				Trig3.Status=TRIG;
			}
			break;
	}
}
void trig_4(void){	// Input B1
	switch(Trig4.Status){
		case TRIG:
			if(!_RB4){
				Trig4.HoldTime=CLR;
				Trig4.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB4){
				if(++Trig4.HoldTime>=flagInput(Value.InputType)){
					/*trig*/
					if(++Value.DivB1>=Value.Divisor1){
						Value.DivB1 = 0;
						if(Value.Actual1 - Value.Multiplier1 >= SEG_LIMITMIN){
							Value.Actual1 -= Value.Multiplier1;
							// Flag.Timer_En = 1;
							write_ram_RTC(RAM_ACTUAL1_,(u8 *)& Value.Actual1,4);
//							write_eeprom(EEP_ACTUAL1, Value.Actual1);
							}
						}
					Trig4.HoldTime=CLR;
					Trig4.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig4.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB4){
				Trig4.Status=TRIG;
			}
			break;
	}
}
#if 0
void trig_5(void){
	switch(Trig5.Status){
		case TRIG:
			if(!_RB5){
				Trig5.HoldTime=CLR;
				Trig5.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RB5){
				if(++Trig5.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig5.HoldTime=CLR;
					Trig5.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig5.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RB5){
				Trig5.Status=TRIG;
			}
			break;
	}
}
void trig_6(void){
	switch(Trig6.Status){
		case TRIG:
			if(!_RC13){
				Trig6.HoldTime=CLR;
				Trig6.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC13){
				if(++Trig6.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig6.HoldTime=CLR;
					Trig6.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig6.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC13){
				Trig6.Status=TRIG;
			}
			break;
	}
}
void trig_7(void){
	switch(Trig7.Status){
		case TRIG:
			if(!_RC14){
				Trig7.HoldTime=CLR;
				Trig7.Status=DEBOUNCE;
			}
			break;
		case DEBOUNCE:
			if(!_RC14){
				if(++Trig7.HoldTime>=Value.InputDelay){
					/*trig*/
					Trig7.HoldTime=CLR;
					Trig7.Status=RELEASE;
				}
			}
			else{
					/*no trig*/
				Trig7.Status=RELEASE;
			}
			break;
		case RELEASE:
			if(_RC14){
				Trig7.Status=TRIG;
			}
			break;
	}
}
#endif
