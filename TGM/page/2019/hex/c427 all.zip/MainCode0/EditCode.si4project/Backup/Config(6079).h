#ifndef CONFIG

#if 1
#define	SIZE_S
#endif
#if 0
#define	SIZE_M
#endif
#if 0
#define	SIZE_L
#endif
#if 0
#define	SIZE_XL
#endif

#ifdef SIZE_S
#define SIZE_2_3_INCH
#elif defined SIZE_M
#define SIZE_4_INCH
#elif defined SIZE_L
#define SIZE_8_INCH
#else
#define SIZE_12_INCH
#endif

#define	_T1ON	T1CONbits.TON
#define	_T2ON	T2CONbits.TON
#define	_T3ON	T3CONbits.TON
#define	_T4ON	T4CONbits.TON

#define	DS1307_R		0b11010001
#define	DS1307_W		0b11010000

#define	IrDataLogic_0	0x0050


#define	TMR1_PERIOD	0x0240
#define	TMR2_PERIOD	0xFFFF
#define	TMR3_PERIOD	0x0006
#define	TMR4_PERIOD	0xE100

#define	TIME4SEC	400
#define	TIME2SEC	200
#define	TIME1SEC	100
#define	TIME500mSEC	50
#define	TIME250mSEC	25
#define	TIME100mSEC	10
#define	TIME50mSEC	5
#define	TIME20mSEC	2
#define	TBLINK	50

#define	RX_START			0x3A
#define	RX_STOP				0x0D
#define	DOT					0x2E
#define	MINUS				0x2D
#define	PLUS				0x2B

#define	SEG_SPEED			0
#define	SEG_TARGET			3
#define	SEG_ACTUAL1			3+6
#define	SEG_ACTUAL3			17

#define	SEG_LIMITMAX		999999
#define	SEG_LIMITMIN		-199999

#define	EDIT_LENGTH			6
#define	SEGMENT_COLUMN		3
#define	SEGMENT_LENGTH		15
#define	MATRIX_COLUMN		5
#define	MATRIX_LENGTH		5
#define	MATRIX_LENG			5
#define	TIME_RESET_LENGTH	2
#define	PROGRAM_LENGTH		20
#define	SLAVE_ADDR			10

#define	CD4051_A	_RB6
#define	CD4051_B	_RB7
#define	ADC_CS	_RB8

#define	OUT1	_RD1
#define	OUT2	_RD3
#define	OUT3	_RD2

#define	ST_CLK	_RE0
#define	SER		_RE1
#define	SH_CLK	_RE2
#define	RD_485	_RE3

#define	STR 	_RD0
#define	DAT 	_RE4
#define	CLK		_RF0

#define 	SDAIO	_TRISF1
#define	SDA		_RF1
#define	SCL		_RE5

#define	EEPROM_OFFSET			0x7FFC00
#define EEP_PROGRAM_HOURS		0x0000
#define EEP_PROGRAM_MINUTES	0x0028
#define EEP_PROGRAM_EVENT		0x0050
#define EEP_T_RESET_HOURS		0x0002
#define EEP_T_RESET_MINUTES	0x0004
#define EEP_MUL					0x0006
#define EEP_DIV					0x0008
#define EEP_SV					0x0008

#define EEP_SCALE_HI_HW		0x000A
#define EEP_SCALE_HI_LW		0x000C

#define EEP_SCALE_LO_HW		0x0010
#define EEP_SCALE_LO_LW		0x0012
#define EEP_RST_MODE			0x0014
#define EEP_DP					0x0016
#define EEP_RTU					0x0018
#define EEP_SLAVE_ADDRESS		0x001A
#define EEP_BAUDRATE			0x001C
#define EEP_PARITY				0x001E
#define EEP_BITS					0x0020
//#define EEP_DELAY_POLLS		0x0020
#define EEP_INPUTDELAY		0x0022

#define EEP_TARGET_H			0x0024
#define EEP_ACTUAL1_H			0x0026
#define EEP_ACTUAL2_H			0x0026
#define EEP_ACTUAL3_H			0x0028

#define EEP_TARGET				0x002A
#define EEP_ACTUAL1				0x002E
#define EEP_ACTUAL2				0x0030
#define EEP_ACTUAL3				0x0032

#define EEP_MUL1				0x0034
#define EEP_MUL2				0x0036
#define EEP_MUL3				0x0038
#define EEP_MUL4				0x003A
#define EEP_CYCLEPLAN			0x003E
#define EEP_CYCLETARGET		0x0040
#define EEP_TACT_R				0x0042

#define EEP_DIV1					0x0044
#define EEP_DIV2					0x0046
#define EEP_DIV3					0x0048
#define EEP_DIV4					0x004A
#define EEP_CYCLETARGET_L		0x004C
#define EEP_TACT_R_L			0x004E
#define EEP_SETTACTTIME		0x0050

#define EEP_SETPOINT1_H		0x0080
#define EEP_SETPOINT1_L			0x0082
#define EEP_SETPOINT2_H		0x0084
#define EEP_SETPOINT2_L			0x0086
#define EEP_SETPOINT3_H		0x0088
#define EEP_SETPOINT3_L			0x008A

#define EEP_SETPOINT1_M		0x008C
#define EEP_SETPOINT2_M		0x008E
#define EEP_SETPOINT3_M		0x0090

#define EEP_TIME_EN			0x00FE
#define TIME2400			6144
// EEPROM << TIME ON >> 0x0100 - 0x0120
#define EEP_TIMEON_00			0x0100
#define EEP_TIMEON_01			0x0102
#define EEP_TIMEON_02			0x0104
#define EEP_TIMEON_03			0x0106
#define EEP_TIMEON_04			0x0108
#define EEP_TIMEON_05			0x010A
#define EEP_TIMEON_06			0x010C
#define EEP_TIMEON_07			0x010E

#define EEP_TIMEON_08			0x0110
#define EEP_TIMEON_09			0x0112
#define EEP_TIMEON_10			0x0114
#define EEP_TIMEON_11			0x0116
#define EEP_TIMEON_12			0x0118
#define EEP_TIMEON_13			0x011A
#define EEP_TIMEON_14			0x011C
#define EEP_TIMEON_15			0x011E

#define EEP_TIMEON_16			0x0120
#define EEP_TIMEON_17			0x0122
#define EEP_TIMEON_18			0x0124
#define EEP_TIMEON_19			0x0126
#define EEP_TIMEON_20			0x0128
#define EEP_TIMEON_21			0x012A
#define EEP_TIMEON_22			0x012C
#define EEP_TIMEON_23			0x012E

#define EEP_TIMEON_24			0x0130
#define EEP_TIMEON_25			0x0132
#define EEP_TIMEON_26			0x0134
#define EEP_TIMEON_27			0x0136
#define EEP_TIMEON_28			0x0138
#define EEP_TIMEON_29			0x013A
#define EEP_TIMEON_30			0x013C
#define EEP_TIMEON_31			0x013E

// EEPROM << TIME OFF >> 0x0140 - 0x017F
#define EEP_TIMEOFF_00			0x0140
#define EEP_TIMEOFF_01			0x0142
#define EEP_TIMEOFF_02			0x0144
#define EEP_TIMEOFF_03			0x0146
#define EEP_TIMEOFF_04			0x0148
#define EEP_TIMEOFF_05			0x014A
#define EEP_TIMEOFF_06			0x014C
#define EEP_TIMEOFF_07			0x014E

#define EEP_TIMEOFF_08			0x0150
#define EEP_TIMEOFF_09			0x0152
#define EEP_TIMEOFF_10			0x0154
#define EEP_TIMEOFF_11			0x0156
#define EEP_TIMEOFF_12			0x0158
#define EEP_TIMEOFF_13			0x015A
#define EEP_TIMEOFF_14			0x015C
#define EEP_TIMEOFF_15			0x015E

#define EEP_TIMEOFF_16			0x0160
#define EEP_TIMEOFF_17			0x0162
#define EEP_TIMEOFF_18			0x0164
#define EEP_TIMEOFF_19			0x0166
#define EEP_TIMEOFF_20			0x0168
#define EEP_TIMEOFF_21			0x016A
#define EEP_TIMEOFF_22			0x016C
#define EEP_TIMEOFF_23			0x016E

#define EEP_TIMEOFF_24			0x0170
#define EEP_TIMEOFF_25			0x0172
#define EEP_TIMEOFF_26			0x0174
#define EEP_TIMEOFF_27			0x0176
#define EEP_TIMEOFF_28			0x0178
#define EEP_TIMEOFF_29			0x017A
#define EEP_TIMEOFF_30			0x017C
#define EEP_TIMEOFF_31			0x017E

#define EEP_TIMERESET			0x0180
#define EEP_TIMERESET_M		0x0182

#define EEP_TIME32_H			0x0184
#define EEP_TIME32_L			0x0186
/***************************************************************/


#define RAM_TARGET				0x000A
#define RAM_ACTUAL				0x000E

#define RAM_TARGET_		16
#define RAM_ACTUAL1_		20
#define RAM_ACTUAL2_		24
#define RAM_ACTUAL3_		28
#define RAM_ACTUAL2_R		32
#define RAM_ACTUAL3_R		36
#define RAM_CYCLEPLAN_		40
#define RAM_CYCLETARGET_	44

#define BUTTON_SET_TIME		0x0290
#define BUTTON_DSP				0x05D0
#define BUTTON_POWER			0x0A90
#define BUTTON_OP_MODE		0x0FD0
#define BUTTON_ADD				0x0A50
#define BUTTON_OSD				0x01D0
#define BUTTON_SIGN				0x0B90
#define BUTTON_F1				0x0150
#define BUTTON_F2				0x0E90
#define BUTTON_F3				0x03D0
#define BUTTON_F4				0x06D0
#define BUTTON_SCALE_PLUS		0x0490
#define BUTTON_SCALE_MINUS	0x0C90
#define BUTTON_VOL_PLUS		0x0090
#define BUTTON_VOL_MINUS		0x0890
#define BUTTON_CANCEL			0x02F0
#define BUTTON_MENU			0x0AF0
#define BUTTON_ENTER			0x03F0
#define BUTTON_DP				0x0270
#define BUTTON_0				0x0910
#define BUTTON_1				0x0010
#define BUTTON_2				0x0810
#define BUTTON_3				0x0410
#define BUTTON_4				0x0C10
#define BUTTON_5				0x0210
#define BUTTON_6				0x0A10
#define BUTTON_7				0x0610
#define BUTTON_8				0x0E10
#define BUTTON_9				0x0110

#define BIT0		0x0001
#define BIT1		0x0002
#define BIT2		0x0004
#define BIT3		0x0008
#define BIT4		0x0010
#define BIT5		0x0020
#define BIT6		0x0040
#define BIT7		0x0080
#define BIT8		0x0100
#define BIT9		0x0200
#define BIT10		0x0400
#define BIT11		0x0800
#define BIT12		0x1000
#define BIT13		0x2000
#define BIT14		0x4000
#define BIT15		0x8000


#ifndef _MACRO
#define togglebi(b,x) (b^=x)
#define sbi(b,x) (b|=x)
#define cbi(b,x) (b&=~x)
#define bis(b,x) (b&x)
#define bic(b,x) (!(b&x))
#endif

enum BAUDRATE{//	BR2400,					// = 0
					BR4800,  				// = 1
					BR9600,      				// = 2
					BR19200,    				// = 3
					BR38400,    				// = 4
					BR57600,    				// = 5
					BR115200   				// = 6
};
enum SETPOINTMODE
	{	SETPOINT_ACTUAL_,      				// = 0
		SETPOINT_TARGET_,    				// = 1
		SETPOINT_PLAN_,   					// = 2
};
enum PARITY{	b8n1,      					// = 0
				b8e1,      					// = 1
				b8o1     						// = 2
};
enum {	RTUs,								// = 0
		ASCII								// = 1
};
enum {	STRING,								// = 0
		VOLUE								// = 1
};
enum {	REQ_PV,      							// = 0
		RSP_PV,      							// = 1
		REQ_DP,      							// = 2
		RSP_DP     							// = 3
};
enum{	_W,     								// = 0
		_R     								// = 1
};
enum{	_BREAK,     							// = 0
		_RUN     								// = 1
};
enum{	RX,      								// = 0
		TX     								// = 1
};
enum{	DIS,     								// = 0
		EN    								// = 1
};
enum{	CLR,	     								// = 0
		SET 	   							// = 1
};
enum{	RISING,     							// = 0
		FALLING    							// = 1
};
enum{	OUTPUT,     							// = 0
		INPUT    							// = 1
};
enum{	_FALSE, 	    						// = 0
		_TRUE    							// = 1
};
enum{	TRIG,     								// = 0
		DEBOUNCE,     						// = 1
		RELEASE    							// = 2
};
enum {	
		ST_CHECK,							// = 0
		ST_INC,     						// = 1
		ST_DEC,    							// = 2
		ST_RELEASE,							// = 2
};

enum{	ILLEGAL_FUNCTION=1,     				// = 0
		ILLEGAL_DATA_ADDRESS,     			// = 1
		ILLEGAL_DATA_VALUE    				// = 2
};
enum{	PRIORITY_1=1,     					// = 0
		PRIORITY_2,     						// = 1
		PRIORITY_3,     						// = 2
		PRIORITY_4,     						// = 3
		PRIORITY_5,     						// = 4
		PRIORITY_6,     						// = 5
		PRIORITY_7    						// = 6
};
enum{	Monday,    							// = 0
		Tuesday,    							// = 1
		Wednesday,    						// = 2
		Thursday,    							// = 3
		Friday,    							// = 4
		Saterday,    							// = 5
		Sunday   							// = 6
};
enum IPType{
		SWITCH,				// = 0
		S_NPN,				// = 1
		S_PNP				// = 2
};
enum{	January,  							// = 0
		February,  							// = 1
		March,	  							// = 2
		April,  								// = 3
		May,   								// = 4
		June,   								// = 5
		July,   								// = 6
		August,  							// = 7
		September,  							// = 8
		October,  							// = 9
		November,   							// = 10
		December  							// = 11
};
enum{SECONDS_REG,  						// = 0
	MINUTES_REG,	  						// = 1
	HOURS_REG,  							// = 2
	DAY_REG,  								// = 3
	DATE_REG,  								// = 4
	MONTH_REG,  							// = 5
	YEAR_REG, 								// = 6
	CONTROL_REG,  							// = 7
	RAM_REG 								// = 8
};


enum{INIT_MODE, 						// =  0
	OPERATE_MODE, 						// =  1
	
	EDIT_PROTOCOL_MODE, 				// =  2
	EDIT_MUL_MODE, 						// =  3
	EDIT_DIV_MODE, 						// =  4
	EDIT_DP_MODE,  						// =  5
	EDIT_INPUT_DELAY, 					// =  6
	
	EDIT_ADDRESS_MODE,  				// =  7
	EDIT_BAUDRATE_MODE,  				// =  8
	EDIT_PARITY_MODE,  					// =  9
	
	
	EDIT_DELAY_POLLS_MODE,  			// = 10
	EDIT_RESPONSE_TIMEOUT_MODE,  		// = 11
	CAL_ANALOG_MODE,  					// = 12
	IDLE_MODE,		 					// = 13
	
	EDIT_TARGET,						// = 14
	EDIT_ACTUAL1,						// = 15
	EDIT_ACTUAL3,						// = 16
	EDIT_ACTUAL4,						// = 17
	
	EDIT_CYCLETIME,						// = 18
	EDIT_TIMERESET,						// = 19
	EDIT_SETTIME,						// = 20
	
	EDIT_BREAK_OFF,						// = 21
	EDIT_BREAK_ON,						// = 22
	EDIT_BREAK_EN,						// = 23
	EDIT_SETTACTTIME,					// = 24
	
	EDIT_ALM_MODE,						// = 25
	EDIT_ALH_MODE,						// = 26
	EDIT_ALL_MODE,						// = 27
	EDIT_ALC_MODE,						// = 28
	EDIT_ALS_MODE,						// = 29
};
enum COIL_ADDRESS{
	 COIL_001B=0x0000,						// = 0
	 COIL_002B,	 							// = 1
	 COIL_003B,	 							// = 2	
	 COIL_004B,	 		 					// = 3
	 COIL_005B,	 		 					// = 4
	 COIL_006B,	 		 					// = 5
	 COIL_007B,	 		 					// = 6
	 COIL_008B,	 		 					// = 7
	 COIL_009B,	 		 					// = 8
	 COIL_010B		 						// = 9
};
enum MB_FUNC{
	READ_COILS=1, 										// = 01
	READ_DISCRETE_INPUT,  								// = 02
	READ_HOLDING_REGISTERS,  							// = 03
	READ_INPUT_REGISTERS,  							// = 04
	WRITE_SINGLE_COIL,  								// = 05
	WRITE_SINGLE_REGISTER,  							// = 06
	READ_EXCEPTION_STATUS,  							// = 07
	DIAGNOSTICS,  										// = 08
	RESERVED_COMMAND1,  								// = 09
	RESERVED_COMMAND2,  								// = 0A
	GET_COMM_EVENT_COUNTER, 							// = 0B
	GET_COMM_EVENT_LOG, 								// = 0C
	RESERVED_COMMAND3,  								// = 0D
	RESERVED_COMMAND4,  								// = 0E
	WRITE_MULTIPLE_COIL,  								// = 0F
	WRITE_MULTIPLE_REGISTER,  						// = 10
};

enum ISL{
	SC_REG,
	MIN_REG,
	HR_REG,
	DT_REG,
	MO_REG,
	YR_REG,
	DW_REG,
	SR_REG,
	INT_REG
};
enum REGISTER_ADDRESS{
	 DATA_SEG_1_REGS=0x0000,
	 DATA_SEG_2_REGS,	 	
	 DATA_SEG_3_REGS,	 	
	 DATA_SEG_4_REGS,	
	 DATA_SEG_5_REGS,
	 DATA_SEG_6_REGS
	
};
enum{
	CHAR21,  						// = 5
	CHAR43,  						// = 6
	CHAR65,  						// = 7
	CHARB7,							// = 8
	BATCH, 						// = 0
	BATCH_DP, 						// = 1
	DUMP,  							// = 2
	DUMP_DP,  						// = 3
	TIME_16,  						// = 4
};
enum{	ADDw_E,
		DATAw_E,
		ADDr_E,
};
enum{GRADE_A_REG, 						// = 0
	GRADE_C_RJ_REG, 						// = 1
	SUMMARY_REG,  							// = 2
	PERCENT_GRADE_C_REG,  				// = 3
	MULTIPLIER_REG,  						// = 4
	DIVISOR_REG,  							// = 5
	DECIMAL_REG, 							// = 6
	COIL_1,									// = 7
	COIL_2,									// = 8
	COIL_3									// = 9
};
enum{ 	IN_NUM1,							// = 0
		IN_NUM2,							// = 1
		SUM_MODE,							// = 2
};
#endif
