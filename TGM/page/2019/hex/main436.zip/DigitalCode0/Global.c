#ifndef GLOBAL_C
#include "config.h"
#include "typedef.h" 
 
u8 MainStatus;
u8 TimeUpdateRTC;
u16 TimeBlink;
u32 TimeSwitch;
u16 MatrixDigit;
u16 X_Time_ON_OFF;
u16 X_Time_RESET;
Word16_uType BreakOn, BreakOff, ResetTime;
	
u8 StatusAlarm[3];
s8 MatrixData[MATRIX_LENGTH];
u8 Data_DIGR[8];
u8 Data_DIGG[8];
u8 SegmentDigit;
u8 SegmentData[SEGMENT_LENGTH];	// Segmant ALL 
u8 EditBuffer[EDIT_LENGTH];
u8 EditTimeBuffer[6];
u8 EditcharBuffer[8];
u8 EditNum;
u8 EditSet;
u16 Dp;
u8 ProgramIndex;
u8 TimeResetIndex;
u16 WorkingProgram;
u8 CurrentProgram;
s16 DataLastMB;
s8 DataLastChart[MATRIX_LENGTH];

u8 *MB_Dptr;

Status_sType Status;
IR_sType IrData;
Value_sType Value;
RTC_sType RTC;
MB_sType Modbus;
Trig_sType Trig0;
Trig_sType Trig1;
Trig_sType Trig2;
Trig_sType Trig3;
Trig_sType Trig4;
Trig_sType Trig5;
Trig_sType Trig6;
Trig_sType Trig7;
Program_sType TimeReset[2];
Program_sType TimeResetBuff[2];
Program_sType Program[20];
Program_sType ProgramBuff[20];
Flag_uType Flag;
ADC_sType ADC;
#endif

