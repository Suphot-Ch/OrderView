#include <p30f4011.h>
#include "config.h"
#include "global.h"
#include "segment.h"
#include "Matrix.h"
#define DELAYX	500
void nopDelay(u32 delay){
	u32 i;
	for(i = 0;i < delay;i++){
		Nop();Nop();Nop();Nop();Nop();
		Nop();Nop();Nop();Nop();Nop();
		// Delay(1);
	}
}
void shift_data(u8 *dptr){
	u8 i;
	for(i=0x80;i>0;i=i/2){
		SER=(i&*dptr) ? 1 : 0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=1;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
		SH_CLK=0;
		Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	}
}

void TPIC6B595_LATCH(u8 *dptr){
	u8 i;
	_TRISE0=0;
	_TRISE1=0;
	_TRISE2=0;
	
	ST_CLK=0;
	SH_CLK=0;
	for(i=0;i<SEGMENT_LENGTH;i++,dptr++){
//	for(i=0;i<MATRIX_COLUMN*MATRIX_LENGTH;i++,dptr++){
		shift_data(dptr);
	}
	ST_CLK=1;
	ST_CLK=0;
}
void TPIC6B595_scan(void){
	u8 i, data[SEGMENT_LENGTH];
	
	for(i=0; i<SEGMENT_LENGTH; i++){
		data[i]=0x00;
		data[i]=SegmentData[i];
		}
	TPIC6B595_LATCH(data);
}
#if 1
void shift_data2(u8 *dptr){
	u8 i;
	for(i=0x80;i>0;i=i/2){
		DAT=(i&*dptr) ? 0 : 1;
		nopDelay(DELAYX);
		CLK=1;
		nopDelay(DELAYX);
		CLK=0;
		nopDelay(DELAYX);
	}
}
void TPIC6B595_LATCH2(u8 *dptr){
	u8 i;
	_TRISD0=0;
	_TRISE4=0;
	_TRISF0=0;
	
	STR=0;
	CLK=0;
	nopDelay(DELAYX);
	for(i=0;i<MATRIX_LENGTH;i++,dptr++){
	// for(i=0;i<10;i++,dptr++){
		shift_data2(dptr);
	}
	nopDelay(DELAYX);
	STR=1;
	nopDelay(DELAYX);
	STR=0;
	nopDelay(DELAYX);
}
void HC595_SCAN(void){
	u8 i,j, data2[MATRIX_LENGTH];
	s8 data[8];
	/* Code from TGA-002 */
    // for(i=0;i<MATRIX_LENGTH;i++){
	// 	data[i] = MatrixData[i] - 32;
    //     for(j=0;j<MATRIX_COLUMN;j++){
	// 	data2[j + (i * 5)] = MAP_FONT[data[i]][MATRIX_COLUMN-1-j];
    //     }
	// }
	/* Test Tx Ship Data to Matrix 8x8 */
    // for(i=0;i<MATRIX_LENGTH/2;i++){
	// 	data[0+(i*2)] = 'A';//MatrixData[i];
	// 	data[1+(i*2)] = 'a';//MatrixData[i];
	// }
	/* Use */
    for(i=0;i<MATRIX_LENGTH;i++){
		data[i] = MatrixData[i];
	}
	TPIC6B595_LATCH2(data);
}
#endif
void TPIC6B595_init(void){  // Loop Segmant 0 - N
	u8 i;
	for(i=0;i<SEGMENT_LENGTH;i++){
		SegmentData[i]=FONT_BLANK;
	}
	for(i=0;i<MATRIX_LENGTH;i++){
		MatrixData[i] = ' ';
	}
}

