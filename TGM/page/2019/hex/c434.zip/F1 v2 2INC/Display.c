#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"
#include "matrix.h"

extern u8 XCTMasterPlan;
extern f32 Xpct;
const unsigned long Devide2[]={10,		1,		0,		0,		0,		0,		0};
const unsigned long Devide3[]={100,		10,		1,		0,		0,		0,		0};
const unsigned long Devide4[]={1000,	100,		10,		1,		0,		0,		0};
const unsigned long Devide5[]={10000,	1000,	100,		10,		1,		0,		0};
const unsigned long Devide6[]={100000,	10000,	1000,	100,		10,		1,		0};
const u8 NUM_MAP[]={
	/*b a f g e d c dp*/
	FONT_0,
	FONT_1,
	FONT_2,
	FONT_3,
	FONT_4,
	FONT_5,
	FONT_6,
	FONT_7,
	FONT_8,
	FONT_9,
	FONT_A,
	FONT_B,
	FONT_C,
	FONT_D,
	FONT_E,
	FONT_F,
	FONT_MINUS
};
const u8 NUM_MAP_[]={
	/*b a f g e d c dp*/
	FONT_0_,
	FONT_1_,
	FONT_2_,
	FONT_3_,
	FONT_4_,
	FONT_5_,
	FONT_6_,
	FONT_7_,
	FONT_8_,
	FONT_9_,
	FONT_A_,
	FONT_B_,
	FONT_C_,
	FONT_D_,
	FONT_E_,
	FONT_F_,
	FONT_MINUS_
};
const u8 ASCII_CHR[]={
	'0',
	'1',
	'2',
	'3',
	'4',
	'5',
	'6',
	'7',
	'8',
	'9',
	'A',
	'B',
	'C',
	'D',
	'E',
	'F'		
};

void display_page0(void);
void display_page1(void);
void display_page2(void);
void display_page3(void);
void display_page4(void);
void display_page5(void);
void display_page6(void);
void display_page7(void);
void display_page8(void);
void display_page9(void);
void display_page10(void);
void display_page11(void);
void display_page12(void);
void display_page13(void);
void display_page14(void);
void display_page15(void);
void display_page16(void);
void display_page17(void);
void display_page18(void);
void display_page19(void);
void display_page20(void);
void display_page21(void);
void display_page22(void);
void display_page23(void);
void display_page24(void);
void display_page25(void);
void display_page26(void);
void display_page27(void);
void display_page28(void);
void display_page29(void);

void (*update_segment_page[])(void)={
	display_page0,     								// = 0
	display_page1,     								// = 1
	display_page2,     								// = 2
	display_page3,     								// = 3
	display_page4,     								// = 4
	display_page5,     								// = 5
	display_page6,     								// = 6
	display_page7,     								// = 7
	display_page8,     								// = 8
	display_page9,     								// = 9
	display_page10,     								// = 10
	display_page11,     								// = 11
	display_page12,     								// = 12
	display_page13,     								// = 13
	display_page14,     								// = 14
	display_page15,     								// = 15
	display_page16,     								// = 16
	display_page17,     								// = 17
	display_page18,     								// = 18
	display_page19,     								// = 19
	display_page20,     								// = 20
	display_page21,     								// = 21
	display_page22,     								// = 22
	display_page23,     								// = 23
	display_page24,     								// = 24
	display_page25,     								// = 25
	display_page26,     								// = 26
	display_page27,     								// = 27
	display_page28,     								// = 28
	display_page29,     								// = 29
	
};

void blink(void){
	if(Flag.BlinkEn){
		if(++TimeBlink>=TBLINK){
			TimeBlink=CLR;
			Flag.Blink=Flag.Blink ? 0 : 1;
		}
	}
}

void set_char(u8 a, u8 b[a], u8* segment){
	u8 i;
	for(i=0;i<a;i++)
		*segment++=b[i];
}
void set_char_(u8 a, u8 b[a], u8* segment){
	u8 i;
	for(i=0;i<a;i++)
		*segment++=b[a-1-i];
}
void set_char_S3(u8 a, u8 b, u8 d, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment=d;
	
}
void set_char_S4(u8 a, u8 b, u8 c, u8 d, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment=d;
	
}
void set_char_S5(u8 a, u8 b, u8 c, u8 d, u8 e, u8* segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;
	*segment=e;	
}
void set_num_S_r3(s32 dec , u8 dp, u8 *segment){
	u8 Data[3],sign;
	s32 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
	Data[0]=Dat/Devide3[0]%10;
	Data[1]=Dat/Devide3[1]%10;
	Data[2]=Dat/Devide3[2]%10;
	
	if(!sign)	*segment++=(dp==2) ? (!Data[0] ? FONT_0|FONT_DP     : NUM_MAP[Data[0]]|FONT_DP)            : ((dp>2) ? NUM_MAP[Data[0]]            : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	else		*segment++=(dp==2) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>2) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
				*segment++=(dp==1) ? (!Data[1] ? FONT_0|FONT_DP     : NUM_MAP[Data[1]]|FONT_DP)            : ((dp>1) ? NUM_MAP[Data[1]]            : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
				*segment=NUM_MAP[Data[2]];
}
void set_num_S_r5(s32 dec , u8 dp, u8 *segment){
	u8 Data[6],sign;
	s32 Dat;
	sign=0;
	Dat=dec;
	if(Dat<0){
		sign=1;
		Dat =- Dat;
	}
	Data[0]=Dat/Devide5[0]%10;
	Data[1]=Dat/Devide5[1]%10;
	Data[2]=Dat/Devide5[2]%10;
	Data[3]=Dat/Devide5[3]%10;
	Data[4]=Dat/Devide5[4]%10;
	
	if(!sign)	*segment++=(dp==4) ? (!Data[0] ? FONT_0|FONT_DP : NUM_MAP[Data[0]]|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]] : (!Data[0] ? FONT_BLANK : NUM_MAP[Data[0]]));
	else		*segment++=(dp==4) ? (!Data[0] ? FONT_MINUS|FONT_DP : NUM_MAP[Data[0]]|FONT_MINUS|FONT_DP) : ((dp>4) ? NUM_MAP[Data[0]]|FONT_MINUS : (!Data[0] ? FONT_MINUS : NUM_MAP[Data[0]]|FONT_MINUS));
				*segment++=(dp==3) ? (!Data[1] ? FONT_0|FONT_DP : NUM_MAP[Data[1]]|FONT_DP) : ((dp>3) ? NUM_MAP[Data[1]] : (!Data[0]&&!Data[1] ? FONT_BLANK : NUM_MAP[Data[1]]));
				*segment++=(dp==2) ? (!Data[2] ? FONT_0|FONT_DP : NUM_MAP[Data[2]]|FONT_DP) : ((dp>2) ? NUM_MAP[Data[2]] : (!Data[0]&&!Data[1]&&!Data[2] ? FONT_BLANK : NUM_MAP[Data[2]]));
				*segment++=(dp==1) ? (!Data[3] ? FONT_0|FONT_DP : NUM_MAP[Data[3]]|FONT_DP) : ((dp>1) ? NUM_MAP[Data[3]] : (!Data[0]&&!Data[1]&&!Data[2]&&!Data[3] ? FONT_BLANK : NUM_MAP[Data[3]]));
				*segment=NUM_MAP[Data[4]];
}
void display_edit5(u8 dp, u8 *segment){
	u8 sign, n;
	sign=Flag.Sign;
	n = 5;
	if(!sign){
		*segment++=(dp==n-1) ? (!EditBuffer[EDIT_LENGTH - n] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_DP) : ((dp>n-1) ? NUM_MAP[EditBuffer[EDIT_LENGTH - n]] : (!EditBuffer[EDIT_LENGTH - 5] ? FONT_BLANK : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]));	n--;
		}
	else{
		*segment++=(dp==n-1) ? (!EditBuffer[EDIT_LENGTH - n] ? FONT_MINUS|FONT_DP : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_DP|FONT_MINUS) : ((dp>n-1) ? NUM_MAP[EditBuffer[EDIT_LENGTH - n]] : (!EditBuffer[EDIT_LENGTH - 5] ? FONT_MINUS: NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_MINUS));	n--;
		}
		*segment++=(dp==n-1) ? (!EditBuffer[EDIT_LENGTH - n] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_DP) : ((dp>n-1) ? NUM_MAP[EditBuffer[EDIT_LENGTH - n]] : (!EditBuffer[EDIT_LENGTH - 5]&&!EditBuffer[EDIT_LENGTH - 4] ? FONT_BLANK : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]));	n--;
		*segment++=(dp==n-1) ? (!EditBuffer[EDIT_LENGTH - n] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_DP) : ((dp>n-1) ? NUM_MAP[EditBuffer[EDIT_LENGTH - n]] : (!EditBuffer[EDIT_LENGTH - 5]&&!EditBuffer[EDIT_LENGTH - 4]&&!EditBuffer[EDIT_LENGTH - 3] ? FONT_BLANK : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]));	n--;
		*segment++=(dp==n-1) ? (!EditBuffer[EDIT_LENGTH - n] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]|FONT_DP) : ((dp>n-1) ? NUM_MAP[EditBuffer[EDIT_LENGTH - n]] : (!EditBuffer[EDIT_LENGTH - 5]&&!EditBuffer[EDIT_LENGTH - 4]&&!EditBuffer[EDIT_LENGTH - 3]&&!EditBuffer[EDIT_LENGTH - 2] ? FONT_BLANK : NUM_MAP[EditBuffer[EDIT_LENGTH - n]]));	n--;
		*segment=NUM_MAP[EditBuffer[EDIT_LENGTH - n ]];
}
void display_Clear(void){
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);
}
void display_page0(void){
	u8 i;
	blink();
	switch(Flag.Logo){
	case 0:
		set_char_S5(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_TARGET]);
		set_char_S5(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_ACTUAL1]);
		set_char_S5(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_DEFF]);
		for(i=0;i<8;i++)
			MatrixData[i] = 0x7F;
		break;
	case 1:
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);
		set_char(8,"        ",&MatrixData[0]);
		break;
	case 2:
		set_char_S5(FONT_T, FONT_G, FONT_MINUS, FONT_0, FONT_1, &SegmentData[SEG_TARGET]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_F, FONT_1, &SegmentData[SEG_ACTUAL1]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_V, FONT_2, &SegmentData[SEG_DEFF]);
		set_char(8,Value.Chart,&MatrixData[0]);
		break;
	case 3:
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);
		set_char(8,"        ",&MatrixData[0]);
		break;
	}
}
void display_page1(void){	// OPERATE_MODE
	u8 dis = OPERATE_MODE;
	display_Clear();
	u8 i;
	for(i=0;i<8;i++){
		DataLastChart[i] = Value.Chart[i];
	}
	set_char_(8,DataLastChart,&MatrixData[0]);
#if 1
	if(!Flag.Edit){
		if(Flag.BlinkEn){
			if(++TimeBlink >= TBLINK){
				TimeBlink = CLR;
				Flag.Edit = 1;
				}
			}
		}
	else {
		set_num_S_r5(Value.Target,	Value.DecimalPoint,	&SegmentData[SEG_TARGET]);
		set_num_S_r5(Value.Actual1,	Value.DecimalPoint,	&SegmentData[SEG_ACTUAL1]);
		if(Value.Deff>99999){
			set_char_S5(FONT_OVER, FONT_OVER, FONT_OVER, FONT_OVER, FONT_OVER, &SegmentData[SEG_DEFF]);
			}
		else if(Value.Deff<-19999){
			set_char_S5(FONT_E, FONT_R, FONT_R, FONT_O, FONT_R, &SegmentData[SEG_DEFF]);
			}
		else{
			set_num_S_r5(Value.Deff, Value.DecimalPoint, &SegmentData[SEG_DEFF]);
			}
		}
#endif
}
void display_page2(void){	// EDIT_WARNING_MODE
u8 dis = EDIT_WARNING_MODE;
	//display_Clear();
	switch(Value.WarningStatus){
		case WN_ALARM:
			set_char(8,"Alarm On", &MatrixData[0]);
			if(++TimeBlink>=200){
				TimeBlink=0;
				operate_mode();
			}
		break;
		case WN_TIMEOFF:
			set_char(8,"Time OFF", &MatrixData[0]);
			if(++TimeBlink>=200){
				TimeBlink=0;
				edit_Ide_mode();
			}
		break;
		case WN_TIMEON:
			set_char(8,"Time ON", &MatrixData[0]);
			if(++TimeBlink>=200){
				TimeBlink=0;
				operate_mode();
			}
		break;
		case WN_TIMERESET:
			set_char(8,"ResetACT", &MatrixData[0]);
			if(++TimeBlink>=200){
				TimeBlink=0;
				operate_mode();
			}
		break;
	}
}
void display_page3(void){	// EDIT_MUL_MODE
u8 dis = EDIT_MUL_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_M, FONT_U, FONT_L,&SegmentData[SEG_TARGET]);
	display_edit5(0,&SegmentData[SEG_ACTUAL1]);	
	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	
}
void display_page4(void){	// EDIT_DIV_MODE
u8 dis = EDIT_DIV_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_D, FONT_I, FONT_V, &SegmentData[SEG_TARGET]);
	display_edit5(0,&SegmentData[SEG_ACTUAL1]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page5(void){	// EDIT_DP_MODE
u8 dis = EDIT_DP_MODE;
	blink();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_D, FONT_P, FONT_BLANK, &SegmentData[SEG_TARGET]);
	display_edit5(0,&SegmentData[SEG_ACTUAL1]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page6(void){	// EDIT_INPUT_DELAY
u8 dis = EDIT_INPUT_DELAY;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_I, FONT_N, FONT_D, FONT_BLANK, &SegmentData[SEG_TARGET]);
	display_edit5(2,&SegmentData[SEG_ACTUAL1]);
	
	if(Flag.Edit&&Flag.Blink)
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	
}
void display_page7(void){	// EDIT_ADDRESS_MODE
u8 dis = EDIT_ADDRESS_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_A, FONT_D, FONT_D, FONT_BLANK, &SegmentData[SEG_TARGET]);
	display_edit5(0,&SegmentData[SEG_ACTUAL1]);
	if(Flag.Edit&&Flag.Blink)
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page8(void){	// EDIT_BAUDRATE_MODE
u8 dis = EDIT_BAUDRATE_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_B, FONT_P, FONT_S, FONT_BLANK, &SegmentData[SEG_TARGET]);
	switch(EditBuffer[EDIT_LENGTH-1]){
		case BR4800:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_4|FONT_DP, FONT_8, 	&SegmentData[SEG_ACTUAL1]);	break;
		case BR9600:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_9|FONT_DP, FONT_6, 	&SegmentData[SEG_ACTUAL1]);	break;
		case BR19200:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_1, FONT_9|FONT_DP, FONT_2, 	&SegmentData[SEG_ACTUAL1]);	break;
		case BR38400:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_3, FONT_8|FONT_DP, FONT_4, 	&SegmentData[SEG_ACTUAL1]);	break;
		case BR57600:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_5, FONT_7|FONT_DP, FONT_6, 	&SegmentData[SEG_ACTUAL1]);	break;
		}

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page9(void){	// EDIT_PARITY_MODE
u8 dis = EDIT_PARITY_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_C, FONT_O, FONT_M, FONT_M, &SegmentData[SEG_TARGET]);
	switch(EditBuffer[EDIT_LENGTH -1]){
		case b8n1:	set_char_S5(FONT_BLANK, FONT_B, FONT_8, FONT_N, FONT_1, &SegmentData[SEG_ACTUAL1]);		break;
		case b8o1:	set_char_S5(FONT_BLANK, FONT_B, FONT_8, FONT_O, FONT_1, &SegmentData[SEG_ACTUAL1]);		break;
		case b8e1:	set_char_S5(FONT_BLANK, FONT_B, FONT_8, FONT_E, FONT_1, &SegmentData[SEG_ACTUAL1]);		break;
		}
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page10(void){	// EDIT_DELAY_POLLS_MODE
u8 dis = EDIT_DELAY_POLLS_MODE;
	display_Clear();
}
void display_page11(void){	// EDIT_RESPONSE_TIMEOUT_MODE
u8 dis = EDIT_RESPONSE_TIMEOUT_MODE;
	display_Clear();
}
void display_page12(void){	// CAL_ANALOG_MODE 
u8 dis = CAL_ANALOG_MODE;
	display_Clear();
}
void display_page13(void){	// IDLE_MODE
u8 dis = IDLE_MODE;
	display_Clear();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_MINUS, &SegmentData[SEG_TARGET]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_MINUS, &SegmentData[SEG_ACTUAL1]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_MINUS, &SegmentData[SEG_DEFF]);
}
void display_page14(void){   // EDIT_TARGET
u8 dis = EDIT_TARGET;
	display_Clear();
	blink();
	display_edit5(Value.DecimalPoint,&SegmentData[SEG_TARGET]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
}
void display_page15(void){	// EDIT_ACTUAL1
u8 dis = EDIT_ACTUAL1;
	display_Clear();
	blink();
	display_edit5(Value.DecimalPoint,&SegmentData[SEG_ACTUAL1]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_TARGET]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);
	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page16(void){	// EDIT_CHARTMENU_MODE
u8 dis = EDIT_CHARTMENU_MODE;
	display_Clear();
	set_char(8, EditcharBuffer, &MatrixData[0]);
	set_char_S5(FONT_C, FONT_H, FONT_R, NUM_MAP[EditNum], FONT_BLANK, &SegmentData[SEG_TARGET]);
	SegmentData[SEG_TARGET + 4] = !Flag.Blink? SegmentData[SEG_TARGET + 4]:FONT_BLANK;
}
void display_page17(void){	// EDIT_CHARTVALUE_MODE
u8 dis = EDIT_CHARTVALUE_MODE;
	blink();
	display_Clear();
	set_char_(8, EditcharBuffer, &MatrixData[0]);
	set_char_S5(FONT_C, FONT_H, FONT_R, FONT_BLANK, NUM_MAP[EditNum], &SegmentData[SEG_TARGET]);
	if(Flag.Edit){
		switch(EditSet){
		case 0x20:	set_char_S5(FONT_2, FONT_0, FONT_MINUS, FONT_3, FONT_F, &SegmentData[SEG_ACTUAL1]);
			break;
		case 0x40:	set_char_S5(FONT_4, FONT_0, FONT_MINUS, FONT_5, FONT_F, &SegmentData[SEG_ACTUAL1]);
			break;
		case 0x60:	set_char_S5(FONT_6, FONT_0, FONT_MINUS, FONT_7, FONT_F, &SegmentData[SEG_ACTUAL1]);
			break;
		}
		set_char_S3(FONT_A, FONT_S, FONT_C|FONT_DP, &SegmentData[SEG_DEFF]);
		SegmentData[SEG_DEFF + 3] = NUM_MAP[EditcharBuffer[MATRIX_LENGTH - EditNum]/0x10];
		SegmentData[SEG_DEFF + 4] = NUM_MAP[EditcharBuffer[MATRIX_LENGTH - EditNum]%0x10];
		if(Flag.Blink){
			SegmentData[SEG_DEFF + 3] = FONT_BLANK;
			SegmentData[SEG_DEFF + 4] = FONT_BLANK;
		}
	}
		if(Flag.Blink)
			MatrixData[EditNum-1] = 0x80;
}
void display_page18(void){	// EDIT_CYCLETIME
u8 dis = EDIT_CYCLETIME;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK,  FONT_C, FONT_T, &SegmentData[SEG_TARGET]);	
	display_edit5(0,&SegmentData[SEG_ACTUAL1]);
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page19(void){	// EDIT_TIMERESET_MODE 
u8 dis = EDIT_TIMERESET_MODE;
	blink();
	display_Clear();
	set_char_S5(FONT_T, FONT_R, FONT_S, FONT_T|FONT_DP, NUM_MAP[Value.Channel], &SegmentData[SEG_TARGET]);
	
	SegmentData[SEG_ACTUAL1 + 1] 	= NUM_MAP[EditTimeBuffer[0]];
	SegmentData[SEG_ACTUAL1 + 2] 	= NUM_MAP[EditTimeBuffer[1]]|FONT_DP;
	SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[EditTimeBuffer[2]];
	SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[EditTimeBuffer[3]];

	if(Flag.Edit){
		if(Flag.Blink && EditNum == 1) SegmentData[SEG_ACTUAL1 + 1] = FONT_UNDER;
		if(Flag.Blink && EditNum == 2) SegmentData[SEG_ACTUAL1 + 2] = FONT_UNDER|FONT_DP;
		if(Flag.Blink && EditNum == 3) SegmentData[SEG_ACTUAL1 + 3] = FONT_UNDER;
		if(Flag.Blink && EditNum == 4) SegmentData[SEG_ACTUAL1 + 4] = FONT_UNDER;
	}
	else{
		if(Flag.Blink) SegmentData[SEG_TARGET + 4] = FONT_BLANK;
	}
}
void display_page20(void){	// EDIT_TIMEMENU_MODE
u8 dis = EDIT_TIMERESET_MODE;
	blink();
	display_Clear();
	set_char_S5(FONT_T|FONT_DP, FONT_C, FONT_T, FONT_R, FONT_L, &SegmentData[SEG_TARGET]);
	switch(EditBuffer[EDIT_LENGTH-1]){
	case MENU_TIME_ON:		set_char_S5(FONT_T,		FONT_MINUS, FONT_0, FONT_N, FONT_BLANK, &SegmentData[SEG_ACTUAL1]); break;
	case MENU_TIME_OFF:		set_char_S5(FONT_T,		FONT_MINUS, FONT_0, FONT_F, FONT_F, 	&SegmentData[SEG_ACTUAL1]); break;
	case MENU_TIME_RESET:	set_char_S5(FONT_T,		FONT_MINUS, FONT_R, FONT_S, FONT_T, 	&SegmentData[SEG_ACTUAL1]); break;
	case MENU_TIME_EN:		set_char_S5(FONT_T,		FONT_MINUS, FONT_E, FONT_N, FONT_BLANK, &SegmentData[SEG_ACTUAL1]); break;
	case MENU_TIME_SUM:		set_char_S5(FONT_BLANK,	FONT_S, 	FONT_U, FONT_M, FONT_T, 	&SegmentData[SEG_ACTUAL1]); break;
	case MENU_TIME_DOWN:	set_char_S5(FONT_D,		FONT_O, 	FONT_W, FONT_N, FONT_T, 	&SegmentData[SEG_ACTUAL1]); break;
	}
	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}

void display_page21(void){	// EDIT_TIMEON_MODE
u8 dis = EDIT_TIMEON_MODE;
	blink();
	display_Clear();
	set_char_S5(FONT_T, FONT_BLANK, FONT_0, FONT_N|FONT_DP, NUM_MAP[Value.Channel], &SegmentData[SEG_TARGET]);
	
	SegmentData[SEG_ACTUAL1 + 1] 	= NUM_MAP[EditTimeBuffer[0]];
	SegmentData[SEG_ACTUAL1 + 2] 	= NUM_MAP[EditTimeBuffer[1]]|FONT_DP;
	SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[EditTimeBuffer[2]];
	SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[EditTimeBuffer[3]];

	if(Flag.Edit){
		if(Flag.Blink && EditNum == 1) SegmentData[SEG_ACTUAL1 + 1] = FONT_UNDER;
		if(Flag.Blink && EditNum == 2) SegmentData[SEG_ACTUAL1 + 2] = FONT_UNDER|FONT_DP;
		if(Flag.Blink && EditNum == 3) SegmentData[SEG_ACTUAL1 + 3] = FONT_UNDER;
		if(Flag.Blink && EditNum == 4) SegmentData[SEG_ACTUAL1 + 4] = FONT_UNDER;
	}
	else{
		if(Flag.Blink) SegmentData[SEG_TARGET + 4] = FONT_BLANK;
	}
}
void display_page22(void){	// EDIT_TIMEOFF_MODE
u8 dis = EDIT_TIMEOFF_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_T, FONT_0, FONT_F, FONT_F|FONT_DP, NUM_MAP[Value.Channel], &SegmentData[SEG_TARGET]);
	
	SegmentData[SEG_ACTUAL1 + 1] 	= NUM_MAP[EditTimeBuffer[0]];
	SegmentData[SEG_ACTUAL1 + 2] 	= NUM_MAP[EditTimeBuffer[1]]|FONT_DP;
	SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[EditTimeBuffer[2]];
	SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[EditTimeBuffer[3]];

	if(Flag.Edit){
		if(Flag.Blink && EditNum == 1) SegmentData[SEG_ACTUAL1 + 1] = FONT_UNDER;
		if(Flag.Blink && EditNum == 2) SegmentData[SEG_ACTUAL1 + 2] = FONT_UNDER|FONT_DP;
		if(Flag.Blink && EditNum == 3) SegmentData[SEG_ACTUAL1 + 3] = FONT_UNDER;
		if(Flag.Blink && EditNum == 4) SegmentData[SEG_ACTUAL1 + 4] = FONT_UNDER;
	}
	else{
		if(Flag.Blink) SegmentData[SEG_TARGET + 4] = FONT_BLANK;
	}
}
void display_page23(void){	// EDIT_TIMEEN_MODE
u8 dis = EDIT_TIMEEN_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_T, FONT_MINUS, FONT_E, FONT_N, &SegmentData[SEG_TARGET]);
	if(EditBuffer[EDIT_LENGTH-1])
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_Y, FONT_E, FONT_S, &SegmentData[SEG_ACTUAL1]);
	else
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_N, FONT_O, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);

	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page24(void){	// EDIT_INPUT_TYPE
u8 dis = EDIT_INPUT_TYPE;
	blink();
	set_char_S5(FONT_I|FONT_DP, FONT_T, FONT_Y, FONT_P, FONT_E, &SegmentData[SEG_TARGET]);	
	switch(EditBuffer[EDIT_LENGTH-1]){
	case 0: set_char_S5(FONT_BLANK, FONT_S, FONT_E, FONT_N, FONT_S, &SegmentData[SEG_ACTUAL1]);			break;
	case 1:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_S, FONT_W, &SegmentData[SEG_ACTUAL1]);	break;
	}
	if(Flag.Edit&&Flag.Blink) set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
}
void display_page25(void){	// EDIT_SETDATE
u8 dis = EDIT_SETDATE;
	display_Clear();
	blink();
	if(!Flag.Edit){
		set_char_S5(FONT_S|FONT_DP, FONT_D, FONT_A, FONT_T, FONT_E, &SegmentData[SEG_TARGET]);

		SegmentData[SEG_ACTUAL1 + 1] = NUM_MAP[RTC.Date/10];
		SegmentData[SEG_ACTUAL1 + 2] = NUM_MAP[RTC.Date%10]|FONT_DP;
		SegmentData[SEG_ACTUAL1 + 3] = NUM_MAP[RTC.Month/10];
		SegmentData[SEG_ACTUAL1 + 4] = NUM_MAP[RTC.Month%10];
		
		SegmentData[SEG_DEFF + 3] = NUM_MAP[RTC.Year/10];
		SegmentData[SEG_DEFF + 4] = NUM_MAP[RTC.Year%10];

		if(Flag.Blink) set_char_S4(FONT_UNDER, FONT_UNDER, FONT_UNDER, FONT_UNDER, &SegmentData[SEG_TARGET + 1]);
	}
	else{
		set_char_S3(FONT_D, FONT_D, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S3(FONT_M, FONT_M, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		set_char_S3(FONT_Y, FONT_Y, FONT_BLANK, &SegmentData[SEG_DEFF]);
		
		SegmentData[SEG_TARGET + 3] 	= NUM_MAP[EditTimeBuffer[0]];
		SegmentData[SEG_TARGET + 4] 	= NUM_MAP[EditTimeBuffer[1]];
		SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[EditTimeBuffer[2]];
		SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[EditTimeBuffer[3]];
		SegmentData[SEG_DEFF + 3] 		= NUM_MAP[EditTimeBuffer[4]];
		SegmentData[SEG_DEFF + 4] 		= NUM_MAP[EditTimeBuffer[5]];
		
		if(Flag.Blink && EditNum == 1) SegmentData[SEG_TARGET + 3] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 2) SegmentData[SEG_TARGET + 4] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 3) SegmentData[SEG_ACTUAL1 + 3] = FONT_UNDER;
		if(Flag.Blink && EditNum == 4) SegmentData[SEG_ACTUAL1 + 4] = FONT_UNDER;
		if(Flag.Blink && EditNum == 5) SegmentData[SEG_DEFF + 3] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 6) SegmentData[SEG_DEFF + 4] 	= FONT_UNDER;
	}
}
void display_page26(void){	//EDIT_SETTIME
u8 dis = EDIT_SETTIME; 
	display_Clear();
	blink();
	if(!Flag.Edit){
		set_char_S5(FONT_S|FONT_DP, FONT_T, FONT_I, FONT_M, FONT_E, &SegmentData[SEG_TARGET]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);

		SegmentData[SEG_ACTUAL1 + 1] = NUM_MAP[RTC.Hours/10];
		SegmentData[SEG_ACTUAL1 + 2] = NUM_MAP[RTC.Hours%10]|FONT_DP;
		SegmentData[SEG_ACTUAL1 + 3] = NUM_MAP[RTC.Minutes/10];
		SegmentData[SEG_ACTUAL1 + 4] = NUM_MAP[RTC.Minutes%10];
		
		SegmentData[SEG_DEFF + 3] = NUM_MAP[RTC.Seconds/10];
		SegmentData[SEG_DEFF + 4] = NUM_MAP[RTC.Seconds%10];

		if(Flag.Blink) set_char_S4(FONT_UNDER, FONT_UNDER, FONT_UNDER, FONT_UNDER, &SegmentData[SEG_TARGET + 1]);
	}
	else{
		set_char_S3(FONT_H, FONT_H, FONT_BLANK, &SegmentData[SEG_TARGET]);
		set_char_S3(FONT_M, FONT_M, FONT_BLANK, &SegmentData[SEG_ACTUAL1]);
		set_char_S3(FONT_S, FONT_S, FONT_BLANK, &SegmentData[SEG_DEFF]);

		SegmentData[SEG_TARGET + 3] 	= NUM_MAP[EditTimeBuffer[0]];
		SegmentData[SEG_TARGET + 4] 	= NUM_MAP[EditTimeBuffer[1]];
		SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[EditTimeBuffer[2]];
		SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[EditTimeBuffer[3]];
		SegmentData[SEG_DEFF + 3] 		= NUM_MAP[EditTimeBuffer[4]];
		SegmentData[SEG_DEFF + 4] 		= NUM_MAP[EditTimeBuffer[5]];
		
		if(Flag.Blink && EditNum == 1) SegmentData[SEG_TARGET + 3] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 2) SegmentData[SEG_TARGET + 4] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 3) SegmentData[SEG_ACTUAL1 + 3] = FONT_UNDER;
		if(Flag.Blink && EditNum == 4) SegmentData[SEG_ACTUAL1 + 4] = FONT_UNDER;
		if(Flag.Blink && EditNum == 5) SegmentData[SEG_DEFF + 3] 	= FONT_UNDER;
		if(Flag.Blink && EditNum == 6) SegmentData[SEG_DEFF + 4] 	= FONT_UNDER;
	}
}
void display_page27(void){	// EDIT_SUMTIME_MODE
u8 dis = EDIT_SUMTIME_MODE;
	display_Clear();
	set_char_S5(FONT_BLANK, FONT_S, FONT_U, FONT_M, FONT_T, &SegmentData[SEG_TARGET]);
	if(!EditBuffer[EDIT_LENGTH-1])
		 set_char_S5(FONT_BLANK, FONT_S, FONT_H, FONT_0, FONT_W, &SegmentData[SEG_ACTUAL1]);
	else set_char_S5(FONT_R, FONT_E, FONT_S, FONT_E, FONT_T, &SegmentData[SEG_ACTUAL1]);
	if(Flag.Edit){
		if(!EditBuffer[EDIT_LENGTH-1]){
			SegmentData[SEG_ACTUAL1 + 0] 	= NUM_MAP[Value.SummaryTimeDay /100 %10];
			SegmentData[SEG_ACTUAL1 + 1] 	= NUM_MAP[Value.SummaryTimeDay /10  %10];
			SegmentData[SEG_ACTUAL1 + 2] 	= NUM_MAP[Value.SummaryTimeDay /1   %10]|FONT_DP;
			
			SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[Value.SummaryTimeHour /10  %10];
			SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[Value.SummaryTimeHour /1   %10];
			
			SegmentData[SEG_DEFF + 1] 	= NUM_MAP[Value.SummaryTimeMinute /10  %10];
			SegmentData[SEG_DEFF + 2] 	= NUM_MAP[Value.SummaryTimeMinute /1   %10]|FONT_DP;
			SegmentData[SEG_DEFF + 3] 	= NUM_MAP[Value.SummaryTimeSecond /10  %10];
			SegmentData[SEG_DEFF + 4] 	= NUM_MAP[Value.SummaryTimeSecond /1   %10];
		}
		else{
			set_char_S5(FONT_BLANK, FONT_BLANK, FONT_Y, FONT_E, FONT_S, &SegmentData[SEG_DEFF]);
		}
	}
}
void display_page28(void){	// EDIT_DOWNTIME_MODE
u8 dis = EDIT_DOWNTIME_MODE;
	display_Clear();
	set_char_S5(FONT_D, FONT_0, FONT_W, FONT_N, FONT_T, &SegmentData[SEG_TARGET]);
	if(!EditBuffer[EDIT_LENGTH-1])
		 set_char_S5(FONT_BLANK, FONT_S, FONT_H, FONT_0, FONT_W, &SegmentData[SEG_ACTUAL1]);
	else set_char_S5(FONT_R, FONT_E, FONT_S, FONT_E, FONT_T, &SegmentData[SEG_ACTUAL1]);
	if(Flag.Edit){
		if(!EditBuffer[EDIT_LENGTH-1]){
			SegmentData[SEG_ACTUAL1 + 0] 	= NUM_MAP[Value.DownTimeDay /100 %10];
			SegmentData[SEG_ACTUAL1 + 1] 	= NUM_MAP[Value.DownTimeDay /10  %10];
			SegmentData[SEG_ACTUAL1 + 2] 	= NUM_MAP[Value.DownTimeDay /1   %10]|FONT_DP;
			
			SegmentData[SEG_ACTUAL1 + 3] 	= NUM_MAP[Value.DownTimeHour /10  %10];
			SegmentData[SEG_ACTUAL1 + 4] 	= NUM_MAP[Value.DownTimeHour /1   %10];
			
			SegmentData[SEG_DEFF + 1] 	= NUM_MAP[Value.DownTimeMinute /10  %10];
			SegmentData[SEG_DEFF + 2] 	= NUM_MAP[Value.DownTimeMinute /1   %10]|FONT_DP;
			SegmentData[SEG_DEFF + 3] 	= NUM_MAP[Value.DownTimeSecond /10  %10];
			SegmentData[SEG_DEFF + 4] 	= NUM_MAP[Value.DownTimeSecond /1   %10];
		}
		else{
			set_char_S5(FONT_BLANK, FONT_BLANK, FONT_Y, FONT_E, FONT_S, &SegmentData[SEG_DEFF]);
		}
	}
}
void display_page29(void){	// EDIT_ALS_MODE
u8 dis = EDIT_ALS_MODE;
	display_Clear();
	blink();
	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_S, FONT_P, FONT_BLANK, &SegmentData[SEG_TARGET]);
	switch(Value.Channel){
		case 0:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_S, FONT_P, FONT_1, &SegmentData[SEG_ACTUAL1]);	break;
		case 1:	set_char_S5(FONT_BLANK, FONT_BLANK, FONT_S, FONT_P, FONT_2, &SegmentData[SEG_ACTUAL1]);	break;
		}
	display_edit5( Value.DecimalPoint,&SegmentData[SEG_DEFF]);
	if(Flag.Edit&&Flag.Blink)set_char_S5(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_DEFF]);
	
}
