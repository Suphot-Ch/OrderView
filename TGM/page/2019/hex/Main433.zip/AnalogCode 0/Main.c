#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"

_FOSC(CSW_FSCM_OFF & XT_PLL8);
_FWDT(WDT_OFF);
_FBORPOR(PBOR_ON & BORV_27 & PWRT_OFF & MCLR_DIS);

/*
Fcy=Fosc/4=(Xtal*PLL)/(POST*4)
Fcy=(7.3728MHz*8)/(4)
Fcy=14.7456MHz
Tcy=6.7816840277777777777777777777778e-8
*/

void io_init(void){
	ADPCFG=0xFFFF; // ADC Port
	TRISB=0xF00F;
	TRISC=0xFFFF;
	TRISD=0xFFF0;
	TRISE=0xFF00;
	TRISF=0xFFD2;

#ifdef ADCEN
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();

	/// CH0 ///
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	ADC_CS=0;
	delayxNop();
	delayxNop();
	ADC_CS=1;
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
	delayxNop();
#endif	
}
void int0_init(void){
	_INT0EP=FALLING;
	_INT0IE=EN;
	_INT0IP=PRIORITY_7;
}
void timer1_init(void){
	TMR1=CLR;
	PR1=TMR1_PERIOD;
	_T1IP=PRIORITY_3;
	T1CON=0x0030;
	_T1IE=EN;
	_T1ON=EN;
}
void timer2_init(void){
	TMR2=CLR;
	PR2=TMR2_PERIOD;
	T2CON=0x0030;
	_T2IP=PRIORITY_2;
	_T2IE=EN;
	//_T2ON=SET;
}
void timer3_init(void){
	TMR3=CLR;
	PR3=TMR3_PERIOD;
	T3CON=0x0030;
	_T3IP=PRIORITY_1;
	_T3IE=EN;
	_T3ON=EN;
}
void timer4_init(void){
	TMR4=CLR;
	PR4=TMR4_PERIOD;
	T4CON=0x0030;
	_T4IP=PRIORITY_5;
	_T4IE=EN;
	_T4ON=EN;
}
void config_uart2(void){
	switch(Value.Baudrate){
		case BR1200:
			U2BRG=767;
			break;
		case BR2400:
			U2BRG=383;
			break;
		case BR4800:
			U2BRG=191;
			break;
		case BR19200:
			U2BRG=47;
			break;
		case BR38400:
			U2BRG=23;
			break;
		case BR57600:
			U2BRG=15;
			break;
		case BR115200:
			U2BRG=7;
			break;
		default:
			U2BRG=95;
			break;
	}
	switch(Value.Parity){
		case b8o1:
			cbi(U2MODE, BIT1);
			sbi(U2MODE, BIT2);
			break;
		case b8e1:
			sbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
		default:
			cbi(U2MODE, BIT1);
			cbi(U2MODE, BIT2);
			break;
	}
}
void uart2_init(void){
	U2MODE=0x8000;
	U2STA=0x8400;
	config_uart2();
	_U2RXIP=PRIORITY_6;
	_U2TXIP=PRIORITY_4;
	_U2RXIE=EN;
	_U2TXIE=EN;
	rx_en();
}
void ram_init(void){
	u8 i, ctrl,ks;
	u16 val[12], Started;
	Started = read_eeprom(EEP_DEFINE_START);
	write_eeprom(EEP_DEFINE_START, (Started==0xFFFF)? 0 : Started);
//***********************************************************************************************************************************//
//												   ADC INPUT
//***********************************************************************************************************************************//

	for(i=0;i<ADC_CHANNEL;i++){
		if(!Started){
			Value.SystemZeroScale[i].LWord = 0x28B0;
			Value.SystemFullScale[i].LWord = 0xCBA0;
			write_eeprom(EEP_AN_ZERO_HW0+(i*2), Value.SystemZeroScale[i].WordHi);
			write_eeprom(EEP_AN_ZERO_LW0+(i*2), Value.SystemZeroScale[i].WordLo);
			write_eeprom(EEP_AN_FULL_HW0+(i*2), Value.SystemFullScale[i].WordHi);
			write_eeprom(EEP_AN_FULL_LW0+(i*2), Value.SystemFullScale[i].WordLo);
		}
	Value.SystemZeroScale[i].WordHi=read_eeprom(EEP_AN_ZERO_HW0+(i*2));
	Value.SystemZeroScale[i].WordLo=read_eeprom(EEP_AN_ZERO_LW0+(i*2));
	
	Value.SystemFullScale[i].WordHi=read_eeprom(EEP_AN_FULL_HW0+(i*2));
	Value.SystemFullScale[i].WordLo=read_eeprom(EEP_AN_FULL_LW0+(i*2));
	
	Value.ScaleHiLimit[i].WordHi=read_eeprom(EEP_SCALE_HI_HW0+(i*2));
	Value.ScaleHiLimit[i].WordLo=read_eeprom(EEP_SCALE_HI_LW0+(i*2));
	
	Value.ScaleLoLimit[i].WordHi=read_eeprom(EEP_SCALE_LO_HW0+(i*2));
	Value.ScaleLoLimit[i].WordLo=read_eeprom(EEP_SCALE_LO_LW0+(i*2));
	
	Value.PVS[i].WordHi=read_eeprom(EEP_PUS0H+(i*2));
	Value.PVS[i].WordLo=read_eeprom(EEP_PUS0l+(i*2));
	
	Value.DecimalPoint[i]=read_eeprom(EEP_DP1+(i*2));
	
	if(!Started){
		Value.SystemZeroScale[i].LWord = 0x028B;
		write_eeprom(EEP_AN_ZERO_HW0+(i*2), Value.SystemZeroScale[i].WordHi);
		write_eeprom(EEP_AN_ZERO_LW0+(i*2), Value.SystemZeroScale[i].WordLo);
		Value.SystemFullScale[i].LWord = 0x0CBA;
		write_eeprom(EEP_AN_FULL_HW0+(i*2), Value.SystemFullScale[i].WordHi);
		write_eeprom(EEP_AN_FULL_HW0+(i*2), Value.SystemFullScale[i].WordLo);
	}

	if(!Started || Value.ScaleLoLimit[i].LWord>9999||Value.ScaleLoLimit[i].LWord<-1999){
		Value.ScaleLoLimit[i].LWord = 400 ;
		write_eeprom(EEP_SCALE_LO_HW0+(i*2), Value.ScaleLoLimit[i].WordHi);
		write_eeprom(EEP_SCALE_LO_LW0+(i*2), Value.ScaleLoLimit[i].WordLo);
		}
	if(!Started || Value.ScaleHiLimit[i].LWord>9999||Value.ScaleHiLimit[i].LWord<-1999 || Value.ScaleHiLimit[i].LWord < Value.ScaleLoLimit[i].LWord){
		Value.ScaleHiLimit[i].LWord = 2000 ;
		write_eeprom(EEP_SCALE_HI_HW0+(i*2), Value.ScaleHiLimit[i].WordHi);
		write_eeprom(EEP_SCALE_HI_LW0+(i*2), Value.ScaleHiLimit[i].WordLo);
		}
	if(!Started || Value.PVS[i].LWord>9999||Value.PVS[i].LWord<-1999){
		Value.PVS[i].LWord=0; 
		write_eeprom(EEP_PUS0H+(i*2), Value.PVS[i].WordHi);
		write_eeprom(EEP_PUS0l+(i*2), Value.PVS[i].WordLo);
		}
	if(!Started || Value.DecimalPoint[i]>4||Value.DecimalPoint[i]<0){
		Value.DecimalPoint[i]=2; 
		write_eeprom(EEP_DP1+(i*2), Value.DecimalPoint[i]);
		}
	}

//***********************************************************************************************************************************//

//***********************************************************************************************************************************//
//                                                 Alarm
//***********************************************************************************************************************************//

	for(i=0;i<ALARM_CHANNEL;i++){
	Value.ALH[i].WordHi	=read_eeprom(EEP_ALH0H+(i*2));
	Value.ALH[i].WordLo	=read_eeprom(EEP_ALH0L+(i*2));
	Value.ALL[i].WordHi	=read_eeprom(EEP_ALL0H+(i*2));
	Value.ALL[i].WordLo	=read_eeprom(EEP_ALL0L+(i*2));
	Value.ALC[i].WordHi	=read_eeprom(EEP_ALC0H+(i*2));
	Value.ALC[i].WordLo	=read_eeprom(EEP_ALC0L+(i*2));
	Value.Mode[i]	=read_eeprom(EEP_MODE1+(i*2));
	
	if(!Started || Value.ALH[i].LWord>9999||Value.ALH[i].LWord<-1999){
		Value.ALH[i].LWord=1600; 
		write_eeprom(EEP_ALH0H+(i*2), Value.ALH[i].WordHi);
		write_eeprom(EEP_ALH0L+(i*2), Value.ALH[i].WordLo);
		}
	if(!Started || Value.ALL[i].LWord>9999||Value.ALL[i].LWord<-1999){
		Value.ALL[i].LWord=800; 
		write_eeprom(EEP_ALL0H+(i*2), Value.ALL[i].WordHi);
		write_eeprom(EEP_ALL0L+(i*2), Value.ALL[i].WordLo);
		}
	if(!Started || Value.ALC[i].LWord>9999||Value.ALC[i].LWord<-1999){
		Value.ALC[i].LWord=0; 
		write_eeprom(EEP_ALC0H+(i*2), Value.ALC[i].WordHi);
		write_eeprom(EEP_ALC0L+(i*2), Value.ALC[i].WordLo);
		}
	if(!Started || Value.Mode[i]>=5||Value.Mode[i]<0) 
		write_eeprom(EEP_MODE1+(i*2), Value.Mode[i] = 1);
	}

//***********************************************************************************************************************************//


	Value.CycleTime=read_eeprom(EEP_CYCLE);
	Value.SlaveAddress=read_eeprom(EEP_SLAVE_ADDRESS);
	Value.Baudrate=read_eeprom(EEP_BAUDRATE);
	Value.Parity=read_eeprom(EEP_PARITY);
	Value.DelayBetweenPolls=read_eeprom(EEP_DELAY_POLLS);
	Value.ResponseTimeOut=read_eeprom(EEP_RESP_TIME_OUT);

	if(!Started || Value.SlaveAddress>255||Value.SlaveAddress<0){
		Value.SlaveAddress=1;
		write_eeprom(EEP_SLAVE_ADDRESS, Value.SlaveAddress);
	}
	if(!Started || Value.Baudrate>BR57600||Value.Baudrate<BR4800){
		Value.Baudrate=BR9600;
		write_eeprom(EEP_BAUDRATE, Value.Baudrate);
	}
	if(!Started || Value.Parity>b8e1||Value.Parity<b8n1){
		Value.Parity=b8n1;
		write_eeprom(EEP_PARITY, Value.Parity);
	}
	if(!Started || Value.DelayBetweenPolls>1000||Value.DelayBetweenPolls<5){
		Value.DelayBetweenPolls=50;
		write_eeprom(EEP_DELAY_POLLS, Value.DelayBetweenPolls);
	}
	if(!Started || Value.ResponseTimeOut>1000||Value.ResponseTimeOut<5){
		Value.ResponseTimeOut=50;
		write_eeprom(EEP_RESP_TIME_OUT, Value.ResponseTimeOut);
	}
	
	ADC.channel=0;
	Value.ResponseTimeOut=20;
	Value.DelayBetweenPolls=20;
	//Value.Baudrate=BR9600;
	//Value.Parity=b8n1;
	Value.Channel=0;
		
	Modbus.Poll = 0;
	Modbus.Response = 0;
	Modbus.Status = RSP_PV;
	Flag.Word = CLR;
	Status.Main = INIT;
	write_eeprom(EEP_DEFINE_START,Started+1); 

	SumtimeOver = 0;
}
s16 main(void){
	u16 i;
	
	io_init();
	ram_init();
	rtc_init();
	timer1_init();
	timer2_init();
	timer3_init();
	timer4_init();
	uart2_init();
	int0_init();
	TPIC6B595_init();

	while(1){
	};
	return 0;
}

