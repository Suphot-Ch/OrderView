#include <p30f4011.h>
#include "config.h"
#include "global.h"

#if 1
void delayxNop(void){
	Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
	//Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();Nop();
}
void start_bit(void){
	SDAIO=OUTPUT;
	SDA=SET;
	SCL=SET;
	delayxNop();
	delayxNop();
	SDA=CLR;
	delayxNop();
	SCL=CLR;
}
void stop_bit(void){
	SDAIO=OUTPUT;
	SCL=SET;
	delayxNop();
	SDA=CLR;
	delayxNop();
	SDA=SET;
	delayxNop();
}
void ack(void){
	SDAIO=OUTPUT;
	SDA=CLR;
	//SDAIO=INPUT;
	delayxNop();
	SCL=SET;
	delayxNop();
	SCL=CLR;
	delayxNop();
	SDA=SET;
}
void nack(void){
	SDAIO=OUTPUT;
	SCL=CLR;
	SDA=SET;
	delayxNop();
	SCL=SET;
	delayxNop();
	SCL=CLR;
	delayxNop();
}
void send_byte(u8 value){
	u8 i;
	SDAIO=OUTPUT;
	for(i=0;i<8;i++){
		SCL=CLR;
		SDA=value&0x80 ? 1 : 0;
		delayxNop();
		SCL=SET;
		delayxNop();
		value<<=1;
	}
	SCL=CLR;
	delayxNop();
	SDA=CLR;
}
u8 read_byte(void){
	u8 i, value;
	value=CLR;
	SDAIO=INPUT;
	SCL=CLR;
	for(i=0;i<8;i++){
		delayxNop();
		SCL=SET;
		value<<=1;
		value|=SDA ? 1 : 0;
		delayxNop();
		SCL=CLR;
	}
	SCL=CLR;
	delayxNop();
	return value;
}

void write_ram_RTC(u8 addr, u8 *dptr, u8 n){
	u8 i;
	
	for(i=0;i<n;i++,dptr++){
		start_bit();		
		send_byte(DS1307_W);
		ack();
		send_byte(addr+i);
		ack();		
		send_byte(*dptr);
		ack();
		stop_bit();
		//*dptr=0;
	}
}
void read_ram_RTC(u8 addr, u8 *dptr, u8 n){
	u8 i;
	
	for(i=0;i<n;i++,dptr++){
		start_bit();		
		send_byte(DS1307_W);
		ack();
		send_byte(addr+i);
		ack();
		start_bit();		
		send_byte(DS1307_R);
		ack();
		*dptr=read_byte();
		nack();	
		stop_bit();
	}
}
#endif

