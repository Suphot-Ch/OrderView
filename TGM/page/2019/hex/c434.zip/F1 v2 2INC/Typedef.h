#ifndef TYPEDEF

typedef float f32;	
typedef unsigned long u32;	
typedef long s32;
typedef unsigned int u16;	
typedef int s16; 
typedef unsigned char u8;  
typedef char s8; 
typedef struct{
	u8 Main;
	u8 CalAn;
	u8 Display;
}Status_sType;
typedef union{
	s32 LWord;
	struct{
		s16 WordLo;
		s16 WordHi;		
	};
}Word32_sType;
typedef union{
	u16 Word;
	struct{
		u8 L;
		u8 H;
	};
}Word16_uType;
typedef union{
	volatile s8 Bytes;
	struct{
		volatile u8 L:4;
		volatile u8 H:4;
	};
}Byte_sType;
typedef struct{
	u16 Buffer[16];
	u16 DecodeLast;
	u16 Decode;
	u8 Status;
	u8 TimeOut;
	u8 ByteCount;
}IR_sType;
typedef struct{
	s16 Channel;
	
	u32	SetPointMode2;
	u32	SetPointMode1;
	u32 CycleTimeMasterPlan;
	
	s16	DivB1;
	s16	DivA2;
	s16	DivA1;
	s16	MulAB1;
	
/***********************************************************************/
/***************************** Communication ***************************/
	s16 SlaveAddress;		// 	87				1		- 255
	s16 Parity;				// 	86				0		- 2
	s16 Baudrate;			// 	85				0		- 4
/***********************************************************************/
/***************************** Time ************************************/
	Word16_uType Time_Reset[TIMER_CHANNEL];
							//  84	363		
							//  83	363		
							//  82	363		
							//  81	363		
							//  80	362		How to Read Time
							//  79	361		1.	if read value = 0x1800
							//  78	350			Byte High 	= 0x18 = 24
							//  77	359			Byte Low	= 0x00 =  0
							//  76	358			So 0x1800 	= 24.00
							//  75	357		
			
	Word16_uType Time_OFF[TIMER_CHANNEL];
							//  74	356		2.	if read value = 0x081E
							//  73	355			Byte High	= 0x08 =  8
							//  72	354			Byte Low	= 0x1E = 30
							//  71	353			So 0x081E	= 08.30
							//  70	352		
							//  69	351		How to set Time 
							//  68	350		1.	if want to set time to 12.45
							//  67	349			Convert Hour to Hex		= 0x0C
							//  66	348			Convert Minute to Hex	= 0x2D
							//  65	347			So write value 			= 0x0C2D

	Word16_uType Time_ON[TIMER_CHANNEL];
							//  64	346		
							//  63	345		2.	if want to set time to 15.10
							//  62	344			Convert Hour to Hex		= 0x0F
							//  61	343			Convert Minute to Hex	= 0x0A
							//  60	342			So write value 			= 0x0F0A
							//  59	341		
							//  58	340		
							//  57	339		
							//  56	338		
							//  55	337		

	u16 Time_EN;			//  54	336		0 OFF	- 1 ON

	u16 SummaryTimeSecond;	//  53	335		0		- 59
	u16 SummaryTimeMinute;	//  52	334		0		- 59
	u16 SummaryTimeHour;	//  51	333		0		- 23
	u16 SummaryTimeDay;		//  50	332		0		- 999

	u16 DownTimeSecond;		//  49	331		0		- 59
	u16 DownTimeMinute;		//  48	330		0		- 59
	u16 DownTimeHour;		//  47	329		0		- 23
	u16 DownTimeDay;		//  46	328		0		- 999
	u16 DownTimeStatus;		//  45	327		0 OFF	- 1 ON

	u16 Second;				//  44	326		0		- 59
	u16 Minute;				//  43	325		0		- 59
	u16 Hour;				//  42	324		0		- 23
	u16 Year;				//  41	323		0		- 99
	u16 Month;				//  40	322		1		- 12
	u16 Date;				//  39	321		1		- 31
	u16 DayOfWeek;			//  38	320		0		- 6
/***********************************************************************/
/***************************** Message *********************************/
	u16 Chart[8];
	// u16 Char_8;				// 	37	519		
	// u16 Char_7;				// 	36	518		
	// u16 Char_6;				// 	35	517		
	// u16 Char_5;				// 	34	516		32		- 124
	// u16 Char_4;				//  33	515		Space	- ~
	// u16 Char_3;				// 	32	514		
	// u16 Char_2;				// 	31	513		
	// u16 Char_1;				// 	30	512
/***********************************************************************/
/*****************************           *******************************/
	u16	InputDelay;			// 	29				0		- 999
	u16 CycleTimeTarget;	// 	28				0		- 999
	s16	DecimalPoint;		// 	27				0		- 4
/***********************************************************************/
/***************************** Set Point *******************************/
	s32	SetPoint2;			// 	25	1088
	s32	SetPoint1;			// 	23	1090
/***********************************************************************/
/***************************** Display Value ***************************/
	s16	Divisor1;			// 	22	388		0		- 1
	s16	Multiplier1;		// 	21	387		0		- FFFF
	s16	DO_Status;			// 	20	386		0		- FFFF
	s16	DI_Status;			// 	19	385		0		- 999
	s16	InputType;			// 	18	384		0		- 999
/***********************************************************************/
/***************************** Input Output ****************************/
	s32	PerEff;				// 	16	1032		0		- 99999
	s32	MasterPlan;			// 	14	1030		0		- 99999
	s32	Deff;				// 	12	1028		0		- 99999
	s32	Actual1;			// 	10	1026		-19999	- 99999
	s32	Target;				// 	08	1024		0		- 999
/***********************************************************************/
/***************************** Information *****************************/
	s16	SwMinorYear;		// 	07	7		0
	s16	SwMajorYear;		// 	06	6		1
	s16	SwReleaseYear;		// 	05	5		2015
	s16	HwMinorVersion;		// 	04	4		5
	s16	HwMajorVersion;		// 	03	3		1
	s16	HwReleaseYear;		// 	02	2		2015
	s16	Function;			//	01	1		1-6
	Word16_uType	Model;	// 	00	0		0-3
/***********************************************************************/
	s16 Data16Last;
	u32 Time32;

	u8 BreakStatus;
	u8 WarningStatus;
	u16 SummaryTimeMiliSecond;	//  
	u16 DownTimeMiliSecond;		//  

	s16 ResponseTimeOut;
	s16 DelayBetweenPolls;
	s16 Protocol;
	
	s8 Bits;
	u8 CoilOutput;
	
	Word32_sType DatamLast;
	u8 CalAnTimeOut;
	u16 Time1Sec;

}Value_sType;
typedef struct{
	u32 Data[8];
	u32 Filter;
	u16 Sample;
	u32 Buffer[16];
	u8 TimeOunt;
	u8 ch[2];
	u8 ch_num;
}ADC_sType;
typedef struct {
	u8 Status;
	u16 NotResponse; 
	u16 Poll; 
	u16 Response; 
	u16 ByteReq; 
	u16 ByteRsp; 
	u16 DelayBetweenPolls; 
	u16 ResponseTimeOut; 
	u8 RxTimeOut; 
	u8 TxTimeOut; 
	u8 CrcHi; 
	u8 CrcLo;
	u8 TXTimeOut;
	u8 RXTimeOut;
	u8 ReqBuf[127];
	u8 RspBuf[127];
	u8 Ascii2HexBuf[64];
}MB_sType;
typedef struct{
	u8 Status;
	u16 HoldTime;
	u32 Actual1Div;
}Trig_sType;
typedef struct{
	u8 Minutes;
	u8 Hours;
	u8 Event;
}Program_sType;
typedef struct{
	u8 Seconds;
	u8 Minutes;
	u8 Hours;
	u8 Date;
	u8 Month;
	u8 Year;
	u8 Day;
	u8 Status;
	u8 Interrupt;
}RTC_sType;
typedef union{
	volatile u32 Word;
	struct{
		volatile u8 IrStart : 1;
		volatile u8 IrDecode : 1;
		volatile u8 TimeSetting : 1;
		volatile u8 FTX:1;

		volatile u8 FRX : 1;
		volatile u8 DATA_NOT_SUPPORT:1;
		volatile u8 NoDevice : 1;
		volatile u8 Sign : 1;

		volatile u8 Blink : 1;
		volatile u8 Power : 1;
		volatile u8 CoilsOn;
		volatile u8 BlinkEn : 1;

		volatile u8 BreakTime : 1;
		volatile u8 Edit : 1;
		volatile u8 PVLoLimit : 1;
		volatile u8 PVHiLimit : 1;

		volatile u8 CalAnalog : 1;
		volatile u8 CalPoint : 1;
		volatile u8 MB_BUSY : 1;
		volatile u8 Timer_En : 1;
		
		volatile u8 Logo : 4;
		
	};
}Flag_uType;
#endif
/*
*/
