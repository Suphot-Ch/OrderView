
#ifndef FUNCTION

#include "config.h"
#include "typedef.h"

#endif

