#include <p30f4011.h>
#include <uart.h>
#include "config.h"
#include "global.h"
#include "segment.h"

const unsigned long Devide[]={1000,100,10,1};
const unsigned long Devide1[]={100000,10000,1000,100,10,1};
const u8 _MAP[]={FONT_1, FONT_2, FONT_3, FONT_4, FONT_5};
const u8 NUM_MAP[]={
	/*b a f g e d c dp*/
	FONT_0,
	FONT_1,
	FONT_2,
	FONT_3,
	FONT_4,
	FONT_5,
	FONT_6,
	FONT_7,
	FONT_8,
	FONT_9,
	FONT_A,
	FONT_B,
	FONT_C,
	FONT_D,
	FONT_E,
	FONT_F,
	FONT_MINUS
};
const u8 NUM_MAP_[]={
	/*b a f g e d c dp*/
	FONT_0_,
	FONT_1_,
	FONT_2_,
	FONT_3_,
	FONT_4_,
	FONT_5_,
	FONT_6_,
	FONT_7_,
	FONT_8_,
	FONT_9_,
	FONT_A_,
	FONT_B_,
	FONT_C_,
	FONT_D_,
	FONT_E_,
	FONT_F_,
	FONT_MINUS_
};
const u8 ASCII_CHR[]={
	'0',
	'1',
	'2',
	'3',
	'4',
	'5',
	'6',
	'7',
	'8',
	'9',
	'A',
	'B',
	'C',
	'D',
	'E',
	'F'		
};

void display_page0(void);
void display_page1(void);
void display_page2(void);
void display_page3(void);
void display_page4(void);
void display_page5(void);
void display_page6(void);
void display_page7(void);
void display_page8(void);
void display_page9(void);
void display_page10(void);
void display_page11(void);
void display_page12(void);
void display_page13(void);
void display_page14(void);
void display_page15(void);
void display_page16(void);
void display_page17(void);
void display_page18(void);
void display_page19(void);
void display_page20(void);
void display_page21(void);
void display_page22(void);
void display_page23(void);
void display_page24(void);
void display_page25(void);
void display_page26(void);
void display_page27(void);
void display_page28(void);
void display_page29(void);
void display_page30(void);


void (*update_segment_page[])(void)={
	display_page0,
	display_page1,
	display_page2,
	display_page3,
	display_page4,
	display_page5,
	display_page6,
	display_page7,
	display_page8,
	display_page9,
	display_page10,
	display_page11,
	display_page12,
	display_page13,
	display_page14,
	display_page15,
	display_page16,
	display_page17,
	display_page18,
	display_page19,
	display_page20,
	display_page21,
	display_page22,
	display_page23,
	display_page24,
	display_page25,
	display_page26,
	display_page27,
	display_page28,
	display_page29,
	display_page30,
};

void blink(void){
	if(Flag.BlinkEn){
		if(++TimeBlink>=TBLINK){
			TimeBlink=CLR;
			Flag.Blink=Flag.Blink ? 0 : 1;
		}
	}
}
void set_blank(void){
	u8 i;

	for(i=0;i<SEGMENT_LENGTH;i++) SegmentData[i]=FONT_BLANK;
}

void set_num_lo_r1(s16 value, u8 *segment){
	*segment=NUM_MAP[(value)];
				
}

void set_num_lo_r4(s16 value, u8 *segment){
	
	*segment++=!(value/Devide[0]) ? FONT_BLANK : NUM_MAP[(value/Devide[0])%10];
	*segment++=!(value/Devide[1]) ? FONT_BLANK : NUM_MAP[(value/Devide[1])%10];
	*segment++=!(value/Devide[2]) ? FONT_BLANK : NUM_MAP[(value/Devide[2])%10];
	*segment++=!(value/Devide[3]) ? FONT_BLANK : NUM_MAP[(value/Devide[3])%10];
	//*segment=NUM_MAP[(value/Devide[4])%10];
}
void set_num_lo_r6(s16 value, u8 *segment){
	
	*segment++=!(value/Devide1[0]) ? FONT_BLANK : NUM_MAP[(value/Devide1[0])%10];
	*segment++=!(value/Devide1[1]) ? FONT_BLANK : NUM_MAP[(value/Devide1[1])%10];
	*segment++=!(value/Devide1[2]) ? FONT_BLANK : NUM_MAP[(value/Devide1[2])%10];
	*segment++=!(value/Devide1[3]) ? FONT_BLANK : NUM_MAP[(value/Devide1[3])%10];
	*segment++=!(value/Devide1[4]) ? FONT_BLANK : NUM_MAP[(value/Devide1[4])%10];
	*segment=NUM_MAP[(value/Devide[5])%10];
}
void set_char(s8 a, s8 b, s8 c, s8 d, s8 e, u8 *segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;
	*segment=e;
}

void set_char1(s8 a, u8 *segment){
	*segment=a;
}
void set_char2(s8 a, s8 b, u8 *segment){
	*segment++=a;
	*segment=b;
}
void set_char3(s8 a, s8 b, s8 c, u8 *segment){
	*segment++=a;
	*segment++=b;
	*segment=c;
}
void set_char4(s8 a, s8 b, s8 c, s8 d, u8 *segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment=d;
}

void set_char5(s8 a, s8 b, s8 c, s8 d, s8 e, u8 *segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;
	*segment=e;
}

void set_char6(s8 a, s8 b, s8 c, s8 d, s8 e, s8 f, u8 *segment){
	*segment++=a;
	*segment++=b;
	*segment++=c;
	*segment++=d;
	*segment++=e;
	*segment=f;
}

void set_hex(s32 lword){	
	SegmentData[0]=NUM_MAP[lword/0x100000%0x10];
	SegmentData[1]=NUM_MAP[lword/0x10000%0x10];
	SegmentData[2]=NUM_MAP[lword/0x1000%0x10];
	SegmentData[3]=NUM_MAP[lword/0x100%0x10];
	SegmentData[4]=NUM_MAP[lword/0x10%0x10];
	SegmentData[5]=NUM_MAP[lword%0x10];
}
void set_hex2(s32 lword, u8 *Segment){	
	*Segment++=NUM_MAP[lword/0x1000%0x10];
	*Segment++=NUM_MAP[lword/0x100%0x10];
	*Segment++=NUM_MAP[lword/0x10%0x10];
	// *Segment=NUM_MAP[lword%0x10];
}
void set_hex3(s32 lword){	
	SegmentData[10]=NUM_MAP[lword/0x10000%0x10];
	SegmentData[11]=NUM_MAP[lword/0x1000%0x10];
	SegmentData[12]=NUM_MAP[lword/0x100%0x10];
	SegmentData[13]=NUM_MAP[lword/10%0x10];
	SegmentData[14]=NUM_MAP[lword%0x10];
}
void set_num_hi(long value, u8 *segment){
	*segment++=!(value/Devide[0]) ? FONT_BLANK : NUM_MAP[(value/Devide[0])%10];
	*segment++=!(value/Devide[1]) ? FONT_BLANK : NUM_MAP[(value/Devide[1])%10];
	*segment++=!(value/Devide[2]) ? FONT_BLANK : NUM_MAP_[(value/Devide[2])%10];
	*segment=NUM_MAP[(value/Devide[3])%10];
}
void set_num_lo(long value, u8 *segment){
	*segment++=!(value/Devide[0]) ? FONT_BLANK : NUM_MAP[(value/Devide[0])%10];
	*segment++=!(value/Devide[1]) ? FONT_BLANK : NUM_MAP[(value/Devide[1])%10];
	*segment++=!(value/Devide[2]) ? FONT_BLANK : NUM_MAP[(value/Devide[2])%10];
	*segment=NUM_MAP[(value/Devide[3])%10];
}
void set_edit_num_hi(u8 *segment){
	*segment++=(!Flag.Blink ? (!EditBuffer[0] ? FONT_BLANK : NUM_MAP[EditBuffer[0]]) : FONT_BLANK);
	*segment++=(!Flag.Blink ? (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]) : FONT_BLANK);
	*segment++=(!Flag.Blink ? (!EditBuffer[0]&&!EditBuffer[1]&&!EditBuffer[2] ? FONT_BLANK : NUM_MAP_[EditBuffer[2]]) : FONT_BLANK);
	*segment=(!Flag.Blink ? NUM_MAP[EditBuffer[3]] : FONT_BLANK);
}
void set_edit_num_lo(u8 *segment){
	*segment++=(!Flag.Blink ? (!EditBuffer[0] ? FONT_BLANK : NUM_MAP[EditBuffer[0]]) : FONT_BLANK);
	*segment++=(!Flag.Blink ? (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]) : FONT_BLANK);
	*segment++=(!Flag.Blink ? (!EditBuffer[0]&&!EditBuffer[1]&&!EditBuffer[2] ? FONT_BLANK : NUM_MAP[EditBuffer[2]]) : FONT_BLANK);
	*segment=(!Flag.Blink ? NUM_MAP[EditBuffer[3]] : FONT_BLANK);
}
void set_edit_time(u8 *segment){
	*segment++=EditNum==1 ? (!Flag.Blink ? NUM_MAP[EditBuffer[0]] : FONT_BLANK) : NUM_MAP[EditBuffer[0]];
	*segment++=EditNum==2 ? (!Flag.Blink ? NUM_MAP[EditBuffer[1]] : FONT_BLANK)|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP;
	*segment++=EditNum==3 ? (!Flag.Blink ? NUM_MAP_[EditBuffer[2]] : FONT_BLANK)|FONT_DP_ : NUM_MAP_[EditBuffer[2]]|FONT_DP_;
	*segment=EditNum==4 ? (!Flag.Blink ? NUM_MAP[EditBuffer[3]] : FONT_BLANK) : NUM_MAP[EditBuffer[3]];
}
void set_hour_min(u8 hour, u8 min){
	SegmentData[0]=NUM_MAP[hour/10];
	SegmentData[1]=NUM_MAP[hour%10]|FONT_DP;
	SegmentData[2]=NUM_MAP_[min/10]|FONT_DP_;
	SegmentData[3]=NUM_MAP[min%10];
}

void display_edit_2(u8 *segmentData){
		if(!Flag.Sign){
			*segmentData++=(Value.DecimalPoint[Value.Channel]==1) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Value.DecimalPoint[Value.Channel]>1) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[1] ? FONT_BLANK: NUM_MAP[EditBuffer[1]]));
			*segmentData=NUM_MAP[EditBuffer[2]];
			}
		else{
			*segmentData++=(Value.DecimalPoint[Value.Channel]==1) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Value.DecimalPoint[Value.Channel]>1) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[1] ? FONT_MINUS : NUM_MAP[EditBuffer[1]]));
			*segmentData=NUM_MAP[EditBuffer[2]];
			}
}
void display_edit_3(u8 Dp ,u8 *segmentData){
		if(!Flag.Sign)
			*segmentData++	=(Dp==2) ? (!EditBuffer[0] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[0]]|FONT_DP) : ((Dp>2) ? NUM_MAP[EditBuffer[0]] : (!EditBuffer[0] ? FONT_BLANK: NUM_MAP[EditBuffer[0]]));
		else
			*segmentData++	=(Dp==2) ? (!EditBuffer[0] ? FONT_0|FONT_DP|FONT_MINUS  : NUM_MAP[EditBuffer[0]]|FONT_DP|FONT_MINUS ) : ((Dp>2) ? NUM_MAP[EditBuffer[0]] : (!EditBuffer[0] ? FONT_MINUS : NUM_MAP[EditBuffer[0]]|FONT_MINUS ));
			
			*segmentData++	=(Dp==1) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Dp>1) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]));
			*segmentData 	=NUM_MAP[EditBuffer[2]];
			
}
void display_edit_4(u8 Dp ,u8 *segmentData){
		if(!Flag.Sign){
			*segmentData++=(Dp==3) ? (!EditBuffer[0] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[0]]|FONT_DP) : ((Dp>3) ? NUM_MAP[EditBuffer[0]] : (!EditBuffer[0] ? FONT_BLANK: NUM_MAP[EditBuffer[0]]));
			*segmentData++=(Dp==2) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Dp>2) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]));
			*segmentData++=(Dp==1) ? (!EditBuffer[2] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[2]]|FONT_DP) : ((Dp>1) ? NUM_MAP[EditBuffer[2]] : (!EditBuffer[0]&&!EditBuffer[1]&&!EditBuffer[2] ? FONT_BLANK : NUM_MAP[EditBuffer[2]]));
			*segmentData=NUM_MAP[EditBuffer[3]];
			}
		else{
			*segmentData++=(Dp==3) ? (!EditBuffer[0] ? FONT_0|FONT_DP|FONT_MINUS  : NUM_MAP[EditBuffer[0]]|FONT_DP|FONT_MINUS ) : ((Dp>3) ? NUM_MAP[EditBuffer[0]] : (!EditBuffer[0] ? FONT_MINUS : NUM_MAP[EditBuffer[0]]|FONT_MINUS ));
			*segmentData++=(Dp==2) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Dp>2) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]));
			*segmentData++=(Dp==1) ? (!EditBuffer[2] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[2]]|FONT_DP) : ((Dp>1) ? NUM_MAP[EditBuffer[2]] : (!EditBuffer[0]&&!EditBuffer[1]&&!EditBuffer[2] ? FONT_BLANK : NUM_MAP[EditBuffer[2]]));
			*segmentData=NUM_MAP[EditBuffer[3]];
			}
}

void display_edit_no_dp(u8 Dp ,u8 *segmentData){
	blink();
	if(!Flag.Blink){
			*segmentData++=(Dp==2) ? (!EditBuffer[0] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[0]]|FONT_DP) : ((Dp>2) ? NUM_MAP[EditBuffer[0]] : (!EditBuffer[0] ? FONT_BLANK: NUM_MAP[EditBuffer[0]]));
			*segmentData++=(Dp==1) ? (!EditBuffer[1] ? FONT_0|FONT_DP : NUM_MAP[EditBuffer[1]]|FONT_DP) : ((Dp>1) ? NUM_MAP[EditBuffer[1]] : (!EditBuffer[0]&&!EditBuffer[1] ? FONT_BLANK : NUM_MAP[EditBuffer[1]]));
			*segmentData=NUM_MAP[EditBuffer[2]];
			}
		else{set_char6(FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, FONT_BLANK, &segmentData);}
}

void display_page0(void){
	blink();
	switch(Flag.Logo){
		case 0:
			set_char3(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_PV1]);
			set_char3(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_PV2]);
			set_char3(TEST_SEGMENT, TEST_SEGMENT, TEST_SEGMENT, &SegmentData[SEG_PV3]);
			break;
		case 1:
		case 3:
			set_char3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_PV1]);
			set_char3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_PV2]);
			set_char3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_PV3]);
			break;
		case 2:
			// set_char3(FONT_BLANK, FONT_BLANK, FONT_C, &SegmentData[SEG_PV1]);
			// set_char3(FONT_4, FONT_3, FONT_5, &SegmentData[SEG_PV2]);
			// set_char3(FONT_BLANK, FONT_V, FONT_0, &SegmentData[SEG_PV3]);
			break;
		}
}
void pv_out(u8 dp, s32 value, u8 *segment){
	s32 temp;
	u8 buf[6],sign;
	temp = value;
	sign=0;
	if(temp<0){
		sign = 1;
		temp =-temp;
		}

	buf[0] = temp/100%10;
	buf[1] = temp/10%10;
	buf[2] = temp/1%10;
	// buf[3] = temp/1%10;

	if(!sign){
		 *segment++= dp==2? NUM_MAP[buf[0]]|FONT_DP : !buf[0]? FONT_BLANK : NUM_MAP[buf[0]];
		 *segment++= dp==1? NUM_MAP[buf[1]]|FONT_DP : dp>1? NUM_MAP[buf[1]] : !buf[0]&&!buf[1]? FONT_BLANK: NUM_MAP[buf[1]]|FONT_BLANK;
		 *segment= NUM_MAP[buf[2]];
		}
	else {
		 *segment++= dp==2? NUM_MAP[buf[0]]|FONT_DP|FONT_MINUS: !buf[0]? FONT_MINUS : NUM_MAP[buf[0]]|FONT_MINUS;
		 *segment++= dp==1? NUM_MAP[buf[1]]|FONT_DP : dp>1? NUM_MAP[buf[1]] : !buf[0]&&!buf[1]? FONT_BLANK: NUM_MAP[buf[1]]|FONT_BLANK;
		 *segment=NUM_MAP[buf[2]];
		}
		
}
void display_page1(void){	//	OPERATE
	if(Flag.PVHiLimit_ch1)		set_char3(FONT_OVER, FONT_OVER, FONT_OVER, &SegmentData[SEG_PV1]);
	else if(Flag.PVLoLimit_ch1)	set_char3(FONT_UNDER, FONT_UNDER, FONT_UNDER, &SegmentData[SEG_PV1]);
	else						pv_out(Value.DecimalPoint[0],Value.PV[0],&SegmentData[SEG_PV1]);
	
	if(Flag.PVHiLimit_ch2)		set_char3(FONT_OVER, FONT_OVER, FONT_OVER, &SegmentData[SEG_PV2]);
	else if(Flag.PVLoLimit_ch2)	set_char3(FONT_UNDER, FONT_UNDER, FONT_UNDER, &SegmentData[SEG_PV2]);
	else						pv_out(Value.DecimalPoint[1],Value.PV[1],&SegmentData[SEG_PV2]);
	
	// if(Flag.PVHiLimit_ch3)		set_char3(FONT_OVER, FONT_OVER, FONT_OVER, &SegmentData[SEG_PV3]);
	// else if(Flag.PVLoLimit_ch3)	set_char3(FONT_UNDER, FONT_UNDER, FONT_UNDER, &SegmentData[SEG_PV3]);
	// else						pv_out(Value.DecimalPoint[2],Value.PV[2],&SegmentData[SEG_PV3]);
}
void display_page2(void){	//	EDIT_SCALE_HI
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_P, FONT_H, _MAP[Value.Channel], &SegmentData[SEG_PV1]);
	display_edit_3(Value.DecimalPoint[Value.Channel], &SegmentData[SEG_PV2]);
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page3(void){	//	EDIT_SCALE_LO
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_P, FONT_L, _MAP[Value.Channel], &SegmentData[SEG_PV1]);
	display_edit_3(Value.DecimalPoint[Value.Channel], &SegmentData[SEG_PV2]);
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page4(void){	//	EDIT_DP
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_D, FONT_P, _MAP[Value.Channel], &SegmentData[SEG_PV1]);
	display_edit_3(0, &SegmentData[SEG_PV2]);
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page5(void){	//	EDIT_ADDRESS
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_A, FONT_D, FONT_D, &SegmentData[SEG_PV1]);
	display_edit_3(0, &SegmentData[SEG_PV2]);
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page6(void){	//	EDIT_BAUDRATE
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_B, FONT_P, FONT_S, &SegmentData[SEG_PV1]);
	switch(EditBuffer[EDIT_LENGTH-1]){
		case BR4800:
			set_char3(FONT_BLANK, FONT_4|FONT_DP, FONT_8, &SegmentData[SEG_PV2]);
			break;
		case BR9600:
			set_char3(FONT_BLANK, FONT_9|FONT_DP, FONT_6, &SegmentData[SEG_PV2]);
			break;
		case BR19200:
			set_char3(FONT_1, FONT_9|FONT_DP, FONT_2, &SegmentData[SEG_PV2]);
			break;
		case BR38400:
			set_char3(FONT_3, FONT_8|FONT_DP, FONT_4, &SegmentData[SEG_PV2]);
			break;
		case BR57600:
			set_char3(FONT_5, FONT_7|FONT_DP, FONT_6, &SegmentData[SEG_PV2]);
			break;
		}
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page7(void){	//	EDIT_PARITY
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_P, FONT_A, FONT_R, &SegmentData[SEG_PV1]);
	switch(EditBuffer[EDIT_LENGTH-1]){
		case b8n1:
			set_char3(FONT_8, FONT_N, FONT_1, &SegmentData[SEG_PV2]);
		break;
		case b8o1:
			set_char3(FONT_8, FONT_O, FONT_1, &SegmentData[SEG_PV2]);
		break;
		case b8e1:
			set_char3(FONT_8, FONT_E, FONT_1, &SegmentData[SEG_PV2]);
		break;
		}
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page8(void){	//	EDIT_DELAY_POLLS
}
void display_page9(void){	//	EDIT_RESPONSE_TIMEOUT
}
u16 DIS10;
void display_page10(void){	//	CAL_ANALOG
	blink();
	
	if(!Flag.CalPoint)
			set_char3(FONT_4, FONT_M|FONT_DP, _MAP[Value.Channel], &SegmentData[SEG_PV1]);
	else
			set_char3(FONT_2, FONT_0|FONT_DP, _MAP[Value.Channel], &SegmentData[SEG_PV1]);
			
	if(!Flag.Edit){
		if(!Flag.CalPoint){
		if(Flag.Blink)set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
			set_char3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_PV2]);
			}
		else{
		if(Flag.Blink)set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
			set_char3(FONT_BLANK, FONT_BLANK, FONT_BLANK, &SegmentData[SEG_PV2]);
			if(++DIS10>=200){DIS10=0; Flag.Edit=1;}
			}
		}
	else{
		if(Value.Channel==0)set_hex2(ADC.Filter[0],&SegmentData[SEG_PV2]);
		if(Value.Channel==1)set_hex2(ADC.Filter[1],&SegmentData[SEG_PV2]);
		if(Value.Channel==2)set_hex2(ADC.Filter[2],&SegmentData[SEG_PV2]);
		}
}

void display_page11(void){	//	IDLE
	set_char3(FONT_BLANK ,FONT_BLANK ,FONT_MINUS, &SegmentData[SEG_PV1]);
	set_char3(FONT_BLANK ,FONT_BLANK ,FONT_MINUS, &SegmentData[SEG_PV2]);
	// set_char3(FONT_BLANK ,FONT_BLANK ,FONT_MINUS, &SegmentData[SEG_PV3]);
}
void display_page12(void){	//	HYS_MODE
}
void display_page13(void){	//	SETPOINT_2_MODE
}
void display_page14(void){	//	CHANGE_DSP
}
void display_page15(void){	//	EDIT_TIMER
}
void display_page16(void){	//	EDIT_PUS_MODE
	blink();
	set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV3]);
	set_char3(FONT_P, FONT_C,_MAP[Value.Channel],&SegmentData[SEG_PV1]);
	display_edit_3(Value.DecimalPoint[Value.Channel], &SegmentData[SEG_PV2]);
	if(Flag.Blink){
		if(!Flag.Edit)
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV1]);
		else
			set_char3(FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[SEG_PV2]);
	}
}
void display_page17(void){	//	ALL_MODE
	// blink();
	// 	 if(Value.Channel == 0){
	// 	 	set_char4(FONT_1|FONT_DP,FONT_A, FONT_L,FONT_1,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[0], &SegmentData[4]);
	// 	 	}
	// else if(Value.Channel == 1){
	// 		set_char4(FONT_1|FONT_DP,FONT_A, FONT_L,FONT_2,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[0], &SegmentData[4]);
	// 		}
	// else if(Value.Channel == 2){
	// 		set_char4(FONT_2|FONT_DP,FONT_A, FONT_L,FONT_1,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[1], &SegmentData[4]);
	// 		}
	// else if(Value.Channel == 3){
	// 		set_char4(FONT_2|FONT_DP,FONT_A, FONT_L,FONT_2,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[1], &SegmentData[4]);
	// 		}
	
	// if(!Flag.Edit){
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[0]);
	// 	}
	// else {
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[4]);
	// 	}
}
void display_page18(void){	//	ALH_MODE
	// blink();
	// 	 if(Value.Channel == 0){
	// 	 	set_char4(FONT_1|FONT_DP,FONT_A, FONT_H,FONT_1,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[0], &SegmentData[4]);
	// 	 	}
	// else if(Value.Channel == 1){
	// 		set_char4(FONT_1|FONT_DP,FONT_A, FONT_H,FONT_2,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[0], &SegmentData[4]);
	// 		}
	// else if(Value.Channel == 2){
	// 		set_char4(FONT_2|FONT_DP,FONT_A, FONT_H,FONT_1,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[1], &SegmentData[4]);
	// 		}
	// else if(Value.Channel == 3){
	// 		set_char4(FONT_2|FONT_DP,FONT_A, FONT_H,FONT_2,&SegmentData[0]);
	// 		display_edit_4(Value.DecimalPoint[1], &SegmentData[4]);
	// 		}
	
	// if(!Flag.Edit){
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[0]);
	// 	}
	// else {
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[4]);
	// 	}
}
void display_page19(void){	//	ALC_MODE
	// blink();
	// set_char4(FONT_A, FONT_L,FONT_C,NUM_MAP[Value.Channel+1],&SegmentData[0]);
	// display_edit_4(Value.DecimalPoint[Value.Channel], &SegmentData[4]);
	
	// if(!Flag.Edit){
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[0]);
	// 	}
	// else {
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[4]);
	// 	}
}
void display_page20(void){	//	CHOOSE_MODE
	// blink();
	// set_char4(FONT_M, FONT_O,FONT_D,FONT_E,&SegmentData[0]);
	// display_edit_4(0, &SegmentData[4]);
	
	// if(!Flag.Edit){
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[0]);
	// 	}
	// else {
	// 	if(Flag.Blink)set_char4(FONT_BLANK,FONT_BLANK,FONT_BLANK,FONT_BLANK,&SegmentData[4]);
	// 	}
}
void display_page21(void){	//	MODE_INP
	set_char3(FONT_BLANK ,FONT_MINUS ,FONT_BLANK, &SegmentData[SEG_PV1]);
	set_char3(FONT_BLANK ,FONT_MINUS ,FONT_BLANK, &SegmentData[SEG_PV2]);
	// set_char3(FONT_BLANK ,FONT_MINUS ,FONT_BLANK, &SegmentData[SEG_PV3]);
}
void display_page22(void){	//	EDIT_VALUE_TIME
}
void display_page23(void){	//	EDIT_VALUE_DATE
}
void display_page24(void){	//	EDIT_VALUE_YEAR
}
void display_page25(void){	//	
	if(Value.Channel==0){	set_char4(FONT_BLANK, FONT_BLANK, FONT_M, FONT_A, &SegmentData[0]);}
//	if(Value.Channel==1){	set_char(FONT_BLANK, FONT_V, FONT_O, FONT_L, FONT_T, &SegmentData[0]);}
}
void display_page26(void){	//	
}
void display_page27(void){	//	
}
void display_page28(void){	//	
}
void display_page29(void){	//	
}
void display_page30(void){	//	
}

	
